import type { Metadata } from "next";
import { Inter, Outfit } from "next/font/google";
import Script from "next/script";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const outfit = Outfit({
  variable: "--font-outfit",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "hearingtest.co.uk — Find & Book Hearing Tests Near You",
  description:
    "Compare audiologists across the UK. Find hearing test appointments near you from Specsavers, Boots Hearingcare, Hidden Hearing and independent audiologists. Book online in seconds.",
  keywords: [
    "hearing test",
    "book hearing test",
    "audiologists near me",
    "hearing test appointment",
    "NHS hearing test",
    "free hearing test",
    "compare audiologists",
    "hearing test near me",
    "hearing test UK",
  ],
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "48x48" },
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-96x96.png", sizes: "96x96", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  manifest: "/site.webmanifest",
  openGraph: {
    title: "hearingtest.co.uk — Find & Book Hearing Tests Near You",
    description:
      "Compare audiologists across the UK. Find available hearing test appointments and book online in seconds.",
    url: "https://www.hearingtest.co.uk",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${outfit.variable} h-full`}
    >
      <head>
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"
          strategy="afterInteractive"
        />
        <Script id="gtag-init" strategy="afterInteractive">
          {`window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'G-XXXXXXXXXX');`}
        </Script>
      </head>
      <body className="min-h-full flex flex-col bg-white text-[var(--color-navy)]">
        {children}
      </body>
    </html>
  );
}
