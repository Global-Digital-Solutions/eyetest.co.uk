import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Partners from "@/components/Partners";
import WhyGetTested from "@/components/WhyGetTested";
import NHSBanner from "@/components/NHSBanner";
import Testimonials from "@/components/Testimonials";
import Footer from "@/components/Footer";
import { ScrollReveal, StaggerItem } from "@/components/ScrollReveal";
import { hearingTests } from "@/data/hearing-tests";
import { hearingConditions } from "@/data/hearing-health";
import { audiologists } from "@/data/audiologists";
import { articles } from "@/data/articles";

// ---------------------------------------------------------------------------
// SEO metadata
// ---------------------------------------------------------------------------

export const metadata: Metadata = {
  title: "hearingtest.co.uk — Find & Book Hearing Tests Near You",
  description:
    "Compare audiologists across the UK. Find hearing test appointments near you from Specsavers, Boots Hearingcare, Hidden Hearing and independents. Book online free.",
  keywords: [
    "hearing test",
    "book hearing test",
    "hearing test near me",
    "audiologists near me",
    "hearing test appointment",
    "NHS hearing test",
    "free hearing test",
    "compare audiologists",
    "hearing test UK",
  ],
  openGraph: {
    title: "hearingtest.co.uk — Find & Book Hearing Tests Near You",
    description:
      "Compare audiologists across the UK. Find available hearing test appointments and book online in seconds.",
    url: "https://www.hearingtest.co.uk",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk",
  },
};

// ---------------------------------------------------------------------------
// Icon map — maps icon names from data files to inline SVG paths
// ---------------------------------------------------------------------------

const iconMap: Record<string, React.ReactNode> = {
  ear: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
    </svg>
  ),
  shield: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
    </svg>
  ),
  monitor: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25A2.25 2.25 0 015.25 3h13.5A2.25 2.25 0 0121 5.25z" />
    </svg>
  ),
  baby: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.182 15.182a4.5 4.5 0 01-6.364 0M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z" />
    </svg>
  ),
  waves: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.348 14.651a3.75 3.75 0 010-5.303m5.304 0a3.75 3.75 0 010 5.303m-7.425 2.122a6.75 6.75 0 010-9.546m9.546 0a6.75 6.75 0 010 9.546M5.106 18.894c-3.808-3.808-3.808-9.98 0-13.789m13.788 0c3.808 3.808 3.808 9.981 0 13.79" />
    </svg>
  ),
  headphones: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 18v-6a9 9 0 0118 0v6M3 18a3 3 0 003 3h0a2 2 0 002-2v-3a2 2 0 00-2-2h0a3 3 0 00-3 3zm18 0a3 3 0 01-3 3h0a2 2 0 01-2-2v-3a2 2 0 012-2h0a3 3 0 013 3z" />
    </svg>
  ),
  volume: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
    </svg>
  ),
};

function getIcon(name: string) {
  return iconMap[name] || iconMap.ear;
}

// ---------------------------------------------------------------------------
// Condition icon map — subset for conditions section
// ---------------------------------------------------------------------------

const conditionIconMap: Record<string, React.ReactNode> = {
  ...iconMap,
  clock: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  "volume-x": (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
    </svg>
  ),
  "volume-2": iconMap.volume,
  thermometer: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6a8.983 8.983 0 013.361-6.867 8.21 8.21 0 003 2.48z" />
    </svg>
  ),
  "rotate-ccw": (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182" />
    </svg>
  ),
  droplets: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a8.25 8.25 0 006.222-13.555L12 2.25 5.778 7.445A8.25 8.25 0 0012 21z" />
    </svg>
  ),
  "alert-triangle": (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
    </svg>
  ),
  zap: (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
    </svg>
  ),
  "alert-circle": (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
    </svg>
  ),
  "circle-slash": (
    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
    </svg>
  ),
};

function getConditionIcon(name: string) {
  return conditionIconMap[name] || conditionIconMap.ear;
}

// ---------------------------------------------------------------------------
// Arrow icon used for "Read more" / "Learn more" links
// ---------------------------------------------------------------------------

const ArrowRight = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
  </svg>
);

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default function Home() {
  // ── JSON-LD structured data ───────────────────────────────────────────
  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "hearingtest.co.uk",
    url: "https://www.hearingtest.co.uk",
    description:
      "Compare audiologists across the UK. Find hearing test appointments near you and book online free.",
    potentialAction: {
      "@type": "SearchAction",
      target: {
        "@type": "EntryPoint",
        urlTemplate:
          "https://www.hearingtest.co.uk/search?postcode={search_term_string}",
      },
      "query-input": "required name=search_term_string",
    },
  };

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "hearingtest.co.uk",
    url: "https://www.hearingtest.co.uk",
    logo: "https://www.hearingtest.co.uk/logo.png",
    description:
      "The UK's dedicated hearing test comparison platform. Helping you find, compare, and book hearing tests.",
    foundingDate: "2025",
    parentOrganization: {
      "@type": "Organization",
      name: "Global Digital Solutions Limited",
    },
    sameAs: [],
  };

  // ── Data slices ───────────────────────────────────────────────────────
  const displayedTests = hearingTests.slice(0, 6);
  const displayedConditions = hearingConditions.slice(0, 6);
  const displayedArticles = articles.slice(0, 3);
  const allAudiologists = audiologists;

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(organizationJsonLd),
          }}
        />

        {/* ── Hero ─────────────────────────────────────────────────────── */}
        <Hero />

        {/* ── Partners strip ───────────────────────────────────────────── */}
        <Partners />

        {/* ── How It Works ─────────────────────────────────────────────── */}
        <section className="relative py-20 sm:py-24 bg-animated-gradient overflow-hidden">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {/* Section header */}
            <ScrollReveal animation="fade-up">
              <div className="text-center mb-16">
                <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-4">
                  How it works
                </span>
                <h2
                  className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--color-navy)] mb-4"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Book a hearing test in 3 simple steps
                </h2>
                <p className="text-[var(--color-navy)]/60 max-w-lg mx-auto text-base sm:text-lg leading-relaxed">
                  No phone calls, no waiting. Find a trusted audiologist near
                  you in minutes.
                </p>
              </div>
            </ScrollReveal>

            {/* Step cards */}
            <ScrollReveal stagger={150} className="grid gap-6 md:grid-cols-3">
              {[
                {
                  step: "1",
                  title: "Enter your postcode",
                  description:
                    "Tell us where you are and we'll search for audiologists with real availability near you.",
                  icon: (
                    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                    </svg>
                  ),
                },
                {
                  step: "2",
                  title: "Compare audiologists",
                  description:
                    "See who's available, compare services, and find the right audiologist for your needs.",
                  icon: (
                    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                    </svg>
                  ),
                },
                {
                  step: "3",
                  title: "Book online",
                  description:
                    "Choose a time that suits you and book directly. Same-day appointments are often available.",
                  icon: (
                    <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  ),
                },
              ].map((item) => (
                <StaggerItem key={item.step}>
                  <div className="card-lift relative flex items-start gap-5 rounded-2xl bg-white p-7 border border-[var(--color-warm-200)] shadow-sm">
                    {/* Step number badge with warm gradient */}
                    <div
                      className="flex-shrink-0 flex items-center justify-center w-14 h-14 rounded-2xl text-white text-xl font-bold"
                      style={{
                        fontFamily: "var(--font-display)",
                        background:
                          "linear-gradient(135deg, var(--color-accent) 0%, var(--color-accent-dark) 100%)",
                        boxShadow: "0 4px 14px rgba(13, 148, 136, 0.25)",
                      }}
                    >
                      {item.step}
                    </div>
                    {/* Text content */}
                    <div className="flex-1 min-w-0">
                      <h3
                        className="text-lg sm:text-xl font-bold text-[var(--color-navy)] mb-2"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {item.title}
                      </h3>
                      <p className="text-base text-[var(--color-navy)]/60 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                    {/* Icon accent */}
                    <div className="hidden sm:flex flex-shrink-0 items-center justify-center w-11 h-11 rounded-xl bg-[var(--color-accent)]/10 text-[var(--color-accent)]">
                      {item.icon}
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </ScrollReveal>
          </div>
        </section>

        {/* ── Why Get Tested — empathetic reassurance section ──────────── */}
        <WhyGetTested />

        {/* ── NHS Eligibility Banner ───────────────────────────────────── */}
        <NHSBanner />

        {/* ── Testimonials ─────────────────────────────────────────────── */}
        <Testimonials />

        {/* ── Hearing Tests ────────────────────────────────────────────── */}
        <section className="relative py-20 overflow-hidden">
          {/* Decorative background accents */}
          <div className="absolute top-20 right-0 w-80 h-80 rounded-full bg-[var(--color-accent)] opacity-[0.03] blur-3xl pointer-events-none" />

          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <ScrollReveal animation="fade-up">
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12">
                <div>
                  <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-3">
                    Hearing tests
                  </span>
                  <h2
                    className="text-3xl sm:text-4xl font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Types of Hearing Test
                  </h2>
                  <p className="mt-3 text-lg text-[var(--color-navy)]/60 max-w-2xl">
                    From standard audiometry to specialist assessments — find the
                    right test for your needs.
                  </p>
                </div>
                <Link
                  href="/hearing-tests"
                  className="group mt-4 sm:mt-0 inline-flex items-center gap-1.5 text-[var(--color-accent)] font-semibold hover:underline underline-offset-4 whitespace-nowrap transition-all"
                >
                  View all tests
                  <span className="group-hover:translate-x-1 transition-transform">
                    <ArrowRight />
                  </span>
                </Link>
              </div>
            </ScrollReveal>

            <ScrollReveal stagger={100} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {displayedTests.map((test) => (
                <StaggerItem key={test.slug}>
                  <Link
                    href={`/hearing-tests/${test.slug}`}
                    className="group block bg-white border border-[var(--color-warm-200)] rounded-2xl p-7 card-lift shadow-sm"
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[var(--color-accent)]/10 text-[var(--color-accent)]">
                        {getIcon(test.icon)}
                      </div>
                      <h3
                        className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-accent)] transition-colors"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {test.name}
                      </h3>
                    </div>
                    <p className="text-base text-[var(--color-navy)]/60 leading-relaxed line-clamp-3">
                      {test.shortDescription}
                    </p>
                    <div className="mt-5 flex items-center justify-between">
                      <div className="flex items-center gap-3 text-sm text-[var(--color-navy)]/50">
                        <span className="flex items-center gap-1">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          {test.duration}
                        </span>
                        {test.nhsCovered && (
                          <span className="inline-flex items-center gap-1 rounded-full bg-[var(--color-nhs-blue)]/10 px-2.5 py-1 text-sm text-[var(--color-nhs-blue)] font-medium">
                            NHS
                          </span>
                        )}
                      </div>
                      <span className="inline-flex items-center gap-1 text-sm font-semibold text-[var(--color-accent)] group-hover:gap-2 transition-all">
                        Learn more <ArrowRight />
                      </span>
                    </div>
                  </Link>
                </StaggerItem>
              ))}
            </ScrollReveal>
          </div>
        </section>

        {/* ── Hearing Health / Conditions ───────────────────────────────── */}
        <section className="py-20 bg-animated-gradient relative overflow-hidden">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <ScrollReveal animation="fade-up">
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12">
                <div>
                  <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-3">
                    Hearing health
                  </span>
                  <h2
                    className="text-3xl sm:text-4xl font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Understanding Your Hearing
                  </h2>
                  <p className="mt-3 text-lg text-[var(--color-navy)]/60 max-w-2xl">
                    Learn about common hearing conditions, what causes them, and
                    the treatment options available.
                  </p>
                </div>
                <Link
                  href="/hearing-health/conditions"
                  className="group mt-4 sm:mt-0 inline-flex items-center gap-1.5 text-[var(--color-accent)] font-semibold hover:underline underline-offset-4 whitespace-nowrap transition-all"
                >
                  View all conditions
                  <span className="group-hover:translate-x-1 transition-transform">
                    <ArrowRight />
                  </span>
                </Link>
              </div>
            </ScrollReveal>

            <ScrollReveal stagger={100} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {displayedConditions.map((condition) => (
                <StaggerItem key={condition.slug}>
                  <Link
                    href={`/hearing-health/conditions/${condition.slug}`}
                    className="group block bg-white border border-[var(--color-warm-200)] rounded-2xl p-7 card-lift shadow-sm"
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[var(--color-accent)]/10 text-[var(--color-accent)]">
                        {getConditionIcon(condition.icon)}
                      </div>
                      <h3
                        className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-accent)] transition-colors"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {condition.name}
                      </h3>
                    </div>
                    <p className="text-base text-[var(--color-navy)]/60 leading-relaxed line-clamp-3">
                      {condition.shortDescription}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {condition.symptoms.slice(0, 2).map((symptom) => (
                        <span
                          key={symptom}
                          className="inline-block rounded-full bg-[var(--color-accent)]/8 px-3 py-1 text-sm text-[var(--color-navy)]/50"
                        >
                          {symptom.length > 35
                            ? symptom.slice(0, 35) + "..."
                            : symptom}
                        </span>
                      ))}
                    </div>
                  </Link>
                </StaggerItem>
              ))}
            </ScrollReveal>
          </div>
        </section>

        {/* ── Audiologists ─────────────────────────────────────────────── */}
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <ScrollReveal animation="fade-up">
              <div className="text-center mb-14">
                <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-3">
                  Hearing care providers
                </span>
                <h2
                  className="text-3xl sm:text-4xl font-bold text-[var(--color-navy)]"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Trusted Audiologists Across the UK
                </h2>
                <p className="mt-4 text-lg text-[var(--color-navy)]/60 max-w-3xl mx-auto">
                  Compare services, prices, and availability from leading
                  hearing care brands and independent audiologists near you.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal stagger={80} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {allAudiologists.map((brand) => (
                <StaggerItem key={brand.slug}>
                  <Link
                    href={`/audiologists/${brand.slug}`}
                    className="group block bg-white border border-[var(--color-warm-200)] rounded-2xl p-7 card-lift shadow-sm text-center"
                  >
                    {/* Brand colour bar with hover lift accent */}
                    <div
                      className="mx-auto mb-4 h-1.5 w-16 rounded-full transition-all duration-300 group-hover:w-20"
                      style={{ backgroundColor: brand.brandColor }}
                    />
                    <h3
                      className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-accent)] transition-colors mb-2"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {brand.shortName}
                    </h3>
                    <p className="text-base text-[var(--color-navy)]/50 mb-4">
                      {brand.storeCount.toLocaleString()}+ locations
                    </p>
                    <div className="flex flex-wrap justify-center gap-1.5">
                      {brand.nhsAvailable && (
                        <span className="inline-flex items-center rounded-full bg-[var(--color-nhs-blue)]/10 px-2.5 py-1 text-sm font-medium text-[var(--color-nhs-blue)]">
                          NHS
                        </span>
                      )}
                      {brand.available && (
                        <span className="inline-flex items-center rounded-full bg-[var(--color-success)]/10 px-2.5 py-1 text-sm font-medium text-[var(--color-success)]">
                          Live Availability
                        </span>
                      )}
                    </div>
                  </Link>
                </StaggerItem>
              ))}
            </ScrollReveal>
          </div>
        </section>

        {/* ── Articles ─────────────────────────────────────────────────── */}
        <section className="py-20 bg-[var(--color-warm-50)]">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <ScrollReveal animation="fade-up">
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12">
                <div>
                  <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-3">
                    Guides &amp; advice
                  </span>
                  <h2
                    className="text-3xl sm:text-4xl font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Helpful Reading
                  </h2>
                  <p className="mt-3 text-lg text-[var(--color-navy)]/60 max-w-2xl">
                    Practical advice and expert guidance on hearing health,
                    hearing aids, and getting the most from your appointment.
                  </p>
                </div>
                <Link
                  href="/articles"
                  className="group mt-4 sm:mt-0 inline-flex items-center gap-1.5 text-[var(--color-accent)] font-semibold hover:underline underline-offset-4 whitespace-nowrap transition-all"
                >
                  View all articles
                  <span className="group-hover:translate-x-1 transition-transform">
                    <ArrowRight />
                  </span>
                </Link>
              </div>
            </ScrollReveal>

            <ScrollReveal stagger={120} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {displayedArticles.map((article) => (
                <StaggerItem key={article.slug}>
                  <Link
                    href={`/articles/${article.slug}`}
                    className="group block bg-white rounded-2xl overflow-hidden shadow-sm card-lift border border-[var(--color-warm-200)]"
                  >
                    {/* Article image area */}
                    <div className="img-zoom aspect-[16/9] bg-gradient-to-br from-[var(--color-accent)]/10 to-[var(--color-accent)]/5 flex items-center justify-center">
                      <svg className="w-10 h-10 text-[var(--color-accent)]/30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5" />
                      </svg>
                    </div>
                    <div className="p-7">
                      <div className="flex items-center gap-3 mb-3">
                        <span className="inline-block rounded-full bg-[var(--color-accent)]/10 px-3 py-1 text-sm font-medium text-[var(--color-accent)] capitalize">
                          {article.category}
                        </span>
                        <span className="text-sm text-[var(--color-navy)]/40">
                          {article.readTime}
                        </span>
                      </div>
                      <h3
                        className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-accent)] transition-colors mb-2 line-clamp-2"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {article.title}
                      </h3>
                      <p className="text-base text-[var(--color-navy)]/60 leading-relaxed line-clamp-3">
                        {article.excerpt}
                      </p>
                      <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[var(--color-accent)] group-hover:gap-2 transition-all">
                        Read more <ArrowRight />
                      </div>
                    </div>
                  </Link>
                </StaggerItem>
              ))}
            </ScrollReveal>
          </div>
        </section>

        {/* ── CTA Banner ───────────────────────────────────────────────── */}
        <section className="py-20 relative overflow-hidden">
          {/* Warm navy background */}
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(135deg, #1a2744 0%, #243556 40%, #1a3550 70%, #1a2744 100%)",
            }}
          />

          {/* Decorative floating orbs */}
          <div className="absolute top-10 right-[10%] w-48 h-48 rounded-full bg-[var(--color-accent)] opacity-10 blur-3xl animate-float-slow pointer-events-none" />
          <div className="absolute bottom-8 left-[5%] w-32 h-32 rounded-full bg-[var(--color-accent-light)] opacity-[0.07] blur-2xl animate-float-slow pointer-events-none" />

          <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
            <ScrollReveal animation="fade-up">
              <h2
                className="text-3xl sm:text-4xl font-bold text-white mb-5"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Ready to take the first step?
              </h2>
              <p className="text-lg sm:text-xl text-white/70 mb-10 max-w-2xl mx-auto leading-relaxed">
                Enter your postcode and we&apos;ll find trusted audiologists
                near you with available appointments. It takes less than
                30&nbsp;seconds.
              </p>

              <form
                action="/search"
                method="GET"
                className="mx-auto flex max-w-md flex-col sm:flex-row gap-3"
              >
                <label htmlFor="cta-postcode" className="sr-only">
                  Your postcode
                </label>
                <input
                  id="cta-postcode"
                  type="text"
                  name="postcode"
                  placeholder="Enter your postcode"
                  required
                  autoComplete="postal-code"
                  className="flex-1 rounded-xl border border-white/20 bg-white/10 px-5 py-4 text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)] focus:border-transparent backdrop-blur-sm text-base"
                />
                <button
                  type="submit"
                  className="rounded-xl bg-[var(--color-accent)] px-7 py-4 text-base font-semibold text-white shadow-lg hover:bg-[var(--color-accent-dark)] transition-colors animate-pulse-glow"
                >
                  Find hearing tests
                </button>
              </form>

              <p className="mt-6 text-sm text-white/40">
                Free to use · No registration required
              </p>
            </ScrollReveal>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
