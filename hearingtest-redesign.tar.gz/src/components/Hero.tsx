"use client";

import { useState } from "react";

export default function Hero() {
  const [postcode, setPostcode] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (postcode.trim()) {
      window.location.href = `/search?postcode=${encodeURIComponent(postcode.trim())}`;
    }
  };

  return (
    <section
      id="search"
      className="relative overflow-hidden"
    >
      {/* Hero background image — WebP with JPG fallback */}
      <picture className="absolute inset-0">
        <source srcSet="/images/heroes/hero-home.webp" type="image/webp" />
        <img
          src="/images/heroes/hero-home.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          loading="eager"
        />
      </picture>
      {/* Warmer, softer overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[var(--color-navy)]/70 via-[var(--color-navy)]/50 to-[var(--color-navy)]/75" />

      {/* Soft warm glow accents */}
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-[var(--color-accent)] rounded-full opacity-[0.08] blur-3xl" />
      <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-[var(--color-accent-light)] rounded-full opacity-[0.05] blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 py-20 sm:py-24 lg:py-32">
        <div className="max-w-2xl mx-auto text-center">
          {/* Warm reassurance badge */}
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/15 text-white/90 text-sm sm:text-base font-medium px-5 py-2 rounded-full mb-8">
            <span className="w-2.5 h-2.5 bg-[var(--color-success)] rounded-full animate-pulse" />
            <span>Free NHS hearing tests available</span>
          </div>

          {/* Empathetic heading — addresses the person, not the product */}
          <h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-[1.15] mb-6"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Your hearing matters.{" "}
            <span className="text-[var(--color-accent-light)]">
              Let&apos;s find the right test for you.
            </span>
          </h1>

          {/* Warm, reassuring subheading */}
          <p className="text-lg sm:text-xl text-white/80 mb-10 max-w-xl mx-auto leading-relaxed">
            Quick, painless, and often free on the NHS. Compare trusted
            audiologists near you and book online in seconds.
          </p>

          {/* Search form */}
          <form onSubmit={handleSearch} className="max-w-xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-0 sm:bg-white sm:rounded-full sm:p-1.5 sm:shadow-xl sm:shadow-black/10">
              <div className="relative flex-1">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value)}
                  placeholder="Enter your postcode, e.g. SW1A 1AA"
                  className="w-full pl-12 pr-4 py-4 sm:py-3.5 text-base sm:text-lg text-[var(--color-navy)] bg-white sm:bg-transparent rounded-xl sm:rounded-full border border-gray-200 sm:border-none focus:outline-none placeholder:text-gray-400"
                  aria-label="Enter your postcode"
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 bg-[var(--color-accent)] hover:bg-[var(--color-accent-dark)] text-white font-semibold text-base px-8 py-4 sm:py-3.5 rounded-xl sm:rounded-full transition-all hover:shadow-lg cursor-pointer"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Find hearing tests
              </button>
            </div>

            {/* Geolocation shortcut */}
            <button
              type="button"
              className="mt-5 inline-flex items-center gap-1.5 text-sm text-white/60 hover:text-white/90 transition-colors cursor-pointer"
              onClick={() => {
                if (navigator.geolocation) {
                  navigator.geolocation.getCurrentPosition(
                    () => {
                      setPostcode("Using your location...");
                    },
                    () => {
                      alert("Unable to get your location. Please enter a postcode.");
                    }
                  );
                }
              }}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
              </svg>
              Use my current location
            </button>
          </form>

          {/* Trust indicators — larger text, warmer feel */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-white/60">
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[var(--color-accent-light)]" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              100% free to use
            </span>
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[var(--color-accent-light)]" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              Quick &amp; painless
            </span>
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[var(--color-accent-light)]" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              NHS &amp; private
            </span>
            <span className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[var(--color-accent-light)]" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              Trusted brands
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
