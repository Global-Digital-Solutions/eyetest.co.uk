import Link from "next/link";
import { ScrollReveal } from "./ScrollReveal";

export default function NHSBanner() {
  return (
    <section className="py-14 sm:py-16 relative overflow-hidden">
      {/* Soft warm background */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(135deg, #e8f4fd 0%, #f0f4ff 40%, #f0fdfa 70%, #f0f4ff 100%)",
        }}
      />

      {/* Decorative floating shapes */}
      <div className="absolute top-8 right-[10%] w-24 h-24 rounded-full bg-[var(--color-nhs-blue)] opacity-[0.04] blur-xl animate-float" />
      <div className="absolute bottom-4 left-[15%] w-32 h-32 rounded-full bg-[var(--color-accent)] opacity-[0.04] blur-xl animate-float-delay" />

      <div className="relative max-w-7xl mx-auto px-4">
        <ScrollReveal animation="fade-up">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-12">
            {/* Left — NHS visual */}
            <div className="hidden lg:block lg:w-72 xl:w-80 shrink-0">
              <div className="relative rounded-2xl overflow-hidden shadow-lg bg-gradient-to-br from-[var(--color-nhs-blue)] to-[#003d7a] p-10 text-center">
                <span
                  className="text-white font-bold text-5xl"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  NHS
                </span>
                <p className="text-white/80 text-sm mt-3">
                  Free hearing tests for eligible patients
                </p>
                {/* Decorative rings */}
                <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full border-2 border-white/10" />
                <div className="absolute -bottom-4 -left-4 w-16 h-16 rounded-full border-2 border-white/10" />
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start gap-4 mb-5">
                {/* NHS Logo - mobile */}
                <div className="lg:hidden w-14 h-14 bg-[var(--color-nhs-blue)] rounded-xl flex items-center justify-center shadow-md shadow-[var(--color-nhs-blue)]/20">
                  <span
                    className="text-white font-bold text-lg"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    NHS
                  </span>
                </div>
                <div>
                  <h2
                    className="text-xl sm:text-2xl lg:text-3xl font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Could you get a free NHS hearing test?
                  </h2>
                </div>
              </div>

              <p className="text-base sm:text-lg text-[var(--color-navy)]/60 mb-6 max-w-2xl leading-relaxed">
                If your GP refers you, NHS hearing tests and hearing aids are
                completely free. Many high-street audiologists also offer free
                initial hearing assessments. You may be eligible if you fall into
                any of these groups:
              </p>

              {/* Quick eligibility badges */}
              <div className="flex flex-wrap gap-2 mb-8 justify-center lg:justify-start">
                {[
                  "Over 50",
                  "GP referral",
                  "Registered disabled",
                  "War pensioner",
                  "Income support",
                  "Under 18",
                ].map((badge) => (
                  <span
                    key={badge}
                    className="inline-flex items-center gap-1.5 text-sm bg-white border border-[var(--color-nhs-blue)]/20 text-[var(--color-nhs-blue)] px-3.5 py-2 rounded-full font-medium"
                  >
                    <svg
                      className="w-4 h-4"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {badge}
                  </span>
                ))}
              </div>

              <Link
                href="/hearing-health/guides/nhs-hearing-test-eligibility"
                className="inline-flex items-center gap-2 bg-[var(--color-nhs-blue)] hover:bg-[#004a93] text-white font-semibold text-base px-7 py-3.5 rounded-full transition-all hover:shadow-lg"
              >
                Check NHS eligibility
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                  />
                </svg>
              </Link>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
