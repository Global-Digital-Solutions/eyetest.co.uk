const partners = [
  { name: "Specsavers Audiology", available: true },
  { name: "Boots Hearingcare", available: true },
  { name: "Scrivens Hearing", available: true },
  { name: "Leightons Hearing", available: true },
  { name: "Hidden Hearing", available: false },
  { name: "Amplifon", available: false },
  { name: "Bayfields Audiology", available: false },
  { name: "Local Independent Audiologists", available: true },
];

export default function Partners() {
  return (
    <section className="py-6 sm:py-8 bg-[var(--color-warm-50)] border-y border-[var(--color-warm-200)]/50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-center gap-2 mb-4">
          <span className="text-sm font-medium text-[var(--color-navy)]/40 uppercase tracking-wider">
            Checking availability across
          </span>
        </div>
        <div className="relative overflow-hidden scroll-mask">
          <div className="partners-track">
            {/* Set 1 */}
            {partners.map((p) => (
              <div
                key={`a-${p.name}`}
                className={`flex items-center gap-2 flex-shrink-0 px-4 py-2.5 rounded-lg ${
                  p.available
                    ? "bg-white border border-[var(--color-warm-200)]"
                    : "bg-[var(--color-warm-100)] border border-[var(--color-warm-200)]/50 opacity-50"
                }`}
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    p.available ? "bg-[var(--color-success)]" : "bg-gray-300"
                  }`}
                />
                <span
                  className={`text-sm font-semibold whitespace-nowrap ${
                    p.available
                      ? "text-[var(--color-navy)]"
                      : "text-[var(--color-navy)]/40"
                  }`}
                >
                  {p.name}
                </span>
                {!p.available && (
                  <span className="text-[10px] text-[var(--color-navy)]/30 font-normal">
                    Coming soon
                  </span>
                )}
              </div>
            ))}
            {/* Set 2 (duplicate for seamless loop) */}
            {partners.map((p) => (
              <div
                key={`b-${p.name}`}
                className={`flex items-center gap-2 flex-shrink-0 px-4 py-2.5 rounded-lg ${
                  p.available
                    ? "bg-white border border-[var(--color-warm-200)]"
                    : "bg-[var(--color-warm-100)] border border-[var(--color-warm-200)]/50 opacity-50"
                }`}
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    p.available ? "bg-[var(--color-success)]" : "bg-gray-300"
                  }`}
                />
                <span
                  className={`text-sm font-semibold whitespace-nowrap ${
                    p.available
                      ? "text-[var(--color-navy)]"
                      : "text-[var(--color-navy)]/40"
                  }`}
                >
                  {p.name}
                </span>
                {!p.available && (
                  <span className="text-[10px] text-[var(--color-navy)]/30 font-normal">
                    Coming soon
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
