import { ScrollReveal, StaggerItem } from "@/components/ScrollReveal";

const stats = [
  {
    value: "1 in 6",
    label: "UK adults has some degree of hearing loss",
  },
  {
    value: "10 years",
    label: "Average time people wait before seeking help",
  },
  {
    value: "20 mins",
    label: "Is all a standard hearing test takes",
  },
];

const reasons = [
  {
    title: "It's quicker than you think",
    description:
      "A hearing test takes around 20 minutes. There's no discomfort — you simply listen to sounds through headphones and respond. Most people find it far easier than they expected.",
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    title: "Early detection makes a real difference",
    description:
      "Untreated hearing loss is linked to social isolation, cognitive decline, and reduced quality of life. The earlier it's picked up, the more effective treatment can be.",
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
      </svg>
    ),
  },
  {
    title: "Free on the NHS for many people",
    description:
      "If you're referred by your GP, your hearing test and any NHS hearing aids are completely free. Many high-street audiologists also offer free initial assessments.",
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" />
      </svg>
    ),
  },
  {
    title: "Friendly, professional care",
    description:
      "Today's audiologists are warm, patient professionals. There's no judgement and no pressure — just expert guidance to help you hear your best.",
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.182 15.182a4.5 4.5 0 01-6.364 0M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z" />
      </svg>
    ),
  },
];

export default function WhyGetTested() {
  return (
    <section className="py-20 sm:py-24 relative overflow-hidden">
      {/* Warm background */}
      <div className="absolute inset-0 bg-[var(--color-warm-50)]" />

      {/* Decorative accents */}
      <div className="absolute top-10 right-[8%] w-40 h-40 rounded-full bg-[var(--color-accent)] opacity-[0.04] blur-3xl" />
      <div className="absolute bottom-10 left-[5%] w-56 h-56 rounded-full bg-[var(--color-primary)] opacity-[0.04] blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <ScrollReveal animation="fade-up">
          <div className="text-center mb-14">
            <span className="inline-block text-xs font-semibold uppercase tracking-[0.2em] text-[var(--color-accent)] mb-3">
              You&apos;re not alone
            </span>
            <h2
              className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[var(--color-navy)] mb-5"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Noticing changes in your hearing?
            </h2>
            <p className="text-lg sm:text-xl text-[var(--color-navy)]/60 max-w-2xl mx-auto leading-relaxed">
              Struggling to follow conversations in busy places? Turning the TV
              up more than you used to? You&apos;re far from alone — and getting
              checked is easier than you think.
            </p>
          </div>
        </ScrollReveal>

        {/* Stats row */}
        <ScrollReveal animation="fade-up" delay={100}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16 max-w-3xl mx-auto">
            {stats.map((stat) => (
              <div
                key={stat.value}
                className="text-center p-6 bg-white rounded-2xl border border-[var(--color-warm-200)] shadow-sm"
              >
                <p
                  className="text-3xl sm:text-4xl font-bold text-[var(--color-accent)] mb-2"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {stat.value}
                </p>
                <p className="text-sm sm:text-base text-[var(--color-navy)]/60 leading-snug">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </ScrollReveal>

        {/* Reason cards — 2x2 grid */}
        <ScrollReveal stagger={120} className="grid gap-6 sm:grid-cols-2">
          {reasons.map((reason) => (
            <StaggerItem key={reason.title}>
              <div className="card-lift flex gap-4 p-7 bg-white rounded-2xl border border-[var(--color-warm-200)] shadow-sm">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-[var(--color-accent)]/10 text-[var(--color-accent)] flex items-center justify-center">
                  {reason.icon}
                </div>
                <div>
                  <h3
                    className="text-lg font-bold text-[var(--color-navy)] mb-2"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {reason.title}
                  </h3>
                  <p className="text-base text-[var(--color-navy)]/60 leading-relaxed">
                    {reason.description}
                  </p>
                </div>
              </div>
            </StaggerItem>
          ))}
        </ScrollReveal>
      </div>
    </section>
  );
}
