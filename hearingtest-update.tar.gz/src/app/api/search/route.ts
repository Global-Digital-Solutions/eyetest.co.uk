import { NextRequest } from "next/server";
import { geocodePostcode } from "@/lib/postcodes";
import { fetchBootsHearing } from "@/lib/providers/boots-hearing";
import { fetchSpecsavers } from "@/lib/providers/specsavers";
import { fetchScrivens } from "@/lib/providers/scrivens";
import { fetchLeightons } from "@/lib/providers/leightons";
import type { StoreResult } from "@/lib/types";

const enc = new TextEncoder();

function line(data: object): Uint8Array {
  return enc.encode(JSON.stringify(data) + "\n");
}

async function withTimeout<T>(
  promise: Promise<T>,
  ms: number,
  label: string
): Promise<T> {
  const timeout = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms)
  );
  return Promise.race([promise, timeout]);
}

export async function GET(req: NextRequest) {
  const postcode = req.nextUrl.searchParams.get("postcode");
  if (!postcode) {
    return new Response(JSON.stringify({ error: "postcode is required" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  let geo;
  try {
    geo = await geocodePostcode(postcode);
  } catch (err) {
    return new Response(
      JSON.stringify({
        error: err instanceof Error ? err.message : "Invalid postcode",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }

  const { lat, lng } = geo;
  const RADIUS = 16093; // 10 miles in metres — hearing providers are more spread out
  const LIMIT = 10;
  const TIMEOUT_MS = 20000;

  // Provider config — hardcoded with enabled:true as Supabase may not be configured yet.
  // When Supabase is set up, add a "providers" table and query it here.
  const cfg: Record<string, boolean> = {
    "Boots Hearingcare": true,
    "Specsavers Audiology": true,
    "Scrivens Hearing": true,
    "Leightons Hearing": true,
  };
  const enabled = (name: string) => cfg[name] ?? true;

  const activeProviders = Object.entries(cfg)
    .filter(([, v]) => v)
    .map(([k]) => k);

  const stream = new ReadableStream({
    async start(controller) {
      // Send postcode + active provider list so the frontend knows what to show
      controller.enqueue(
        line({ type: "meta", postcode: geo.postcode, lat, lng, district: geo.district, activeProviders })
      );

      async function runProvider(
        providerName: string,
        fn: () => Promise<StoreResult[]>
      ) {
        try {
          const results = await withTimeout(fn(), TIMEOUT_MS, providerName);
          controller.enqueue(
            line({ type: "results", provider: providerName, results })
          );
        } catch (err) {
          controller.enqueue(
            line({
              type: "error",
              provider: providerName,
              message: err instanceof Error ? err.message : String(err),
            })
          );
        }
      }

      const providers = [
        ...(enabled("Boots Hearingcare")
          ? [runProvider("Boots Hearingcare", () => fetchBootsHearing(lat, lng, RADIUS, LIMIT))]
          : []),
        ...(enabled("Specsavers Audiology")
          ? [runProvider("Specsavers Audiology", () => fetchSpecsavers(lat, lng, RADIUS, LIMIT))]
          : []),
        ...(enabled("Scrivens Hearing")
          ? [runProvider("Scrivens Hearing", () => fetchScrivens(lat, lng, RADIUS, LIMIT))]
          : []),
        ...(enabled("Leightons Hearing")
          ? [runProvider("Leightons Hearing", () => fetchLeightons(lat, lng, RADIUS, LIMIT))]
          : []),
      ];

      await Promise.all(providers);

      controller.enqueue(line({ type: "done" }));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson",
      "Cache-Control": "no-cache",
      "X-Accel-Buffering": "no",
    },
  });
}
