import type { StoreResult } from "../types";
import { ukToday, getThreeDayDates, getThreeDayDatesFrom } from "../dates";

const OCUCO_BASE = "https://eu.oh.ocuco.com/api/omni/v303";
const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
  Accept: "application/json, text/plain, */*",
  "Accept-Language": "en-GB,en;q=0.9",
  Origin: "https://www.bootshearingcare.com",
  Referer: "https://www.bootshearingcare.com/",
};

// Boots Hearingcare hearing assessment visit type UUID.
// TODO: Discover the correct UUID by inspecting network requests on
// https://www.bootshearingcare.com when booking a hearing test.
// The Boots Opticians equivalent is: b0a9995e-0332-411d-ad7c-e9aa1590d639
const VISIT_TYPE_HEARING = "PLACEHOLDER_HEARING_UUID";

function formatSlot(isoString: string): string {
  const dt = new Date(isoString);
  return `Available — next ${dt.toLocaleDateString("en-GB", { weekday: "short", day: "2-digit", month: "short" })} at ${dt.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}`;
}

export async function fetchBootsHearing(
  lat: number,
  lng: number,
  radius = 16093,
  limit = 10
): Promise<StoreResult[]> {
  const todayStr = ukToday();
  const threeDays = getThreeDayDates();
  const results: StoreResult[] = [];
  let offset = 0;
  const pageSize = Math.max(limit, 20);

  outer: while (results.length < limit) {
    const url = new URL(`${OCUCO_BASE}/site/availableappointmentslots`);
    url.searchParams.set("originLatitude", String(lat));
    url.searchParams.set("originLongitude", String(lng));
    url.searchParams.set("visitTypeId", VISIT_TYPE_HEARING);
    url.searchParams.set("window", String(pageSize));
    url.searchParams.set("offset", String(offset));

    const res = await fetch(url.toString(), { headers: HEADERS });
    if (!res.ok) throw new Error(`Boots Hearingcare API error: ${res.status}`);
    const json = await res.json();
    const data = (json.data ?? []) as Record<string, unknown>[];
    const hasMore = (json.meta as Record<string, unknown>)?.hasMoreResults as boolean ?? false;
    if (!data.length) break;

    for (const item of data) {
      const site = (item.site ?? {}) as Record<string, unknown>;
      if (!site.siteId) continue;

      // distanceFromOriginKms is on the site object
      const distM = Number(site.distanceFromOriginKms ?? 0) * 1000;
      // API returns results sorted by distance; stop when we exceed radius
      if (distM > radius) break outer;

      const slotFound = item.slotFound as boolean;
      const nextSlot = item.nextAvailableSlot as Record<string, string> | null;
      const nextStart = nextSlot?.startTime ?? "";
      const nextDateStr = nextStart ? nextStart.slice(0, 10) : "";
      const isFuture = nextDateStr >= todayStr;
      const addressParts = [site.address1, site.address2].filter(Boolean).map(String);

      // Build 3-day availability calendar
      let dailySlots = threeDays.map((date) => ({
        date,
        count: slotFound && isFuture && nextDateStr === date ? -1 : 0,
      }));

      // If no slots in initial 3-day window but next available exists beyond it,
      // shift the window to show 3 days starting from the next available date
      if (dailySlots.every((s) => s.count === 0) && slotFound && isFuture && nextDateStr) {
        const shiftedDays = getThreeDayDatesFrom(nextDateStr);
        dailySlots = shiftedDays.map((date) => ({
          date,
          count: date === nextDateStr ? -1 : 0,
        }));
      }

      results.push({
        provider: "Boots Hearingcare",
        storeName: String(site.name ?? "Boots Hearingcare"),
        address: addressParts.join(", "),
        postcode: String(site.postalCode ?? ""),
        town: String(site.city ?? ""),
        phone: String(site.phoneNumber ?? ""),
        distanceM: Math.round(distM),
        slotsAvailable: slotFound && isFuture && nextStart ? formatSlot(nextStart) : null,
        nextAvailable: isFuture && nextStart ? nextDateStr : null,
        bookingUrl: `https://www.bootshearingcare.com/book-a-hearing-test?siteId=${site.siteId}`,
        lat: Number(site.latitude) || undefined,
        lng: Number(site.longitude) || undefined,
        dailySlots,
      });

      if (results.length >= limit) break outer;
    }

    if (!hasMore || data.length < pageSize) break;
    offset += 1;
  }

  results.sort((a, b) => a.distanceM - b.distanceM);
  return results;
}
