import { haversine } from "../haversine";
import { getThreeDayDates } from "../dates";
import type { StoreResult } from "../types";

/* ------------------------------------------------------------------ */
/*  Leightons Hearing — Static provider (~10 UK stores)               */
/*  Leightons is an independent opticians and audiologists chain.     */
/*  We return count=-1 ("available but count unknown") and link to    */
/*  their hearing care page.                                           */
/* ------------------------------------------------------------------ */

interface LeightonsStore {
  address: string;
  postcode: string;
  town: string;
  phone: string;
  lat: number;
  lng: number;
}

const STORES: LeightonsStore[] = [
  { address: "60 High Street, Guildford, GU1 3HE", postcode: "GU1 3HE", town: "Guildford", phone: "01483 456 435", lat: 51.2358, lng: -0.5704 },
  { address: "4 London Road, Camberley, GU15 3HL", postcode: "GU15 3HL", town: "Camberley", phone: "01276 682 080", lat: 51.3387, lng: -0.7414 },
  { address: "48 High Street, Farnham, GU9 7JD", postcode: "GU9 7JD", town: "Farnham", phone: "01252 723 338", lat: 51.2145, lng: -0.7997 },
  { address: "43 High Street, Fleet, GU51 3LA", postcode: "GU51 3LA", town: "Fleet", phone: "01252 614 456", lat: 51.2830, lng: -0.8461 },
  { address: "12 Union Street, Winchester, SO23 8EB", postcode: "SO23 8EB", town: "Winchester", phone: "01962 843 430", lat: 51.0632, lng: -1.3172 },
  { address: "3 High Street, Alton, GU34 1AW", postcode: "GU34 1AW", town: "Alton", phone: "01420 82224", lat: 51.1495, lng: -1.0859 },
  { address: "25 High Street, Haslemere, GU27 2HU", postcode: "GU27 2HU", town: "Haslemere", phone: "01428 642 362", lat: 51.0899, lng: -0.7133 },
  { address: "78 East Street, Horsham, RH12 1HN", postcode: "RH12 1HN", town: "Horsham", phone: "01403 242 230", lat: 51.0664, lng: -0.3245 },
  { address: "16 High Street, Woking, GU21 6BW", postcode: "GU21 6BW", town: "Woking", phone: "01483 773 388", lat: 51.3196, lng: -0.5585 },
  { address: "60 High Street, Basingstoke, RG21 7JL", postcode: "RG21 7JL", town: "Basingstoke", phone: "01256 460 680", lat: 51.2653, lng: -1.0860 },
];

const BOOKING_URL = "https://www.leightons.co.uk/hearing-care";

export async function fetchLeightons(
  lat: number,
  lng: number,
  radius = 16093,
  limit = 10
): Promise<StoreResult[]> {
  const threeDays = getThreeDayDates();

  const nearby = STORES
    .map((store) => {
      const distM = haversine(lat, lng, store.lat, store.lng);
      if (distM > radius) return null;
      return { ...store, distanceM: Math.round(distM) };
    })
    .filter(Boolean)
    .sort((a, b) => a!.distanceM - b!.distanceM)
    .slice(0, limit) as (LeightonsStore & { distanceM: number })[];

  // Static provider — no live availability, so show count=-1
  // ("available but count unknown") for all 3 days
  return nearby.map((store) => ({
    provider: "Leightons Hearing",
    storeName: `Leightons Hearing ${store.town}`,
    address: store.address,
    postcode: store.postcode,
    town: store.town,
    phone: store.phone,
    distanceM: store.distanceM,
    slotsAvailable: null,
    nextAvailable: null,
    bookingUrl: BOOKING_URL,
    lat: store.lat,
    lng: store.lng,
    dailySlots: threeDays.map((date) => ({ date, count: -1 })),
  }));
}
