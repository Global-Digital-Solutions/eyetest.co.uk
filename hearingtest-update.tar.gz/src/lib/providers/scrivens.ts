import { haversine } from "../haversine";
import { getThreeDayDates } from "../dates";
import type { StoreResult } from "../types";

/* ------------------------------------------------------------------ */
/*  Scrivens Hearing — Static provider (~10 UK stores)                 */
/*  Scrivens is an established opticians and hearing care chain.       */
/*  We return count=-1 ("available but count unknown") and link to    */
/*  their hearing care booking page.                                   */
/* ------------------------------------------------------------------ */

interface ScrivensStore {
  address: string;
  postcode: string;
  town: string;
  phone: string;
  lat: number;
  lng: number;
}

const STORES: ScrivensStore[] = [
  { address: "36 High Street, Birmingham, B4 7SL", postcode: "B4 7SL", town: "Birmingham", phone: "0121 236 4000", lat: 52.4796, lng: -1.8940 },
  { address: "123 Corporation Street, Birmingham, B4 6SB", postcode: "B4 6SB", town: "Birmingham (City)", phone: "0121 236 1800", lat: 52.4823, lng: -1.8943 },
  { address: "15 Market Place, Leicester, LE1 5GF", postcode: "LE1 5GF", town: "Leicester", phone: "0116 251 7866", lat: 52.6345, lng: -1.1310 },
  { address: "3 Market Street, Coventry, CV1 1DH", postcode: "CV1 1DH", town: "Coventry", phone: "024 7622 5567", lat: 52.4071, lng: -1.5095 },
  { address: "27 The Parade, Leamington Spa, CV32 4BN", postcode: "CV32 4BN", town: "Leamington Spa", phone: "01926 428 300", lat: 52.2934, lng: -1.5370 },
  { address: "4 Hertford Street, Coventry, CV1 1LF", postcode: "CV1 1LF", town: "Coventry City Centre", phone: "024 7663 3110", lat: 52.4075, lng: -1.5083 },
  { address: "45 High Street, Solihull, B91 3SW", postcode: "B91 3SW", town: "Solihull", phone: "0121 704 0770", lat: 52.4130, lng: -1.7780 },
  { address: "12 Edgbaston Shopping Centre, Birmingham, B15 3ES", postcode: "B15 3ES", town: "Edgbaston", phone: "0121 454 4500", lat: 52.4700, lng: -1.9170 },
  { address: "2 Bell Lane, Wolverhampton, WV1 3PZ", postcode: "WV1 3PZ", town: "Wolverhampton", phone: "01902 425 160", lat: 52.5850, lng: -2.1280 },
  { address: "16 The Parade, Sutton Coldfield, B72 1PD", postcode: "B72 1PD", town: "Sutton Coldfield", phone: "0121 355 7400", lat: 52.5643, lng: -1.8224 },
];

const BOOKING_URL = "https://www.scrivens.com/hearing/";

export async function fetchScrivens(
  lat: number,
  lng: number,
  radius = 16093,
  limit = 10
): Promise<StoreResult[]> {
  const threeDays = getThreeDayDates();

  const nearby = STORES
    .map((store) => {
      const distM = haversine(lat, lng, store.lat, store.lng);
      if (distM > radius) return null;
      return { ...store, distanceM: Math.round(distM) };
    })
    .filter(Boolean)
    .sort((a, b) => a!.distanceM - b!.distanceM)
    .slice(0, limit) as (ScrivensStore & { distanceM: number })[];

  // Static provider — no live availability, so show count=-1
  // ("available but count unknown") for all 3 days
  return nearby.map((store) => ({
    provider: "Scrivens Hearing",
    storeName: `Scrivens Hearing ${store.town}`,
    address: store.address,
    postcode: store.postcode,
    town: store.town,
    phone: store.phone,
    distanceM: store.distanceM,
    slotsAvailable: null,
    nextAvailable: null,
    bookingUrl: BOOKING_URL,
    lat: store.lat,
    lng: store.lng,
    dailySlots: threeDays.map((date) => ({ date, count: -1 })),
  }));
}
