import { haversine } from "../haversine";
import { getThreeDayDates } from "../dates";
import type { StoreResult } from "../types";

/* ------------------------------------------------------------------ */
/*  Specsavers Audiology — Static provider (~20 UK stores)             */
/*  Specsavers uses a store-specific booking flow we can't access       */
/*  without session cookies. We return count=-1 ("available but count  */
/*  unknown") and link to their store hearing page.                    */
/* ------------------------------------------------------------------ */

interface SpecsaversStore {
  slug: string;
  address: string;
  postcode: string;
  town: string;
  phone: string;
  lat: number;
  lng: number;
}

const STORES: SpecsaversStore[] = [
  { slug: "london-oxford-street", address: "100 Oxford Street, London, W1D 1LN", postcode: "W1D 1LN", town: "London", phone: "020 7636 5771", lat: 51.5152, lng: -0.1410 },
  { slug: "birmingham-high-street", address: "32 High Street, Birmingham, B4 7SL", postcode: "B4 7SL", town: "Birmingham", phone: "0121 643 8960", lat: 52.4796, lng: -1.8952 },
  { slug: "manchester-market-street", address: "102 Market Street, Manchester, M1 1PD", postcode: "M1 1PD", town: "Manchester", phone: "0161 832 5588", lat: 53.4809, lng: -2.2376 },
  { slug: "leeds-the-headrow", address: "15 The Headrow, Leeds, LS1 6PU", postcode: "LS1 6PU", town: "Leeds", phone: "0113 243 4000", lat: 53.7998, lng: -1.5490 },
  { slug: "bristol-broadmead", address: "51 Broadmead, Bristol, BS1 3EG", postcode: "BS1 3EG", town: "Bristol", phone: "0117 925 1050", lat: 51.4577, lng: -2.5905 },
  { slug: "edinburgh-princes-street", address: "87-91 Princes Street, Edinburgh, EH2 2ER", postcode: "EH2 2ER", town: "Edinburgh", phone: "0131 226 5532", lat: 55.9513, lng: -3.1883 },
  { slug: "glasgow-argyle-street", address: "120 Argyle Street, Glasgow, G2 8BH", postcode: "G2 8BH", town: "Glasgow", phone: "0141 221 0084", lat: 55.8579, lng: -4.2526 },
  { slug: "liverpool-church-street", address: "63 Church Street, Liverpool, L1 1DD", postcode: "L1 1DD", town: "Liverpool", phone: "0151 709 2505", lat: 53.4058, lng: -2.9876 },
  { slug: "sheffield-fargate", address: "20 Fargate, Sheffield, S1 2HE", postcode: "S1 2HE", town: "Sheffield", phone: "0114 272 6666", lat: 53.3822, lng: -1.4694 },
  { slug: "cardiff-queen-street", address: "26 Queen Street, Cardiff, CF10 2BU", postcode: "CF10 2BU", town: "Cardiff", phone: "029 2039 8220", lat: 51.4816, lng: -3.1791 },
  { slug: "nottingham-clumber-street", address: "15 Clumber Street, Nottingham, NG1 3ED", postcode: "NG1 3ED", town: "Nottingham", phone: "0115 941 8541", lat: 52.9540, lng: -1.1481 },
  { slug: "leicester-gallowtree-gate", address: "23 Gallowtree Gate, Leicester, LE1 5AD", postcode: "LE1 5AD", town: "Leicester", phone: "0116 253 4432", lat: 52.6332, lng: -1.1314 },
  { slug: "southampton-above-bar", address: "3 Above Bar Street, Southampton, SO14 7DX", postcode: "SO14 7DX", town: "Southampton", phone: "023 8022 2088", lat: 50.9051, lng: -1.4043 },
  { slug: "newcastle-northumberland-street", address: "2 Northumberland Street, Newcastle upon Tyne, NE1 7DE", postcode: "NE1 7DE", town: "Newcastle upon Tyne", phone: "0191 232 0022", lat: 54.9773, lng: -1.6136 },
  { slug: "brighton-north-street", address: "26 North Street, Brighton, BN1 1EB", postcode: "BN1 1EB", town: "Brighton", phone: "01273 326 441", lat: 50.8229, lng: -0.1370 },
  { slug: "reading-broad-street", address: "96 Broad Street, Reading, RG1 2AP", postcode: "RG1 2AP", town: "Reading", phone: "0118 958 5880", lat: 51.4567, lng: -0.9720 },
  { slug: "coventry-west-orchards", address: "4-5 West Orchards, Coventry, CV1 1QX", postcode: "CV1 1QX", town: "Coventry", phone: "024 7622 7060", lat: 52.4082, lng: -1.5121 },
  { slug: "stoke-on-trent-hanley", address: "14 Parliament Row, Hanley, Stoke-on-Trent, ST1 1JN", postcode: "ST1 1JN", town: "Stoke-on-Trent", phone: "01782 284 200", lat: 53.0251, lng: -2.1810 },
  { slug: "hull-whitefriargate", address: "21 Whitefriargate, Hull, HU1 2HN", postcode: "HU1 2HN", town: "Hull", phone: "01482 226 020", lat: 53.7446, lng: -0.3376 },
  { slug: "exeter-sidwell-street", address: "14 Sidwell Street, Exeter, EX4 6NN", postcode: "EX4 6NN", town: "Exeter", phone: "01392 422 400", lat: 50.7258, lng: -3.5275 },
];

export async function fetchSpecsavers(
  lat: number,
  lng: number,
  radius = 16093,
  limit = 10
): Promise<StoreResult[]> {
  const threeDays = getThreeDayDates();

  const nearby = STORES
    .map((store) => {
      const distM = haversine(lat, lng, store.lat, store.lng);
      if (distM > radius) return null;
      return { ...store, distanceM: Math.round(distM) };
    })
    .filter(Boolean)
    .sort((a, b) => a!.distanceM - b!.distanceM)
    .slice(0, limit) as (SpecsaversStore & { distanceM: number })[];

  // Static provider — no live availability, so show count=-1
  // ("available but count unknown") for all 3 days
  return nearby.map((store) => ({
    provider: "Specsavers Audiology",
    storeName: `Specsavers Audiology ${store.town}`,
    address: store.address,
    postcode: store.postcode,
    town: store.town,
    phone: store.phone,
    distanceM: store.distanceM,
    slotsAvailable: null,
    nextAvailable: null,
    bookingUrl: `https://www.specsavers.co.uk/stores/${store.slug}/hearing`,
    lat: store.lat,
    lng: store.lng,
    dailySlots: threeDays.map((date) => ({ date, count: -1 })),
  }));
}
