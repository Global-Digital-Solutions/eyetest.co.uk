@AGENTS.md

# Memory

## Owner
Darin Butler (butlerdarin@gmail.com) — Founder, hearingtest.co.uk

## Project
**hearingtest.co.uk** — The UK's authority on booking hearing tests. Aggregates availability from multiple audiologist chains + independents, lets users compare and book online.

## Stack
| Layer | Tech |
|-------|------|
| Framework | Next.js 16.2.9 (App Router, Turbopack) |
| Language | TypeScript |
| Styling | Tailwind CSS v4 |
| Fonts | Inter (body), Outfit (display, `--font-display`) |
| Maps | Mapbox GL |
| Database | Supabase |
| Hosting | Vercel (auto-deploy from GitHub) |
| Repo | github.com/Global-Digital-Solutions/hearingtest.co.uk.git |
| Live URL | https://www.hearingtest.co.uk |
| Vercel URL | https://hearingtest-co-uk.vercel.app |
| Sister site | eyetest.co.uk |

## Critical Next.js 16 Rules
- `params` and `searchParams` are **Promises** — always `await params`
- Read docs at `node_modules/next/dist/docs/` before writing new patterns
- Domain is `www.hearingtest.co.uk` (non-www redirects to www)

## Brand
| Token | Value |
|-------|-------|
| Primary blue | `#2563eb` / `var(--color-primary)` |
| Navy | `#0d1b3e` / `var(--color-navy)` |
| Success green | `#22c55e` / `var(--color-success)` |
| NHS blue | `#005eb8` / `var(--color-nhs-blue)` |

## Data Providers (Live Availability)
| Provider | API | Stores | Status |
|----------|-----|--------|--------|
| Specsavers Audiology | TBC | ~630 | Available |
| Boots Hearingcare | TBC | ~500 | Available |
| Hidden Hearing | TBC | ~300 | Pending |
| Amplifon | TBC | ~120 | Pending |
| Scrivens | TBC | ~50 | Pending |
| Independent audiologists | TBC | varies | Pending |

## Key Types
- `DailySlot`: `{ date: string; count: number }` — count=-1 means "available but count unknown"
- `StoreResult`: individual audiologist location with availability, deep links, and distance
- Search streams NDJSON via `/api/search` route
- postcodes.io for UK postcode geocoding (returns district for area name)

## Content Scale
| Section | Count |
|---------|-------|
| Hearing tests | 18 types |
| Conditions | 22 |
| Guides | 18 |
| Articles | 30 |
| Locations | 127 UK cities/towns |
| Audiologist brands | 12 |
| Brand x Location pages | ~1,244 |
| Find/search queries | 80 |
| **Total pages** | **~1,566** |

## SEO
- JSON-LD schema on all pages (WebSite, Organization, Article, MedicalWebPage, MedicalCondition, LocalBusiness, BreadcrumbList, FAQPage, CollectionPage)
- Author attribution: Organization "hearingtest.co.uk"
- Dynamic sitemap via `src/app/sitemap.ts`
- robots.txt blocks /api/ and /admin/
- llms.txt at /llms.txt
- E-E-A-T optimised for medical content

## Active / Next Phase
| Phase | Status |
|-------|--------|
| Project setup + scaffolding | Done |
| Core site + all page templates | Done |
| Content pages (20 articles, 18 tests, 15 conditions, 10 guides) | Done |
| Location pages (97 UK cities) | Done |
| Brand x Location pages (~1,002) | Done |
| Search query pages (80 long-tail SEO) | Done |
| Get-Listed form | Done |
| At-home hearing tests + offers pages | Done |
| SEO (sitemap, robots.txt, llms.txt, JSON-LD) | Done |
| **Provider integrations (Specsavers, Boots)** | **Next** |
| Internal linking optimisation | Planned |
| Get-Listed email API | Planned |
| Audiologist subscription + Stripe billing | Planned |

## Preferences
- Git workflow: commit from workspace, push from Mac terminal
- Commit messages: descriptive, multi-line when needed
- Always verify builds before committing
- Mobile-first design approach

Full project details: memory/projects/hearingtest.md
Architecture details: memory/context/architecture.md
