# hearingtest.co.uk

**Owner:** Darin Butler (butlerdarin@gmail.com)
**Company:** Global Digital Solutions Limited
**Status:** Pre-build
**Domain:** www.hearingtest.co.uk (primary), hearingtest-co-uk.vercel.app (Vercel preview)
**Repo:** github.com/Global-Digital-Solutions/hearingtest.co.uk.git
**Sister site:** eyetest.co.uk

## What It Is

The UK's authority on booking hearing tests. Users enter a postcode, the site queries multiple audiologist APIs in real-time (streaming NDJSON), and shows available appointment slots from Specsavers Audiology, Boots Hearingcare, and other hearing care providers. Users can compare prices and availability, then book directly on the audiologist's site via deep links.

Follows the same proven architecture as the sister site eyetest.co.uk — postcode search, streaming results, deep-link booking — adapted for the hearing care market.

## Business Model (Current)

Free for users. Revenue model TBD — planned audiologist subscription with Stripe billing for featured placement in search results (same model as eyetest.co.uk).

## Next Phase: Audiologist Subscription Model

Planned features (mirroring eyetest.co.uk approach):
- **Value prop:** Featured placement in search results
- **Pricing:** Flat monthly fee OR annual fee at discounted rate
- **Target:** Any audiologist, including new ones not yet on the platform
- **Approach:** Full self-service portal (signup, billing, manage listing)
- **Payment:** Stripe integration
- **Scope:** Audiologist can sign up, enter details, choose plan, pay, get featured

## Technical Architecture

### Framework
- Next.js 16.2.9 with App Router (NOT Pages Router)
- TypeScript throughout
- Tailwind CSS v4 for styling
- Turbopack for dev server

### CRITICAL: Next.js 16 Breaking Changes
- `params` and `searchParams` are Promises — MUST use `await params`
- Always read `node_modules/next/dist/docs/` before writing new code patterns
- AGENTS.md enforces this rule

### Search Flow
1. User enters postcode on homepage (`src/components/Hero.tsx`)
2. Redirects to `/search?postcode=XX`
3. `SearchResults.tsx` component streams from `/api/search` route
4. API route (`src/app/api/search/route.ts`):
   - Geocodes postcode via postcodes.io
   - Queries all providers in parallel (Specsavers, Boots Hearingcare, etc.)
   - Streams NDJSON results back: meta event -> store events -> done event
5. Frontend deduplicates, sorts, and displays results with StoreCards
6. Deep links take users directly to audiologist booking pages

### Providers
| Provider | File | API Type | Deep Link | Stores | Status |
|----------|------|----------|-----------|--------|--------|
| Specsavers Audiology | `src/lib/providers/specsavers.ts` | TBC | TBC | ~630 | Available |
| Boots Hearingcare | `src/lib/providers/boots-hearingcare.ts` | TBC | TBC | ~500 | Available |
| Hidden Hearing | `src/lib/providers/hidden-hearing.ts` | TBC | TBC | ~300 | Pending |
| Amplifon | `src/lib/providers/amplifon.ts` | TBC | TBC | ~120 | Pending |
| Scrivens | `src/lib/providers/scrivens.ts` | TBC | TBC | ~50 | Pending |
| Independent audiologists | `src/lib/providers/independents.ts` | TBC | TBC | varies | Pending |

### Data Files
| File | Contains |
|------|----------|
| `src/data/hearing-tests.ts` | 18 hearing test types with full clinical content |
| `src/data/hearing-health.ts` | 15 conditions + 10 guides, relatedTests per condition |
| `src/data/articles.ts` | 6 editorial articles |
| `src/data/locations.ts` | 97 UK cities with lat/lng, postcodes, nearbyAreas |
| `src/data/audiologists.ts` | 12 audiologist brands with store counts, descriptions |
| `src/data/search-queries.ts` | 43 SEO search query pages |
| `src/data/offers.ts` | Current audiologist offers/deals |

### Key Components
| Component | Purpose |
|-----------|---------|
| `Header.tsx` | Main nav with mega menus |
| `Footer.tsx` | SEO footer with all links |
| `Hero.tsx` | Homepage hero with postcode search |
| `SearchResults.tsx` | Main search results with streaming, progress panel, store cards |
| `PageHero.tsx` | Reusable hero for content pages with breadcrumbs |
| `ResultCard.tsx` / `StoreCard` | Individual audiologist result cards |
| `GetListedForm.tsx` | Audiologist signup form — booking system dropdown, location count ranges, API submission to `/api/get-listed` |
| `AtHomeBookingForm.tsx` | At-home hearing test enquiry form — submits to `/api/at-home-enquiry` |

### Pages Structure
```
/ — Homepage (Hero + search + articles + CTA)
/search — Search results (dynamic, streams from API)
/hearing-tests — Listing + /hearing-tests/[slug] (18 types)
/hearing-health — Hub + /conditions/[slug] (15) + /guides/[slug] (10)
/articles — Listing + /articles/[slug] (6)
/audiologists — Listing + /audiologists/[slug] (12 brands)
/audiologists/[brand]/[location] — Brand x city combos (~1,164)
/locations — Listing + /locations/[city] (97)
/find — Listing + /find/[slug] (43 SEO queries)
/offers — Current deals
/at-home-hearing-tests — Home visit info
/about, /privacy, /terms, /disclaimer — Legal/info
/get-listed — Audiologist signup CTA
/admin — Admin dashboard (protected)
```

### API Routes
| Route | Purpose |
|-------|---------|
| `/api/search` | Main search — streams NDJSON results from all providers |
| `/api/get-listed` | POST: Get-Listed form submissions via Nodemailer + Gmail SMTP -> hello@hearingtest.co.uk |
| `/api/at-home-enquiry` | POST: At-home hearing test enquiry form via Nodemailer + Gmail SMTP -> hello@hearingtest.co.uk |
| `/api/admin/featured` | Admin: manage featured audiologists |
| `/api/admin/providers` | Admin: provider status |
| `/api/admin/stores` | Admin: store management |

### Infrastructure
| Service | Purpose |
|---------|---------|
| Vercel | Hosting, auto-deploy from GitHub main branch |
| Supabase | Database (admin features, future subscriptions) |
| Mapbox | Store location maps |
| postcodes.io | UK postcode geocoding |

## Design System

### Colors
- Primary blue: `#2563eb` (`--color-primary`)
- Primary dark: darker blue (`--color-primary-dark`)
- Primary light: lighter blue (`--color-primary-light`)
- Navy: `#0d1b3e` (`--color-navy`)
- Navy light: `--color-navy-light`
- Success green: `#22c55e` (`--color-success`)
- NHS blue: `#005eb8` (`--color-nhs-blue`)

### Typography
- Body: Inter font
- Display/headings: Outfit font (`--font-display`)
- Use `style={{ fontFamily: "var(--font-display)" }}` on headings

### UI Patterns
- Rounded corners: `rounded-2xl` on cards
- Shadows: `shadow-sm` default, `hover:shadow-md` on hover
- Cards: white bg, `border border-gray-100`, hover border blue
- CTAs: blue bg, white text, rounded-full, hover shadow
- PageHero: navy gradient bg, white text, breadcrumbs
- Mobile-first responsive design throughout

## SEO Implementation

### Schema Types Used
WebSite, Organization, AboutPage, WebPage, CollectionPage, FAQPage, MedicalWebPage, MedicalCondition, Article, LocalBusiness, MedicalBusiness, BreadcrumbList

### Author Attribution
All content pages have:
```typescript
author: {
  "@type": "Organization",
  name: "hearingtest.co.uk",
  url: "https://www.hearingtest.co.uk",
}
```

### Sitemap
Dynamic via `src/app/sitemap.ts` — auto-generates from all data files (~1,380 URLs)

### Domain
Primary: `www.hearingtest.co.uk` (non-www redirects via Vercel)
All canonical URLs, OG URLs, and schema URLs use `www.hearingtest.co.uk`

## Build History

| Date | Milestone |
|------|-----------|
| 2026-06-18 | Project planning and memory files created |
| Next | Project scaffolding: Next.js 16.2.9, Tailwind CSS v4, TypeScript, Supabase, Mapbox |

## Pending Work
1. **Project scaffolding** — Next.js 16.2.9 setup with App Router, Tailwind CSS v4, TypeScript config
2. **Provider integrations** — Specsavers Audiology and Boots Hearingcare API research and integration
3. **Content creation** — 18 hearing test types, 15 conditions, 10 guides, 6 articles
4. **Location pages** — 97 UK cities with audiologist data
5. **Brand x Location pages** — ~1,164 combination pages for SEO
6. **Search implementation** — NDJSON streaming search with provider aggregation
7. **Get-Listed form** — Audiologist signup with email API
8. **SEO audit** — Schema markup, sitemap, internal linking, E-E-A-T optimisation
9. **Audiologist subscription + Stripe** — Featured placement, self-service portal, monthly/annual billing
