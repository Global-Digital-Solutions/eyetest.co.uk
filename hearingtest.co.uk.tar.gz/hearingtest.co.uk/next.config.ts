import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async redirects() {
    return [
      {
        source: "/blog",
        destination: "/articles",
        permanent: true,
      },
      {
        source: "/blog/:slug",
        destination: "/articles/:slug",
        permanent: true,
      },
      {
        source: "/contact",
        destination: "/about",
        permanent: true,
      },
      {
        source: "/hearing-aids",
        destination: "/",
        permanent: true,
      },
      {
        source: "/hearing-aids/:path*",
        destination: "/",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
