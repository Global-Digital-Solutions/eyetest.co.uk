import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "About hearingtest.co.uk | Find & Book Hearing Tests",
  description:
    "hearingtest.co.uk helps people across the UK find and book hearing tests. Compare audiologists, check availability, and book online in seconds. Built by Global Digital Solutions Limited.",
  openGraph: {
    title: "About hearingtest.co.uk | Find & Book Hearing Tests",
    description:
      "hearingtest.co.uk helps people across the UK find and book hearing tests. Compare audiologists, check availability, and book online in seconds.",
    url: "https://www.hearingtest.co.uk/about",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/about",
  },
};

const stats = [
  { label: "Audiologists compared", value: "100+" },
  { label: "UK cities covered", value: "97" },
  { label: "Hearing test types", value: "18" },
  { label: "Audiologist brands", value: "12" },
];

const howItWorks = [
  {
    step: 1,
    title: "Enter your postcode",
    description:
      "Tell us where you are and we will find audiologists near you with real-time availability.",
  },
  {
    step: 2,
    title: "Compare audiologists",
    description:
      "See prices, services, distances, and available appointments side by side to find the best fit.",
  },
  {
    step: 3,
    title: "Book online",
    description:
      "Choose a time that suits you and book directly with your chosen audiologist in seconds.",
  },
];

export default function AboutPage() {
  const orgJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "hearingtest.co.uk",
    url: "https://www.hearingtest.co.uk",
    logo: "https://www.hearingtest.co.uk/logo.png",
    description:
      "The UK's authority on finding and booking hearing tests. Compare audiologists, check availability, and book online.",
    foundingDate: "2019",
    founder: {
      "@type": "Organization",
      name: "Global Digital Solutions Limited",
    },
    contactPoint: {
      "@type": "ContactPoint",
      email: "info@hearingtest.co.uk",
      contactType: "customer service",
    },
    sameAs: [],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
        />

        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "About" },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            About hearingtest.co.uk
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/90 max-w-3xl">
            Helping people across the UK find and book hearing tests — quickly,
            easily, and for free.
          </p>
        </PageHero>

        {/* Mission */}
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <h2
            className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Our mission
          </h2>
          <div className="mt-6 space-y-4 text-gray-700 text-lg leading-relaxed">
            <p>
              Hearing loss affects over <strong>12 million people</strong> in the
              UK, yet many delay getting their hearing tested — often because
              they don&apos;t know where to go, how much it will cost, or
              what&apos;s available near them.
            </p>
            <p>
              <strong>hearingtest.co.uk</strong> was built to solve that problem.
              We aggregate hearing test availability from audiologist chains and
              independent providers across the country, making it easy to
              compare services and book an appointment online.
            </p>
            <p>
              Whether you&apos;re looking for a free NHS hearing test, a
              same-day appointment at a high-street audiologist, or a specialist
              tinnitus assessment, we help you find the right provider in
              seconds.
            </p>
          </div>
        </section>

        {/* Stats */}
        <section className="bg-gray-50 border-t border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
            <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <p
                    className="text-4xl md:text-5xl font-bold text-[var(--color-primary)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {stat.value}
                  </p>
                  <p className="mt-2 text-sm md:text-base text-gray-600">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <h2
            className="text-2xl md:text-3xl font-bold text-[var(--color-navy)] text-center"
            style={{ fontFamily: "var(--font-display)" }}
          >
            How it works
          </h2>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {howItWorks.map((item) => (
              <div key={item.step} className="text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[var(--color-primary)] text-white text-xl font-bold">
                  {item.step}
                </div>
                <h3
                  className="mt-4 text-lg font-semibold text-[var(--color-navy)]"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {item.title}
                </h3>
                <p className="mt-2 text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link
              href="/search"
              className="inline-flex items-center justify-center rounded-full bg-[var(--color-primary)] px-8 py-3 text-base font-semibold text-white shadow-lg transition hover:bg-[var(--color-primary)]/90"
            >
              Find hearing tests near you
              <svg
                className="ml-2 h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </Link>
          </div>
        </section>

        {/* Company info */}
        <section className="bg-gray-50 border-t border-gray-200">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
            <h2
              className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              About our company
            </h2>
            <div className="mt-6 space-y-4 text-gray-700 text-lg leading-relaxed">
              <p>
                hearingtest.co.uk is built and operated by{" "}
                <strong>Global Digital Solutions Limited</strong>, a UK-based
                technology company founded in 2019. We specialise in building
                comparison and booking platforms that help people access
                essential health services.
              </p>
              <p>
                Our team combines expertise in healthcare technology, web
                development, and user experience to create tools that make a
                real difference in people&apos;s lives. We believe that finding
                and booking a hearing test should be as simple as booking a
                restaurant or a hotel.
              </p>
              <p>
                We are committed to providing accurate, impartial information
                and do not favour any particular provider. Our goal is to help
                you find the best hearing care option for your needs, whatever
                your budget or location.
              </p>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <h2
            className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Get in touch
          </h2>
          <div className="mt-6 space-y-4 text-gray-700 text-lg leading-relaxed">
            <p>
              We&apos;d love to hear from you — whether you have a question,
              feedback, or would like to partner with us.
            </p>
            <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
              <div className="flex items-center gap-3">
                <svg
                  className="h-6 w-6 text-[var(--color-primary)]"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75"
                  />
                </svg>
                <a
                  href="mailto:info@hearingtest.co.uk"
                  className="text-[var(--color-primary)] font-medium hover:underline"
                >
                  info@hearingtest.co.uk
                </a>
              </div>
              <p className="mt-3 text-sm text-gray-500">
                Global Digital Solutions Limited
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
