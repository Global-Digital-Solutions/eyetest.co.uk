import { NextRequest } from "next/server";
import { geocodePostcode } from "@/lib/postcodes";

const enc = new TextEncoder();

function line(data: object): Uint8Array {
  return enc.encode(JSON.stringify(data) + "\n");
}

export async function GET(req: NextRequest) {
  const postcode = req.nextUrl.searchParams.get("postcode");
  if (!postcode) {
    return new Response(JSON.stringify({ error: "postcode is required" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  let geo;
  try {
    geo = await geocodePostcode(postcode);
  } catch (err) {
    return new Response(
      JSON.stringify({
        error: err instanceof Error ? err.message : "Invalid postcode",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }

  const { lat, lng } = geo;

  const stream = new ReadableStream({
    async start(controller) {
      // ── Meta event ─────────────────────────────────────────────────────
      controller.enqueue(
        line({
          type: "meta",
          postcode: geo.postcode,
          lat,
          lng,
          district: geo.district,
        })
      );

      // ── Provider fetches ───────────────────────────────────────────────
      // TODO: Add hearing test provider integrations
      // Each provider calls runProvider(name, fetchFn) and streams results:
      //
      // Specsavers Audiology — free hearing tests at 600+ stores
      // Boots Hearingcare — hearing tests and hearing aids
      // Hidden Hearing — specialist hearing care clinics
      // The Hearing Care Partnership (THCP) — independent audiology practices
      // Scrivens — opticians & hearing care
      // Amplifon — global hearing aid provider
      // Bayfields — opticians & audiologists
      // Leightons — opticians & hearing care
      // Bloom Hearing Specialists
      // David Clulow — opticians & hearing
      // Costco Hearing Aid Centre
      // Independent audiologists

      // ── Done event ─────────────────────────────────────────────────────
      controller.enqueue(line({ type: "done" }));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain",
      "Cache-Control": "no-cache",
      "X-Accel-Buffering": "no",
    },
  });
}
