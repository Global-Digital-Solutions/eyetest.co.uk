import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import { articles } from "@/data/articles";

export const metadata: Metadata = {
  title: "Articles — Hearing Health News & Insights | hearingtest.co.uk",
  description:
    "Read the latest articles on hearing health, hearing loss statistics, hearing aid technology, workplace hearing safety, and NHS vs private hearing care in the UK.",
  openGraph: {
    title: "Articles — Hearing Health News & Insights | hearingtest.co.uk",
    description:
      "Read the latest articles on hearing health, hearing loss statistics, hearing aid technology, and more.",
    url: "https://www.hearingtest.co.uk/articles",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/articles",
  },
};

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

const categoryLabels: Record<string, string> = {
  research: "Research",
  health: "Health",
  guides: "Guides",
  technology: "Technology",
  workplace: "Workplace",
};

export default function ArticlesPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Articles — Hearing Health News & Insights",
    description:
      "The latest articles on hearing health, hearing tests, and hearing care in the UK.",
    url: "https://www.hearingtest.co.uk/articles",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    mainEntity: {
      "@type": "ItemList",
      numberOfItems: articles.length,
      itemListElement: articles.map((article, index) => ({
        "@type": "ListItem",
        position: index + 1,
        url: `https://www.hearingtest.co.uk/articles/${article.slug}`,
        name: article.title,
      })),
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Articles" },
          ]}
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Articles
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/90 max-w-3xl">
            Evidence-based articles on hearing health, hearing loss, hearing
            aid technology, workplace safety, and NHS hearing services in
            the UK.
          </p>
        </PageHero>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {articles.map((article) => (
              <Link
                key={article.slug}
                href={`/articles/${article.slug}`}
                className="group flex flex-col rounded-2xl border border-gray-200 bg-white shadow-sm overflow-hidden transition hover:shadow-md hover:border-[var(--color-primary)]"
              >
                {/* Image placeholder */}
                <div className="aspect-[16/9] bg-gradient-to-br from-[var(--color-primary)]/10 to-[var(--color-navy)]/10 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg
                      className="h-12 w-12 text-[var(--color-primary)]/30"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={1}
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909M3.75 21h16.5A2.25 2.25 0 0 0 22.5 18.75V5.25A2.25 2.25 0 0 0 20.25 3H3.75A2.25 2.25 0 0 0 1.5 5.25v13.5A2.25 2.25 0 0 0 3.75 21Z"
                      />
                    </svg>
                  </div>
                </div>

                <div className="flex flex-1 flex-col p-6">
                  {/* Category & meta */}
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span className="inline-flex items-center rounded-full bg-[var(--color-primary)]/10 px-2.5 py-0.5 font-medium text-[var(--color-primary)]">
                      {categoryLabels[article.category] || article.category}
                    </span>
                    <span>{article.readTime}</span>
                  </div>

                  <h2
                    className="mt-3 text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors line-clamp-2"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {article.title}
                  </h2>

                  <p className="mt-2 text-sm text-gray-600 line-clamp-3 flex-1">
                    {article.excerpt}
                  </p>

                  <div className="mt-4 flex items-center justify-between">
                    <time
                      dateTime={article.publishedDate}
                      className="text-xs text-gray-400"
                    >
                      {formatDate(article.publishedDate)}
                    </time>
                    <span className="inline-flex items-center text-sm font-medium text-[var(--color-primary)]">
                      Read article
                      <svg
                        className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                        />
                      </svg>
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
