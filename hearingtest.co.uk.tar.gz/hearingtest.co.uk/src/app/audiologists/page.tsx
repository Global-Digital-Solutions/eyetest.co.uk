import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  audiologists,
  getAvailableAudiologists,
  type AudiologistBrand,
} from "@/data/audiologists";

// ---------------------------------------------------------------------------
// SEO metadata
// ---------------------------------------------------------------------------

export const metadata: Metadata = {
  title:
    "Compare UK Audiologists — Find the Best Hearing Test Near You | hearingtest.co.uk",
  description:
    "Compare leading UK audiologist chains and hearing care providers side by side. See services, prices, NHS availability, and store locations for Specsavers, Boots Hearingcare, Hidden Hearing, and more. Book your hearing test online.",
  keywords: [
    "UK audiologists",
    "compare audiologists",
    "best audiologists UK",
    "hearing test near me",
    "NHS hearing test",
    "Specsavers hearing test",
    "Boots Hearingcare",
    "Hidden Hearing",
    "hearing care providers",
  ],
  openGraph: {
    title: "Compare UK Audiologists — Find the Best Hearing Test Near You",
    description:
      "Compare leading UK audiologist chains side by side. See services, prices, NHS availability, and book your hearing test online.",
    url: "https://www.hearingtest.co.uk/audiologists",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/audiologists",
  },
};

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default function AudiologistsPage() {
  const available = audiologists.filter((a) => a.available);
  const unavailable = audiologists.filter((a) => !a.available);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Compare UK Audiologists — Find the Best Hearing Test Near You",
    description:
      "Compare leading UK audiologist chains side by side. See services, prices, NHS availability, and book your hearing test online.",
    url: "https://www.hearingtest.co.uk/audiologists",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    mainEntity: {
      "@type": "ItemList",
      itemListElement: available.map((a, i) => ({
        "@type": "ListItem",
        position: i + 1,
        item: {
          "@type": "Organization",
          name: a.name,
          url: `https://www.hearingtest.co.uk/audiologists/${a.slug}`,
          numberOfEmployees: {
            "@type": "QuantitativeValue",
            name: "UK locations",
            value: a.storeCount,
          },
        },
      })),
    },
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Audiologists",
        item: "https://www.hearingtest.co.uk/audiologists",
      },
    ],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />

        {/* Hero */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Audiologists" },
          ]}
        >
          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Compare UK Audiologists
          </h1>
          <p className="text-lg sm:text-xl text-white/70 max-w-2xl mx-auto">
            Find the best hearing test near you. Compare services, prices, and
            NHS availability across leading hearing care providers, then book
            online in seconds.
          </p>
        </PageHero>

        {/* Featured audiologists grid */}
        <section className="max-w-7xl mx-auto px-4 py-16 sm:py-20">
          <div className="text-center mb-12">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Featured Audiologists
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Book hearing test appointments with these audiologists directly
              through hearingtest.co.uk. Compare prices and availability in your
              area.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {available.map((audiologist) => (
              <Link
                key={audiologist.slug}
                href={`/audiologists/${audiologist.slug}`}
                className="group relative bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden"
              >
                {/* Brand accent bar */}
                <div
                  className="h-1.5 w-full"
                  style={{ backgroundColor: audiologist.brandColor }}
                />

                <div className="p-6">
                  {/* Header row */}
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3
                        className="text-lg font-bold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {audiologist.name}
                      </h3>
                      <p className="text-sm text-gray-500 mt-0.5">
                        Est. {audiologist.founded}
                      </p>
                    </div>
                    {audiologist.nhsAvailable && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[var(--color-nhs-blue)]/10 px-2.5 py-1 text-xs font-medium text-[var(--color-nhs-blue)]">
                        <svg
                          className="w-3.5 h-3.5"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path
                            fillRule="evenodd"
                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                            clipRule="evenodd"
                          />
                        </svg>
                        NHS
                      </span>
                    )}
                  </div>

                  {/* Stats row */}
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1.5">
                      <svg
                        className="w-4 h-4 text-gray-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      {audiologist.storeCount.toLocaleString()} locations
                    </span>
                    <span className="flex items-center gap-1.5">
                      <svg
                        className="w-4 h-4 text-gray-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
                        />
                      </svg>
                      {audiologist.priceRange}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-gray-500 mb-4 line-clamp-2">
                    {audiologist.description}
                  </p>

                  {/* Services preview */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {audiologist.services.slice(0, 4).map((service) => (
                      <span
                        key={service}
                        className="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-600"
                      >
                        {service}
                      </span>
                    ))}
                    {audiologist.services.length > 4 && (
                      <span className="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-500">
                        +{audiologist.services.length - 4} more
                      </span>
                    )}
                  </div>

                  {/* CTA */}
                  <span className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--color-primary)] group-hover:gap-3 transition-all">
                    View details
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M17 8l4 4m0 0l-4 4m4-4H3"
                      />
                    </svg>
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Coming soon */}
        {unavailable.length > 0 && (
          <section className="bg-gray-50 border-y border-gray-200">
            <div className="max-w-7xl mx-auto px-4 py-16 sm:py-20">
              <div className="text-center mb-12">
                <h2
                  className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Coming Soon
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  We&apos;re working on adding these hearing care providers to
                  hearingtest.co.uk. Check back soon for availability.
                </p>
              </div>

              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {unavailable.map((audiologist) => (
                  <Link
                    key={audiologist.slug}
                    href={`/audiologists/${audiologist.slug}`}
                    className="relative bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden opacity-60 hover:opacity-80 transition-opacity"
                  >
                    <div className="h-1.5 w-full bg-gray-300" />
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3
                            className="text-lg font-bold text-gray-400"
                            style={{ fontFamily: "var(--font-display)" }}
                          >
                            {audiologist.name}
                          </h3>
                          <p className="text-sm text-gray-400 mt-0.5">
                            {audiologist.storeCount.toLocaleString()} locations
                            across the UK
                          </p>
                        </div>
                        <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-1 text-xs font-medium text-gray-400">
                          Coming soon
                        </span>
                      </div>
                      <p className="text-sm text-gray-400">
                        No availability &mdash; check back soon
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Why Compare */}
        <section className="max-w-7xl mx-auto px-4 py-16 sm:py-20">
          <div className="text-center mb-12">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Why Compare on hearingtest.co.uk?
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We make finding the right audiologist simple, fast, and free.
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: "M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z",
                title: "Side-by-Side Pricing",
                description:
                  "Compare NHS and private hearing test prices across multiple audiologists in one place. No hidden fees.",
              },
              {
                icon: "M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z M15 11a3 3 0 11-6 0 3 3 0 016 0z",
                title: "Find Locations Near You",
                description:
                  "Search by postcode to see which audiologists have locations nearby, with real-time availability.",
              },
              {
                icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
                title: "NHS Availability",
                description:
                  "Instantly see which audiologists offer free NHS hearing tests and check if you qualify.",
              },
              {
                icon: "M13 10V3L4 14h7v7l9-11h-7z",
                title: "Book Online Instantly",
                description:
                  "Choose your preferred date and time, and book your hearing test appointment in seconds.",
              },
              {
                icon: "M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z",
                title: "Trusted Information",
                description:
                  "Read honest details about each audiologist's services, technology, and patient experience.",
              },
              {
                icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
                title: "Same-Day Appointments",
                description:
                  "Filter for same-day or next-day availability when you need an urgent hearing test.",
              },
            ].map((feature) => (
              <div key={feature.title} className="text-center p-6">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[var(--color-primary)]/10 text-[var(--color-primary)] mb-4">
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d={feature.icon}
                    />
                  </svg>
                </div>
                <h3
                  className="text-lg font-semibold text-[var(--color-navy)] mb-2"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-primary)] to-[#0b8a86]" />
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-white rounded-full opacity-5 blur-3xl" />

          <div className="relative max-w-3xl mx-auto px-4 py-16 sm:py-20 text-center">
            <h2
              className="text-2xl sm:text-3xl font-bold text-white mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to Find Your Audiologist?
            </h2>
            <p className="text-lg text-white/80 mb-8">
              Enter your postcode to compare prices and availability from
              audiologists near you.
            </p>
            <Link
              href="/search"
              className="inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-[var(--color-primary)] shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              Search by Postcode
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
