import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "Medical Disclaimer | hearingtest.co.uk",
  description:
    "Important medical disclaimer for hearingtest.co.uk. Our website provides general hearing health information and is not a substitute for professional medical advice.",
  openGraph: {
    title: "Medical Disclaimer | hearingtest.co.uk",
    description:
      "Important medical disclaimer for hearingtest.co.uk. Our website provides general hearing health information and is not a substitute for professional medical advice.",
    url: "https://www.hearingtest.co.uk/disclaimer",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/disclaimer",
  },
};

export default function DisclaimerPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Medical Disclaimer" },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Medical Disclaimer
          </h1>
          <p className="mt-4 text-lg text-white/90">
            Important information about the content on this website
          </p>
        </PageHero>

        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          {/* Key notice */}
          <div className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-6 md:p-8">
            <div className="flex items-start gap-4">
              <svg
                className="h-8 w-8 shrink-0 text-amber-600 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                />
              </svg>
              <div>
                <h2
                  className="text-xl font-bold text-amber-900"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  This website does not provide medical advice
                </h2>
                <p className="mt-2 text-amber-800 leading-relaxed">
                  The information on hearingtest.co.uk is provided for general
                  informational purposes only and is not intended as a
                  substitute for professional medical advice, diagnosis, or
                  treatment. Always seek the advice of a qualified audiologist,
                  GP, or other healthcare professional regarding any medical
                  condition or hearing concern.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-10 prose prose-lg max-w-none prose-headings:font-semibold prose-headings:text-[var(--color-navy)]">
            <h2 style={{ fontFamily: "var(--font-display)" }}>
              General health information
            </h2>
            <p>
              hearingtest.co.uk provides general health information about
              hearing tests, hearing loss, ear conditions, and related topics.
              This content is written and reviewed for accuracy, but it:
            </p>
            <ul>
              <li>
                Is <strong>not</strong> a substitute for professional medical
                advice from a qualified audiologist, ENT specialist, or GP
              </li>
              <li>
                May not reflect the very latest clinical guidance or research
                findings
              </li>
              <li>
                Should not be used to self-diagnose any hearing condition or
                medical problem
              </li>
              <li>
                Cannot account for your individual medical history,
                circumstances, or risk factors
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              Always consult a professional
            </h2>
            <p>
              If you have concerns about your hearing, you should always
              consult a qualified healthcare professional. This includes:
            </p>
            <ul>
              <li>
                <strong>Audiologists</strong> registered with the Health and
                Care Professions Council (HCPC) for hearing assessments and
                hearing aid fitting
              </li>
              <li>
                <strong>Hearing aid dispensers</strong> registered with the HCPC
                for hearing aid services
              </li>
              <li>
                <strong>Your GP</strong> for referrals to NHS audiology services
                or ENT specialists
              </li>
              <li>
                <strong>ENT specialists</strong> for complex ear, nose, and
                throat conditions
              </li>
            </ul>
            <p>
              Never disregard professional medical advice, delay seeking
              medical attention, or discontinue treatment because of something
              you have read on this website.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              Emergency hearing loss
            </h2>
            <div className="not-prose rounded-xl border border-red-200 bg-red-50 p-6 my-6">
              <h3
                className="text-lg font-bold text-red-900"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Sudden hearing loss is a medical emergency
              </h3>
              <p className="mt-2 text-red-800">
                If you experience a sudden loss of hearing in one or both ears
                — particularly over hours or days — seek immediate medical
                attention. Contact your GP for an emergency appointment, call
                NHS 111, or attend A&amp;E. Treatment with steroids is most
                effective when started within 24 to 72 hours.
              </p>
            </div>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              Comparison service, not a healthcare provider
            </h2>
            <p>
              hearingtest.co.uk is a <strong>comparison and information
              service</strong>. We help you find and compare hearing test
              providers across the UK, but we do not:
            </p>
            <ul>
              <li>Provide hearing tests or audiological assessments</li>
              <li>Diagnose or treat hearing conditions</li>
              <li>Dispense hearing aids or other medical devices</li>
              <li>Offer clinical or therapeutic services of any kind</li>
              <li>
                Employ or supervise the audiologists or hearing care
                professionals listed on our website
              </li>
            </ul>
            <p>
              When you book an appointment through our website, your
              relationship is with the third-party hearing care provider, not
              with hearingtest.co.uk. Each provider is responsible for the
              quality and safety of their own services.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              Content accuracy and review
            </h2>
            <p>
              The health information on our website is researched and reviewed
              for accuracy. However, medical knowledge evolves continuously,
              and we cannot guarantee that all information reflects the most
              current clinical evidence at any given time.
            </p>
            <p>
              We regularly review and update our content, but the date an
              article was last reviewed does not necessarily mean all
              information in it is current. If you notice any information that
              appears inaccurate or outdated, please contact us at{" "}
              <a href="mailto:info@hearingtest.co.uk">
                info@hearingtest.co.uk
              </a>{" "}
              so we can review it.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              Third-party provider information
            </h2>
            <p>
              Information about hearing test providers — including pricing,
              availability, services offered, and locations — is sourced from
              third parties and may change without notice. We make reasonable
              efforts to keep this information accurate, but we cannot
              guarantee it. Always confirm details directly with your chosen
              provider before attending an appointment.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              No professional relationship
            </h2>
            <p>
              Using this website does not create a patient-provider
              relationship, a professional-client relationship, or any other
              form of professional relationship between you and
              hearingtest.co.uk or Global Digital Solutions Limited.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>Contact</h2>
            <p>
              If you have any questions about this disclaimer, please contact
              us:
            </p>
            <ul>
              <li>
                Email:{" "}
                <a href="mailto:info@hearingtest.co.uk">
                  info@hearingtest.co.uk
                </a>
              </li>
              <li>Company: Global Digital Solutions Limited</li>
            </ul>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
