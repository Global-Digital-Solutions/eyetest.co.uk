import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  getAllSearchQuerySlugs,
  getSearchQueryBySlug,
  searchQueries,
} from "@/data/search-queries";

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateStaticParams() {
  return getAllSearchQuerySlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const query = getSearchQueryBySlug(slug);

  if (!query) {
    return { title: "Not Found | hearingtest.co.uk" };
  }

  return {
    title: `${query.title} | hearingtest.co.uk`,
    description: query.shortDescription,
    openGraph: {
      title: `${query.title} | hearingtest.co.uk`,
      description: query.shortDescription,
      url: `https://www.hearingtest.co.uk/find/${query.slug}`,
      siteName: "hearingtest.co.uk",
      type: "article",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/find/${query.slug}`,
    },
  };
}

export default async function SearchQueryPage({ params }: Props) {
  const { slug } = await params;
  const query = getSearchQueryBySlug(slug);

  if (!query) {
    notFound();
  }

  const relatedQueries = query.relatedQueries
    .map((relSlug) => searchQueries.find((q) => q.slug === relSlug))
    .filter(Boolean);

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: query.faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Find",
        item: "https://www.hearingtest.co.uk/find",
      },
      {
        "@type": "ListItem",
        position: 3,
        name: query.title,
        item: `https://www.hearingtest.co.uk/find/${query.slug}`,
      },
    ],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />

        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Find", href: "/find" },
            { label: query.title },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {query.title}
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/90 max-w-3xl">
            {query.shortDescription}
          </p>
        </PageHero>

        {/* Content */}
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div
            className="prose prose-lg max-w-none prose-headings:font-semibold prose-headings:text-[var(--color-navy)] prose-a:text-[var(--color-primary)] prose-a:no-underline hover:prose-a:underline prose-strong:text-[var(--color-navy)]"
            dangerouslySetInnerHTML={{ __html: query.content }}
          />

          {/* CTA */}
          <div className="mt-10 rounded-2xl bg-gradient-to-br from-[var(--color-primary)] to-[var(--color-navy)] p-8 text-center">
            <h2
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              {query.ctaText}
            </h2>
            <p className="mt-2 text-white/80">
              Compare audiologists and book your hearing test online today.
            </p>
            <Link
              href="/search"
              className="mt-6 inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-base font-semibold text-[var(--color-primary)] shadow-lg transition hover:bg-gray-50"
            >
              Search now
              <svg
                className="ml-2 h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </Link>
          </div>
        </section>

        {/* FAQs */}
        {query.faqs.length > 0 && (
          <section className="bg-gray-50 border-t border-gray-200">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
              <h2
                className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Frequently asked questions
              </h2>
              <div className="mt-8 space-y-6">
                {query.faqs.map((faq, index) => (
                  <details
                    key={index}
                    className="group rounded-xl border border-gray-200 bg-white shadow-sm"
                  >
                    <summary className="flex cursor-pointer items-center justify-between gap-4 p-6 text-left font-semibold text-[var(--color-navy)] hover:text-[var(--color-primary)] transition-colors">
                      <span>{faq.question}</span>
                      <svg
                        className="h-5 w-5 shrink-0 text-gray-400 transition-transform group-open:rotate-180"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="m19.5 8.25-7.5 7.5-7.5-7.5"
                        />
                      </svg>
                    </summary>
                    <div className="px-6 pb-6 text-gray-600 leading-relaxed">
                      {faq.answer}
                    </div>
                  </details>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Related queries */}
        {relatedQueries.length > 0 && (
          <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
            <h2
              className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Related searches
            </h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {relatedQueries.map((related) => (
                <Link
                  key={related!.slug}
                  href={`/find/${related!.slug}`}
                  className="group flex items-center gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm transition hover:shadow-md hover:border-[var(--color-primary)]"
                >
                  <svg
                    className="h-5 w-5 shrink-0 text-[var(--color-primary)]"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
                    />
                  </svg>
                  <div>
                    <span className="font-medium text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors">
                      {related!.title}
                    </span>
                    <p className="mt-0.5 text-sm text-gray-500 line-clamp-1">
                      {related!.shortDescription}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
