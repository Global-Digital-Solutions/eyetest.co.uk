import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  hearingConditions,
  getAllConditionSlugs,
  getConditionBySlug,
} from "@/data/hearing-health";
import { hearingTests } from "@/data/hearing-tests";

// ---------------------------------------------------------------------------
// Static params
// ---------------------------------------------------------------------------

export function generateStaticParams() {
  return getAllConditionSlugs().map((slug) => ({ slug }));
}

// ---------------------------------------------------------------------------
// Metadata
// ---------------------------------------------------------------------------

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const condition = getConditionBySlug(slug);
  if (!condition) return {};

  return {
    title: `${condition.name} — Symptoms, Causes & Treatment | hearingtest.co.uk`,
    description: condition.shortDescription,
    openGraph: {
      title: `${condition.name} | hearingtest.co.uk`,
      description: condition.shortDescription,
      url: `https://www.hearingtest.co.uk/hearing-health/conditions/${condition.slug}`,
      siteName: "hearingtest.co.uk",
      type: "article",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/hearing-health/conditions/${condition.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default async function ConditionPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const condition = getConditionBySlug(slug);
  if (!condition) notFound();

  const paragraphs = condition.fullDescription
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  const relatedConditions = condition.relatedConditions
    .map((s) => hearingConditions.find((c) => c.slug === s))
    .filter(Boolean);

  const relatedTests = condition.relatedTests
    .map((s) => hearingTests.find((t) => t.slug === s))
    .filter(Boolean);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "MedicalCondition",
    name: condition.name,
    description: condition.shortDescription,
    url: `https://www.hearingtest.co.uk/hearing-health/conditions/${condition.slug}`,
    signOrSymptom: condition.symptoms.map((s) => ({
      "@type": "MedicalSignOrSymptom",
      name: s,
    })),
    possibleTreatment: condition.treatments.map((t) => ({
      "@type": "MedicalTherapy",
      name: t,
    })),
    mainEntityOfPage: {
      "@type": "MedicalWebPage",
      url: `https://www.hearingtest.co.uk/hearing-health/conditions/${condition.slug}`,
      publisher: {
        "@type": "Organization",
        name: "hearingtest.co.uk",
        url: "https://www.hearingtest.co.uk",
      },
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: "https://www.hearingtest.co.uk",
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Hearing Health",
          item: "https://www.hearingtest.co.uk/hearing-health",
        },
        {
          "@type": "ListItem",
          position: 3,
          name: condition.name,
          item: `https://www.hearingtest.co.uk/hearing-health/conditions/${condition.slug}`,
        },
      ],
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        {/* ── Hero ─────────────────────────────────────────────────── */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Hearing Health", href: "/hearing-health" },
            { label: condition.name },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {condition.name}
          </h1>
          <p className="mt-4 text-lg text-white/90 max-w-3xl">
            {condition.shortDescription}
          </p>
        </PageHero>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          {/* ── Full description ───────────────────────────────────── */}
          <section className="prose prose-lg max-w-none text-gray-700">
            {paragraphs.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </section>

          {/* ── Symptoms ───────────────────────────────────────────── */}
          <section className="mt-12">
            <h2
              className="text-2xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Symptoms
            </h2>
            <ul className="mt-4 space-y-2">
              {condition.symptoms.map((symptom, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <svg
                    className="mt-1 h-5 w-5 shrink-0 text-red-500"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
                    />
                  </svg>
                  <span>{symptom}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ── Causes ─────────────────────────────────────────────── */}
          <section className="mt-12">
            <h2
              className="text-2xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Causes
            </h2>
            <ul className="mt-4 space-y-2">
              {condition.causes.map((cause, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <svg
                    className="mt-1 h-5 w-5 shrink-0 text-amber-500"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
                    />
                  </svg>
                  <span>{cause}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ── Treatments ─────────────────────────────────────────── */}
          <section className="mt-12">
            <h2
              className="text-2xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Treatments
            </h2>
            <ul className="mt-4 space-y-2">
              {condition.treatments.map((treatment, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <svg
                    className="mt-1 h-5 w-5 shrink-0 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m4.5 12.75 6 6 9-13.5"
                    />
                  </svg>
                  <span>{treatment}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ── When to seek help ──────────────────────────────────── */}
          <section className="mt-12 rounded-xl border border-red-200 bg-red-50 p-6">
            <h2
              className="text-xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              When to Seek Medical Help
            </h2>
            <p className="mt-2 text-gray-700">{condition.whenToSeek}</p>
          </section>

          {/* ── Related conditions ─────────────────────────────────── */}
          {relatedConditions.length > 0 && (
            <section className="mt-12">
              <h2
                className="text-2xl font-bold text-[var(--color-navy)]"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Related Conditions
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {relatedConditions.map(
                  (related) =>
                    related && (
                      <Link
                        key={related.slug}
                        href={`/hearing-health/conditions/${related.slug}`}
                        className="group rounded-xl border border-gray-200 bg-white p-5 transition hover:shadow-md hover:border-[var(--color-primary)]"
                      >
                        <h3
                          className="font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                          style={{ fontFamily: "var(--font-display)" }}
                        >
                          {related.name}
                        </h3>
                        <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                          {related.shortDescription}
                        </p>
                      </Link>
                    )
                )}
              </div>
            </section>
          )}

          {/* ── Related tests ──────────────────────────────────────── */}
          {relatedTests.length > 0 && (
            <section className="mt-12">
              <h2
                className="text-2xl font-bold text-[var(--color-navy)]"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Related Hearing Tests
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {relatedTests.map(
                  (test) =>
                    test && (
                      <Link
                        key={test.slug}
                        href={`/hearing-tests/${test.slug}`}
                        className="group rounded-xl border border-gray-200 bg-white p-5 transition hover:shadow-md hover:border-[var(--color-primary)]"
                      >
                        <h3
                          className="font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                          style={{ fontFamily: "var(--font-display)" }}
                        >
                          {test.name}
                        </h3>
                        <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                          {test.shortDescription}
                        </p>
                      </Link>
                    )
                )}
              </div>
            </section>
          )}

          {/* ── CTA ────────────────────────────────────────────────── */}
          <section className="mt-16 rounded-2xl bg-[var(--color-primary)] p-8 text-center text-white">
            <h2
              className="text-2xl font-bold"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Concerned About Your Hearing?
            </h2>
            <p className="mt-2 text-white/90 max-w-xl mx-auto">
              Book a hearing test with an audiologist near you. Compare
              appointments and find availability across the UK.
            </p>
            <Link
              href="/"
              className="mt-6 inline-flex items-center rounded-full bg-white px-8 py-3 font-semibold text-[var(--color-primary)] shadow-sm transition hover:bg-gray-100"
            >
              Find a hearing test
              <svg
                className="ml-2 h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </Link>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
