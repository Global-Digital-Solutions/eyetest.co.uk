import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  hearingGuides,
  getAllGuideSlugs,
  getGuideBySlug,
} from "@/data/hearing-health";

// ---------------------------------------------------------------------------
// Static params
// ---------------------------------------------------------------------------

export function generateStaticParams() {
  return getAllGuideSlugs().map((slug) => ({ slug }));
}

// ---------------------------------------------------------------------------
// Metadata
// ---------------------------------------------------------------------------

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const guide = getGuideBySlug(slug);
  if (!guide) return {};

  return {
    title: `${guide.title} | hearingtest.co.uk`,
    description: guide.shortDescription,
    openGraph: {
      title: `${guide.title} | hearingtest.co.uk`,
      description: guide.shortDescription,
      url: `https://www.hearingtest.co.uk/hearing-health/guides/${guide.slug}`,
      siteName: "hearingtest.co.uk",
      type: "article",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/hearing-health/guides/${guide.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default async function GuidePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const guide = getGuideBySlug(slug);
  if (!guide) notFound();

  const paragraphs = guide.fullDescription
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  const relatedGuides = guide.relatedGuides
    .map((s) => hearingGuides.find((g) => g.slug === s))
    .filter(Boolean);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: guide.title,
    description: guide.shortDescription,
    url: `https://www.hearingtest.co.uk/hearing-health/guides/${guide.slug}`,
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    author: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: "https://www.hearingtest.co.uk",
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Hearing Health",
          item: "https://www.hearingtest.co.uk/hearing-health",
        },
        {
          "@type": "ListItem",
          position: 3,
          name: guide.title,
          item: `https://www.hearingtest.co.uk/hearing-health/guides/${guide.slug}`,
        },
      ],
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        {/* ── Hero ─────────────────────────────────────────────────── */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Hearing Health", href: "/hearing-health" },
            { label: guide.title },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {guide.title}
          </h1>
          <p className="mt-4 text-lg text-white/90 max-w-3xl">
            {guide.shortDescription}
          </p>
        </PageHero>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          {/* ── Key points ─────────────────────────────────────────── */}
          <section className="rounded-xl border border-blue-200 bg-blue-50 p-6 mb-12">
            <h2
              className="text-xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Key Points
            </h2>
            <ul className="mt-4 space-y-2">
              {guide.keyPoints.map((point, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <svg
                    className="mt-1 h-5 w-5 shrink-0 text-[var(--color-primary)]"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m4.5 12.75 6 6 9-13.5"
                    />
                  </svg>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ── Full content ───────────────────────────────────────── */}
          <section className="prose prose-lg max-w-none text-gray-700">
            {paragraphs.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </section>

          {/* ── Related guides ─────────────────────────────────────── */}
          {relatedGuides.length > 0 && (
            <section className="mt-12">
              <h2
                className="text-2xl font-bold text-[var(--color-navy)]"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Related Guides
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {relatedGuides.map(
                  (related) =>
                    related && (
                      <Link
                        key={related.slug}
                        href={`/hearing-health/guides/${related.slug}`}
                        className="group rounded-xl border border-gray-200 bg-white p-5 transition hover:shadow-md hover:border-[var(--color-primary)]"
                      >
                        <h3
                          className="font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                          style={{ fontFamily: "var(--font-display)" }}
                        >
                          {related.title}
                        </h3>
                        <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                          {related.shortDescription}
                        </p>
                      </Link>
                    )
                )}
              </div>
            </section>
          )}

          {/* ── CTA ────────────────────────────────────────────────── */}
          <section className="mt-16 rounded-2xl bg-[var(--color-primary)] p-8 text-center text-white">
            <h2
              className="text-2xl font-bold"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to Check Your Hearing?
            </h2>
            <p className="mt-2 text-white/90 max-w-xl mx-auto">
              Find audiologists near you and book a hearing test online.
            </p>
            <Link
              href="/"
              className="mt-6 inline-flex items-center rounded-full bg-white px-8 py-3 font-semibold text-[var(--color-primary)] shadow-sm transition hover:bg-gray-100"
            >
              Search for appointments
              <svg
                className="ml-2 h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </Link>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
