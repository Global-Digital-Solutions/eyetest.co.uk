import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  hearingTests,
  getAllSlugs,
  getTestBySlug,
} from "@/data/hearing-tests";

// ---------------------------------------------------------------------------
// Static params
// ---------------------------------------------------------------------------

export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }));
}

// ---------------------------------------------------------------------------
// Metadata
// ---------------------------------------------------------------------------

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const test = getTestBySlug(slug);
  if (!test) return {};

  return {
    title: `${test.name} | Hearing Tests | hearingtest.co.uk`,
    description: test.shortDescription,
    openGraph: {
      title: `${test.name} | hearingtest.co.uk`,
      description: test.shortDescription,
      url: `https://www.hearingtest.co.uk/hearing-tests/${test.slug}`,
      siteName: "hearingtest.co.uk",
      type: "article",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/hearing-tests/${test.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default async function HearingTestPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const test = getTestBySlug(slug);
  if (!test) notFound();

  const relatedTests = test.relatedTests
    .map((s) => hearingTests.find((t) => t.slug === s))
    .filter(Boolean);

  const paragraphs = test.fullDescription
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    name: test.name,
    description: test.shortDescription,
    url: `https://www.hearingtest.co.uk/hearing-tests/${test.slug}`,
    mainContentOfPage: {
      "@type": "WebPageElement",
      cssSelector: "main",
    },
    about: {
      "@type": "MedicalTest",
      name: test.name,
      description: test.shortDescription,
    },
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: "https://www.hearingtest.co.uk",
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Hearing Tests",
          item: "https://www.hearingtest.co.uk/hearing-tests",
        },
        {
          "@type": "ListItem",
          position: 3,
          name: test.name,
          item: `https://www.hearingtest.co.uk/hearing-tests/${test.slug}`,
        },
      ],
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        {/* ── Hero ─────────────────────────────────────────────────── */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Hearing Tests", href: "/hearing-tests" },
            { label: test.name },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {test.name}
          </h1>
          <p className="mt-4 text-lg text-white/90 max-w-3xl">
            {test.shortDescription}
          </p>
        </PageHero>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          {/* ── Quick facts ────────────────────────────────────────── */}
          <div className="grid gap-4 sm:grid-cols-3 mb-12">
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                Duration
              </p>
              <p className="mt-1 text-base font-medium text-[var(--color-navy)]">
                {test.duration}
              </p>
            </div>
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                Cost
              </p>
              <p className="mt-1 text-base font-medium text-[var(--color-navy)]">
                {test.cost}
              </p>
            </div>
            <div className="rounded-xl border border-gray-200 bg-gray-50 p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">
                NHS Covered
              </p>
              <p className="mt-1 text-base font-medium">
                {test.nhsCovered ? (
                  <span className="text-[var(--color-nhs-blue)]">
                    Yes — available on the NHS
                  </span>
                ) : (
                  <span className="text-gray-600">
                    Not routinely available on the NHS
                  </span>
                )}
              </p>
            </div>
          </div>

          {/* ── Full description ───────────────────────────────────── */}
          <section className="prose prose-lg max-w-none text-gray-700">
            {paragraphs.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </section>

          {/* ── Who needs this test ────────────────────────────────── */}
          <section className="mt-12">
            <h2
              className="text-2xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Who Needs This Test?
            </h2>
            <ul className="mt-4 space-y-2">
              {test.whoNeeds.map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <svg
                    className="mt-1 h-5 w-5 shrink-0 text-[var(--color-primary)]"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="m4.5 12.75 6 6 9-13.5"
                    />
                  </svg>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* ── What to expect ─────────────────────────────────────── */}
          <section className="mt-12">
            <h2
              className="text-2xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              What to Expect
            </h2>
            <ol className="mt-4 space-y-4">
              {test.whatToExpect.map((step, i) => (
                <li key={i} className="flex items-start gap-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--color-primary)] text-sm font-bold text-white">
                    {i + 1}
                  </span>
                  <p className="pt-1 text-gray-700">{step}</p>
                </li>
              ))}
            </ol>
          </section>

          {/* ── Frequency recommendation ───────────────────────────── */}
          <section className="mt-12 rounded-xl border border-blue-200 bg-blue-50 p-6">
            <h2
              className="text-xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              How Often Should You Have This Test?
            </h2>
            <p className="mt-2 text-gray-700">{test.frequency}</p>
          </section>

          {/* ── Related tests ──────────────────────────────────────── */}
          {relatedTests.length > 0 && (
            <section className="mt-12">
              <h2
                className="text-2xl font-bold text-[var(--color-navy)]"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Related Hearing Tests
              </h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {relatedTests.map(
                  (related) =>
                    related && (
                      <Link
                        key={related.slug}
                        href={`/hearing-tests/${related.slug}`}
                        className="group rounded-xl border border-gray-200 bg-white p-5 transition hover:shadow-md hover:border-[var(--color-primary)]"
                      >
                        <h3
                          className="font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                          style={{ fontFamily: "var(--font-display)" }}
                        >
                          {related.name}
                        </h3>
                        <p className="mt-1 text-sm text-gray-600 line-clamp-2">
                          {related.shortDescription}
                        </p>
                      </Link>
                    )
                )}
              </div>
            </section>
          )}

          {/* ── CTA ────────────────────────────────────────────────── */}
          <section className="mt-16 rounded-2xl bg-[var(--color-primary)] p-8 text-center text-white">
            <h2
              className="text-2xl font-bold"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to Book a Hearing Test?
            </h2>
            <p className="mt-2 text-white/90 max-w-xl mx-auto">
              Find audiologists near you and compare available appointments
              across the UK.
            </p>
            <Link
              href="/"
              className="mt-6 inline-flex items-center rounded-full bg-white px-8 py-3 font-semibold text-[var(--color-primary)] shadow-sm transition hover:bg-gray-100"
            >
              Search for appointments
              <svg
                className="ml-2 h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </Link>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
