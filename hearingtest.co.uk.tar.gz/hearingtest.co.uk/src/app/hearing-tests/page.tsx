import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import { hearingTests } from "@/data/hearing-tests";

export const metadata: Metadata = {
  title: "Types of Hearing Tests in the UK | hearingtest.co.uk",
  description:
    "Explore 18 types of hearing tests available in the UK, from standard audiometry and NHS hearing tests to tinnitus assessments and newborn screening. Find the right test for you.",
  openGraph: {
    title: "Types of Hearing Tests in the UK | hearingtest.co.uk",
    description:
      "Explore 18 types of hearing tests available in the UK, from standard audiometry and NHS hearing tests to tinnitus assessments and newborn screening.",
    url: "https://www.hearingtest.co.uk/hearing-tests",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/hearing-tests",
  },
};

export default function HearingTestsPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Types of Hearing Tests in the UK",
    description:
      "A comprehensive guide to 18 types of hearing tests available in the UK, including NHS and private options.",
    url: "https://www.hearingtest.co.uk/hearing-tests",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    mainEntity: {
      "@type": "ItemList",
      numberOfItems: hearingTests.length,
      itemListElement: hearingTests.map((test, index) => ({
        "@type": "ListItem",
        position: index + 1,
        url: `https://www.hearingtest.co.uk/hearing-tests/${test.slug}`,
        name: test.name,
      })),
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Hearing Tests" },
          ]}
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Types of Hearing Tests
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/90 max-w-3xl">
            Explore the full range of hearing tests available in the UK —
            from routine check-ups and NHS assessments to specialist
            evaluations for tinnitus, balance, and children&apos;s hearing.
          </p>
        </PageHero>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {hearingTests.map((test) => (
              <Link
                key={test.slug}
                href={`/hearing-tests/${test.slug}`}
                className="group block rounded-2xl border border-gray-200 bg-white p-6 shadow-sm transition hover:shadow-md hover:border-[var(--color-primary)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <h2
                    className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {test.name}
                  </h2>
                  <div className="flex shrink-0 gap-1.5">
                    {test.nhsCovered && (
                      <span className="inline-flex items-center rounded-full bg-[var(--color-nhs-blue)]/10 px-2.5 py-0.5 text-xs font-medium text-[var(--color-nhs-blue)]">
                        NHS
                      </span>
                    )}
                  </div>
                </div>

                <p className="mt-3 text-sm text-gray-600 line-clamp-3">
                  {test.shortDescription}
                </p>

                <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-gray-500">
                  <span className="inline-flex items-center gap-1">
                    <svg
                      className="h-3.5 w-3.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                      />
                    </svg>
                    {test.duration}
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-0.5 font-medium text-gray-700">
                    {test.cost.length > 40
                      ? test.cost.split(";")[0]
                      : test.cost}
                  </span>
                </div>

                <span className="mt-4 inline-flex items-center text-sm font-medium text-[var(--color-primary)]">
                  Learn more
                  <svg
                    className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                    />
                  </svg>
                </span>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
