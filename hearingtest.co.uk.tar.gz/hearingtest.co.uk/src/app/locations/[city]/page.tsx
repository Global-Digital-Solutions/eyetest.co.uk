import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

// ---------------------------------------------------------------------------
// Inline city data (mirrors locations/page.tsx — no separate data file)
// ---------------------------------------------------------------------------

type CityEntry = {
  slug: string;
  name: string;
  region: string;
  suggestedPostcode: string;
  description: string;
};

const cities: CityEntry[] = [
  // London
  { slug: "london", name: "London", region: "London", suggestedPostcode: "W1B 3HH", description: "London offers the widest choice of hearing care providers in the UK, from leading high-street brands to specialist independent audiologists across every borough." },
  { slug: "croydon", name: "Croydon", region: "London", suggestedPostcode: "CR0 1NX", description: "Croydon has several hearing test providers in and around the town centre, with good access to both NHS and private audiological services." },
  { slug: "bromley", name: "Bromley", region: "London", suggestedPostcode: "BR1 1DN", description: "Bromley residents can access multiple hearing care providers in the high street and surrounding retail parks." },
  { slug: "kingston-upon-thames", name: "Kingston upon Thames", region: "London", suggestedPostcode: "KT1 1BL", description: "Kingston upon Thames offers convenient access to hearing tests from high-street audiologists and private clinics in the town centre." },
  { slug: "romford", name: "Romford", region: "London", suggestedPostcode: "RM1 3AB", description: "Romford has hearing test providers in the Liberty Shopping Centre and surrounding areas, with walk-in and booked appointments available." },
  { slug: "enfield", name: "Enfield", region: "London", suggestedPostcode: "EN1 1TH", description: "Enfield offers hearing care services through several high-street providers and NHS audiology departments." },
  // South East
  { slug: "brighton", name: "Brighton", region: "South East", suggestedPostcode: "BN1 1EE", description: "Brighton has a strong selection of hearing care providers, from national chains in the city centre to independent audiologists in the Lanes and surrounding areas." },
  { slug: "reading", name: "Reading", region: "South East", suggestedPostcode: "RG1 2HB", description: "Reading offers excellent hearing test availability through providers in the Oracle Shopping Centre and Broad Street area." },
  { slug: "guildford", name: "Guildford", region: "South East", suggestedPostcode: "GU1 3SG", description: "Guildford has multiple hearing care providers along the High Street and in the surrounding retail areas." },
  { slug: "oxford", name: "Oxford", region: "South East", suggestedPostcode: "OX1 1BX", description: "Oxford provides access to hearing tests through high-street audiologists and the renowned Oxford Auditory Neuroscience Group." },
  { slug: "southampton", name: "Southampton", region: "South East", suggestedPostcode: "SO14 7DW", description: "Southampton offers hearing tests at multiple locations including the WestQuay shopping centre and the city centre high street." },
  { slug: "portsmouth", name: "Portsmouth", region: "South East", suggestedPostcode: "PO1 2AH", description: "Portsmouth residents can access hearing care through providers in Commercial Road and Gunwharf Quays." },
  { slug: "canterbury", name: "Canterbury", region: "South East", suggestedPostcode: "CT1 2TF", description: "Canterbury has hearing test providers in the city centre and Whitefriars Shopping Centre area." },
  { slug: "maidstone", name: "Maidstone", region: "South East", suggestedPostcode: "ME14 1HP", description: "Maidstone offers hearing care services through providers in the town centre and surrounding retail parks." },
  { slug: "milton-keynes", name: "Milton Keynes", region: "South East", suggestedPostcode: "MK9 3BB", description: "Milton Keynes has hearing test providers across centre:mk and the surrounding district centres." },
  // South West
  { slug: "bristol", name: "Bristol", region: "South West", suggestedPostcode: "BS1 3BH", description: "Bristol has a wide range of hearing care providers across Broadmead, Cabot Circus, and Clifton, offering both NHS and private hearing tests." },
  { slug: "bath", name: "Bath", region: "South West", suggestedPostcode: "BA1 1SU", description: "Bath offers hearing tests through several providers in the city centre and SouthGate shopping area." },
  { slug: "exeter", name: "Exeter", region: "South West", suggestedPostcode: "EX4 3PQ", description: "Exeter has hearing care providers in the High Street and Princesshay shopping centre." },
  { slug: "plymouth", name: "Plymouth", region: "South West", suggestedPostcode: "PL1 1EA", description: "Plymouth offers hearing tests at Drake Circus and along the city centre, with NHS and private options available." },
  { slug: "bournemouth", name: "Bournemouth", region: "South West", suggestedPostcode: "BH1 1BA", description: "Bournemouth has hearing test providers along the town centre and Castlepoint shopping park." },
  { slug: "swindon", name: "Swindon", region: "South West", suggestedPostcode: "SN1 1BL", description: "Swindon residents can access hearing tests through providers in the Brunel Shopping Centre and town centre." },
  { slug: "cheltenham", name: "Cheltenham", region: "South West", suggestedPostcode: "GL50 1TH", description: "Cheltenham offers hearing care services through high-street providers along the Promenade and surrounding areas." },
  // East of England
  { slug: "cambridge", name: "Cambridge", region: "East of England", suggestedPostcode: "CB2 3QZ", description: "Cambridge has hearing care providers in the Grand Arcade and city centre, with access to leading NHS audiology services." },
  { slug: "norwich", name: "Norwich", region: "East of England", suggestedPostcode: "NR2 1NH", description: "Norwich offers hearing tests at multiple locations in the city centre and Castle Quarter shopping area." },
  { slug: "ipswich", name: "Ipswich", region: "East of England", suggestedPostcode: "IP1 3HD", description: "Ipswich has hearing care providers along the Buttermarket and Tavern Street areas." },
  { slug: "colchester", name: "Colchester", region: "East of England", suggestedPostcode: "CO1 1DT", description: "Colchester residents can find hearing test providers in the town centre and Lion Walk Shopping Centre." },
  { slug: "luton", name: "Luton", region: "East of England", suggestedPostcode: "LU1 2HN", description: "Luton offers hearing tests through providers in The Mall shopping centre and the town centre." },
  { slug: "chelmsford", name: "Chelmsford", region: "East of England", suggestedPostcode: "CM1 1AX", description: "Chelmsford has hearing care providers in the High Chelmer Shopping Centre and city centre." },
  { slug: "peterborough", name: "Peterborough", region: "East of England", suggestedPostcode: "PE1 1HF", description: "Peterborough offers hearing tests at Queensgate Shopping Centre and along Bridge Street." },
  // West Midlands
  { slug: "birmingham", name: "Birmingham", region: "West Midlands", suggestedPostcode: "B2 5PP", description: "Birmingham has the largest selection of hearing care providers in the Midlands, with locations across the Bullring, New Street, and surrounding areas." },
  { slug: "coventry", name: "Coventry", region: "West Midlands", suggestedPostcode: "CV1 1DD", description: "Coventry offers hearing tests in the city centre and West Orchards Shopping Centre." },
  { slug: "wolverhampton", name: "Wolverhampton", region: "West Midlands", suggestedPostcode: "WV1 1HB", description: "Wolverhampton has hearing care providers in the Mander Centre and city centre high street." },
  { slug: "worcester", name: "Worcester", region: "West Midlands", suggestedPostcode: "WR1 2RA", description: "Worcester residents can access hearing tests through providers in the Crowngate Shopping Centre and High Street." },
  { slug: "stoke-on-trent", name: "Stoke-on-Trent", region: "West Midlands", suggestedPostcode: "ST1 1LZ", description: "Stoke-on-Trent has hearing test providers in the Potteries Centre and across the six towns." },
  { slug: "shrewsbury", name: "Shrewsbury", region: "West Midlands", suggestedPostcode: "SY1 1DY", description: "Shrewsbury offers hearing care services through providers in the town centre and Darwin Shopping Centre." },
  // East Midlands
  { slug: "nottingham", name: "Nottingham", region: "East Midlands", suggestedPostcode: "NG1 5AW", description: "Nottingham has hearing test providers across the Victoria Centre, Broadmarsh area, and along the high street." },
  { slug: "leicester", name: "Leicester", region: "East Midlands", suggestedPostcode: "LE1 5AP", description: "Leicester offers hearing tests at Highcross Shopping Centre and in the city centre." },
  { slug: "derby", name: "Derby", region: "East Midlands", suggestedPostcode: "DE1 2QQ", description: "Derby has hearing care providers in Derbion shopping centre and along the city centre." },
  { slug: "lincoln", name: "Lincoln", region: "East Midlands", suggestedPostcode: "LN5 7AT", description: "Lincoln offers hearing tests through providers on the High Street and in the Waterside Shopping Centre." },
  { slug: "northampton", name: "Northampton", region: "East Midlands", suggestedPostcode: "NN1 1ED", description: "Northampton residents can access hearing care through providers in the Grosvenor Centre and town centre." },
  // North West
  { slug: "manchester", name: "Manchester", region: "North West", suggestedPostcode: "M1 1AD", description: "Manchester offers extensive hearing care options across the Arndale Centre, Market Street, and the Northern Quarter, plus specialist clinics." },
  { slug: "liverpool", name: "Liverpool", region: "North West", suggestedPostcode: "L1 1JD", description: "Liverpool has hearing test providers in Liverpool ONE, Church Street, and across the city centre." },
  { slug: "chester", name: "Chester", region: "North West", suggestedPostcode: "CH1 2HJ", description: "Chester offers hearing tests through providers along the famous Rows and in the Grosvenor Shopping Centre." },
  { slug: "preston", name: "Preston", region: "North West", suggestedPostcode: "PR1 2HT", description: "Preston has hearing care providers in the St George's Shopping Centre and along Fishergate." },
  { slug: "bolton", name: "Bolton", region: "North West", suggestedPostcode: "BL1 1SE", description: "Bolton offers hearing tests at the Market Place Shopping Centre and town centre locations." },
  { slug: "blackpool", name: "Blackpool", region: "North West", suggestedPostcode: "FY1 1AD", description: "Blackpool has hearing test providers along the town centre and Houndshill Shopping Centre." },
  { slug: "warrington", name: "Warrington", region: "North West", suggestedPostcode: "WA1 1PG", description: "Warrington offers hearing care through providers in the Golden Square Shopping Centre and town centre." },
  { slug: "carlisle", name: "Carlisle", region: "North West", suggestedPostcode: "CA3 8QG", description: "Carlisle has hearing test providers in The Lanes Shopping Centre and along English Street." },
  // North East
  { slug: "newcastle", name: "Newcastle", region: "North East", suggestedPostcode: "NE1 7RU", description: "Newcastle has a wide selection of hearing care providers across Eldon Square, Northumberland Street, and the Metrocentre in Gateshead." },
  { slug: "sunderland", name: "Sunderland", region: "North East", suggestedPostcode: "SR1 3HY", description: "Sunderland offers hearing tests through providers in The Bridges Shopping Centre and the city centre." },
  { slug: "durham", name: "Durham", region: "North East", suggestedPostcode: "DH1 3NJ", description: "Durham has hearing care providers in the Prince Bishops Shopping Centre and along the city high street." },
  { slug: "middlesbrough", name: "Middlesbrough", region: "North East", suggestedPostcode: "TS1 2AZ", description: "Middlesbrough offers hearing tests at the Cleveland Centre and along Linthorpe Road." },
  { slug: "darlington", name: "Darlington", region: "North East", suggestedPostcode: "DL1 1NH", description: "Darlington has hearing test providers in the town centre and along Skinnergate." },
  // Yorkshire
  { slug: "leeds", name: "Leeds", region: "Yorkshire", suggestedPostcode: "LS1 6AZ", description: "Leeds has extensive hearing care options across the Trinity Leeds shopping centre, Briggate, and surrounding areas." },
  { slug: "sheffield", name: "Sheffield", region: "Yorkshire", suggestedPostcode: "S1 2GE", description: "Sheffield offers hearing tests at Meadowhall, in the city centre along Fargate, and at specialist clinics." },
  { slug: "york", name: "York", region: "Yorkshire", suggestedPostcode: "YO1 9TL", description: "York has hearing care providers along Coney Street, Coppergate, and in the Monks Cross shopping area." },
  { slug: "bradford", name: "Bradford", region: "Yorkshire", suggestedPostcode: "BD1 1HJ", description: "Bradford offers hearing tests through providers in the Broadway Shopping Centre and city centre." },
  { slug: "hull", name: "Hull", region: "Yorkshire", suggestedPostcode: "HU1 3EA", description: "Hull has hearing test providers in the Princes Quay Shopping Centre and along the city centre." },
  { slug: "doncaster", name: "Doncaster", region: "Yorkshire", suggestedPostcode: "DN1 1NH", description: "Doncaster offers hearing care through providers in the Frenchgate Shopping Centre and town centre." },
  { slug: "harrogate", name: "Harrogate", region: "Yorkshire", suggestedPostcode: "HG1 1BS", description: "Harrogate has hearing test providers along Parliament Street and the Victoria Shopping Centre." },
  // Wales
  { slug: "cardiff", name: "Cardiff", region: "Wales", suggestedPostcode: "CF10 1EP", description: "Cardiff has the largest selection of hearing care providers in Wales, with locations across St David's Centre, Queen Street, and the city centre." },
  { slug: "swansea", name: "Swansea", region: "Wales", suggestedPostcode: "SA1 3QW", description: "Swansea offers hearing tests at the Quadrant Shopping Centre and across the city centre." },
  { slug: "newport", name: "Newport", region: "Wales", suggestedPostcode: "NP20 1FW", description: "Newport has hearing care providers in the Kingsway Shopping Centre and along the city centre." },
  { slug: "wrexham", name: "Wrexham", region: "Wales", suggestedPostcode: "LL11 1AY", description: "Wrexham offers hearing tests through providers in Eagles Meadow Shopping Centre and the town centre." },
  { slug: "aberystwyth", name: "Aberystwyth", region: "Wales", suggestedPostcode: "SY23 2AX", description: "Aberystwyth has hearing care providers along Great Darkgate Street and the town centre, serving mid-Wales." },
  // Scotland
  { slug: "edinburgh", name: "Edinburgh", region: "Scotland", suggestedPostcode: "EH1 1RE", description: "Edinburgh offers extensive hearing care through providers on Princes Street, St James Quarter, and across the city." },
  { slug: "glasgow", name: "Glasgow", region: "Scotland", suggestedPostcode: "G1 3SL", description: "Glasgow has the largest selection of hearing test providers in Scotland, across Buchanan Galleries, Argyle Street, and specialist clinics." },
  { slug: "aberdeen", name: "Aberdeen", region: "Scotland", suggestedPostcode: "AB10 1XG", description: "Aberdeen offers hearing tests at Union Square, along Union Street, and through NHS Grampian audiology services." },
  { slug: "dundee", name: "Dundee", region: "Scotland", suggestedPostcode: "DD1 4QB", description: "Dundee has hearing care providers in the Overgate Centre and city centre." },
  { slug: "inverness", name: "Inverness", region: "Scotland", suggestedPostcode: "IV1 1QY", description: "Inverness offers hearing tests through providers in the Eastgate Shopping Centre and along the High Street." },
  { slug: "stirling", name: "Stirling", region: "Scotland", suggestedPostcode: "FK8 2EA", description: "Stirling has hearing test providers in the Thistle Centre and along King Street." },
  // Northern Ireland
  { slug: "belfast", name: "Belfast", region: "Northern Ireland", suggestedPostcode: "BT1 5GS", description: "Belfast has the widest choice of hearing care providers in Northern Ireland, across Victoria Square, Donegall Place, and CastleCourt." },
  { slug: "derry", name: "Derry", region: "Northern Ireland", suggestedPostcode: "BT48 6HQ", description: "Derry offers hearing tests through providers in the Foyleside Shopping Centre and city centre." },
  { slug: "lisburn", name: "Lisburn", region: "Northern Ireland", suggestedPostcode: "BT28 1AL", description: "Lisburn has hearing care providers in Bow Street Mall and the city centre." },
  { slug: "newry", name: "Newry", region: "Northern Ireland", suggestedPostcode: "BT34 1AN", description: "Newry offers hearing tests through providers in The Quays Shopping Centre and along Hill Street." },
];

function getCityBySlug(slug: string): CityEntry | undefined {
  return cities.find((c) => c.slug === slug);
}

// ---------------------------------------------------------------------------
// Static generation
// ---------------------------------------------------------------------------

export function generateStaticParams(): { city: string }[] {
  return cities.map((c) => ({ city: c.slug }));
}

// ---------------------------------------------------------------------------
// Dynamic SEO metadata
// ---------------------------------------------------------------------------

export async function generateMetadata({
  params,
}: {
  params: Promise<{ city: string }>;
}): Promise<Metadata> {
  const { city } = await params;
  const location = getCityBySlug(city);

  if (!location) {
    return { title: "Location Not Found | hearingtest.co.uk" };
  }

  const title = `Hearing Tests in ${location.name} — Compare & Book | hearingtest.co.uk`;
  const description = `Compare hearing test appointments in ${location.name}. Find NHS and private audiologists, check same-day availability, and book online for free.`;

  return {
    title,
    description,
    keywords: [
      `hearing test ${location.name}`,
      `audiologists ${location.name}`,
      `hearing test near me ${location.name}`,
      `NHS hearing test ${location.name}`,
      `book hearing test ${location.name}`,
      `${location.name} audiologists`,
      `free hearing test ${location.name}`,
      `hearing test cost ${location.name}`,
    ],
    openGraph: {
      title,
      description,
      url: `https://www.hearingtest.co.uk/locations/${location.slug}`,
      siteName: "hearingtest.co.uk",
      type: "website",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/locations/${location.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default async function CityPage({
  params,
}: {
  params: Promise<{ city: string }>;
}) {
  const { city } = await params;
  const location = getCityBySlug(city);

  if (!location) {
    notFound();
  }

  // Nearby cities in same region (exclude current)
  const nearbyCities = cities
    .filter((c) => c.region === location.region && c.slug !== location.slug)
    .slice(0, 6);

  // ---------------------------------------------------------------------------
  // JSON-LD
  // ---------------------------------------------------------------------------

  const localBusinessJsonLd = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: `Hearing Tests in ${location.name}`,
    description: location.description,
    url: `https://www.hearingtest.co.uk/locations/${location.slug}`,
    areaServed: {
      "@type": "City",
      name: location.name,
    },
    provider: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Locations",
        item: "https://www.hearingtest.co.uk/locations",
      },
      {
        "@type": "ListItem",
        position: 3,
        name: location.name,
        item: `https://www.hearingtest.co.uk/locations/${location.slug}`,
      },
    ],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(localBusinessJsonLd),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(breadcrumbJsonLd),
          }}
        />

        {/* Hero */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Locations", href: "/locations" },
            { label: location.name },
          ]}
          compact
        >
          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Hearing Tests in {location.name}
          </h1>
          <p className="text-base sm:text-lg text-white/70 max-w-xl mx-auto mb-2">
            {location.description}
          </p>
          <p className="text-sm text-white/50">
            {location.region}, United Kingdom
          </p>
        </PageHero>

        {/* Search CTA */}
        <section className="py-16 sm:py-20">
          <div className="max-w-3xl mx-auto px-4">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-lg p-8 sm:p-10 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-[var(--color-primary)]/10 flex items-center justify-center text-[var(--color-primary)] mb-6">
                <svg
                  className="w-8 h-8"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="1.5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Find Audiologists in {location.name}
              </h2>
              <p className="text-gray-600 mb-6 max-w-lg mx-auto">
                Enter your {location.name} postcode below to compare prices,
                check real-time availability, and book your hearing test online.
              </p>

              <form
                action="/search"
                method="GET"
                className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
              >
                <input
                  type="text"
                  name="postcode"
                  placeholder={`e.g. ${location.suggestedPostcode}`}
                  aria-label="Enter your postcode"
                  className="flex-1 px-4 py-3 text-sm text-[var(--color-navy)] bg-gray-50 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30 focus:border-[var(--color-primary)] placeholder:text-gray-400"
                />
                <button
                  type="submit"
                  className="flex items-center justify-center gap-2 text-sm font-semibold text-white py-3 px-6 rounded-full transition-all hover:shadow-lg cursor-pointer"
                  style={{ backgroundColor: "var(--color-primary)" }}
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                  Search
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* What to expect */}
        <section className="py-16 sm:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Hearing Tests in {location.name}
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Whether you need a routine hearing check or a specialist
                assessment, {location.name} has audiologists ready to help.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
                  title: "Free & Paid Options",
                  desc: `Multiple audiologists in ${location.name} offer free hearing tests, with comprehensive private assessments available from around £50.`,
                },
                {
                  icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
                  title: "NHS Services",
                  desc: `NHS hearing tests are available in ${location.name} through GP referral. Many high-street audiologists also offer free checks.`,
                },
                {
                  icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
                  title: "Quick Appointments",
                  desc: `Same-day and next-day hearing test appointments are often available in ${location.name}. Walk-ins welcome at many locations.`,
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm"
                >
                  <div className="w-12 h-12 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center text-[var(--color-primary)] mb-4">
                    <svg
                      className="w-6 h-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d={item.icon}
                      />
                    </svg>
                  </div>
                  <h3
                    className="font-semibold text-[var(--color-navy)] mb-2"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-600">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Nearby locations */}
        {nearbyCities.length > 0 && (
          <section className="py-16 sm:py-20">
            <div className="max-w-7xl mx-auto px-4">
              <div className="text-center mb-10">
                <h2
                  className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Nearby Locations
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Also find hearing tests in these nearby {location.region}{" "}
                  locations.
                </p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {nearbyCities.map((nearby) => (
                  <Link
                    key={nearby.slug}
                    href={`/locations/${nearby.slug}`}
                    className="group flex items-center gap-3 bg-white rounded-xl p-4 border border-gray-200 hover:border-[var(--color-primary)]/30 hover:shadow-md transition-all"
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[var(--color-primary)]/10 flex items-center justify-center">
                      <svg
                        className="w-5 h-5 text-[var(--color-primary)]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors">
                        Hearing tests in {nearby.name}
                      </span>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {nearby.region}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>

              <div className="text-center mt-8">
                <Link
                  href="/locations"
                  className="text-sm font-medium text-[var(--color-primary)] hover:underline"
                >
                  View all UK locations &rarr;
                </Link>
              </div>
            </div>
          </section>
        )}

        {/* Bottom CTA */}
        <section className="py-16 sm:py-20 bg-[var(--color-navy)]">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <h2
              className="text-2xl sm:text-3xl font-bold text-white mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Book a Hearing Test in {location.name}
            </h2>
            <p className="text-white/70 mb-8 max-w-lg mx-auto">
              Compare audiologists, check availability, and book online for
              free. Most appointments available within 48 hours.
            </p>
            <Link
              href="/search"
              className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:opacity-90 text-white font-semibold text-base px-8 py-4 rounded-full transition-all hover:shadow-lg"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              Search in {location.name}
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
