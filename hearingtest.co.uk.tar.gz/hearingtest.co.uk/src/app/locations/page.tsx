import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

// ---------------------------------------------------------------------------
// Inline location data — no separate data file for locations
// ---------------------------------------------------------------------------

type CityEntry = {
  slug: string;
  name: string;
  suggestedPostcode: string;
};

type RegionData = {
  name: string;
  cities: CityEntry[];
};

const regions: RegionData[] = [
  {
    name: "London",
    cities: [
      { slug: "london", name: "London", suggestedPostcode: "W1B 3HH" },
      { slug: "croydon", name: "Croydon", suggestedPostcode: "CR0 1NX" },
      { slug: "bromley", name: "Bromley", suggestedPostcode: "BR1 1DN" },
      { slug: "kingston-upon-thames", name: "Kingston upon Thames", suggestedPostcode: "KT1 1BL" },
      { slug: "romford", name: "Romford", suggestedPostcode: "RM1 3AB" },
      { slug: "enfield", name: "Enfield", suggestedPostcode: "EN1 1TH" },
    ],
  },
  {
    name: "South East",
    cities: [
      { slug: "brighton", name: "Brighton", suggestedPostcode: "BN1 1EE" },
      { slug: "reading", name: "Reading", suggestedPostcode: "RG1 2HB" },
      { slug: "guildford", name: "Guildford", suggestedPostcode: "GU1 3SG" },
      { slug: "oxford", name: "Oxford", suggestedPostcode: "OX1 1BX" },
      { slug: "southampton", name: "Southampton", suggestedPostcode: "SO14 7DW" },
      { slug: "portsmouth", name: "Portsmouth", suggestedPostcode: "PO1 2AH" },
      { slug: "canterbury", name: "Canterbury", suggestedPostcode: "CT1 2TF" },
      { slug: "maidstone", name: "Maidstone", suggestedPostcode: "ME14 1HP" },
      { slug: "milton-keynes", name: "Milton Keynes", suggestedPostcode: "MK9 3BB" },
    ],
  },
  {
    name: "South West",
    cities: [
      { slug: "bristol", name: "Bristol", suggestedPostcode: "BS1 3BH" },
      { slug: "bath", name: "Bath", suggestedPostcode: "BA1 1SU" },
      { slug: "exeter", name: "Exeter", suggestedPostcode: "EX4 3PQ" },
      { slug: "plymouth", name: "Plymouth", suggestedPostcode: "PL1 1EA" },
      { slug: "bournemouth", name: "Bournemouth", suggestedPostcode: "BH1 1BA" },
      { slug: "swindon", name: "Swindon", suggestedPostcode: "SN1 1BL" },
      { slug: "cheltenham", name: "Cheltenham", suggestedPostcode: "GL50 1TH" },
    ],
  },
  {
    name: "East of England",
    cities: [
      { slug: "cambridge", name: "Cambridge", suggestedPostcode: "CB2 3QZ" },
      { slug: "norwich", name: "Norwich", suggestedPostcode: "NR2 1NH" },
      { slug: "ipswich", name: "Ipswich", suggestedPostcode: "IP1 3HD" },
      { slug: "colchester", name: "Colchester", suggestedPostcode: "CO1 1DT" },
      { slug: "luton", name: "Luton", suggestedPostcode: "LU1 2HN" },
      { slug: "chelmsford", name: "Chelmsford", suggestedPostcode: "CM1 1AX" },
      { slug: "peterborough", name: "Peterborough", suggestedPostcode: "PE1 1HF" },
    ],
  },
  {
    name: "West Midlands",
    cities: [
      { slug: "birmingham", name: "Birmingham", suggestedPostcode: "B2 5PP" },
      { slug: "coventry", name: "Coventry", suggestedPostcode: "CV1 1DD" },
      { slug: "wolverhampton", name: "Wolverhampton", suggestedPostcode: "WV1 1HB" },
      { slug: "worcester", name: "Worcester", suggestedPostcode: "WR1 2RA" },
      { slug: "stoke-on-trent", name: "Stoke-on-Trent", suggestedPostcode: "ST1 1LZ" },
      { slug: "shrewsbury", name: "Shrewsbury", suggestedPostcode: "SY1 1DY" },
    ],
  },
  {
    name: "East Midlands",
    cities: [
      { slug: "nottingham", name: "Nottingham", suggestedPostcode: "NG1 5AW" },
      { slug: "leicester", name: "Leicester", suggestedPostcode: "LE1 5AP" },
      { slug: "derby", name: "Derby", suggestedPostcode: "DE1 2QQ" },
      { slug: "lincoln", name: "Lincoln", suggestedPostcode: "LN5 7AT" },
      { slug: "northampton", name: "Northampton", suggestedPostcode: "NN1 1ED" },
    ],
  },
  {
    name: "North West",
    cities: [
      { slug: "manchester", name: "Manchester", suggestedPostcode: "M1 1AD" },
      { slug: "liverpool", name: "Liverpool", suggestedPostcode: "L1 1JD" },
      { slug: "chester", name: "Chester", suggestedPostcode: "CH1 2HJ" },
      { slug: "preston", name: "Preston", suggestedPostcode: "PR1 2HT" },
      { slug: "bolton", name: "Bolton", suggestedPostcode: "BL1 1SE" },
      { slug: "blackpool", name: "Blackpool", suggestedPostcode: "FY1 1AD" },
      { slug: "warrington", name: "Warrington", suggestedPostcode: "WA1 1PG" },
      { slug: "carlisle", name: "Carlisle", suggestedPostcode: "CA3 8QG" },
    ],
  },
  {
    name: "North East",
    cities: [
      { slug: "newcastle", name: "Newcastle", suggestedPostcode: "NE1 7RU" },
      { slug: "sunderland", name: "Sunderland", suggestedPostcode: "SR1 3HY" },
      { slug: "durham", name: "Durham", suggestedPostcode: "DH1 3NJ" },
      { slug: "middlesbrough", name: "Middlesbrough", suggestedPostcode: "TS1 2AZ" },
      { slug: "darlington", name: "Darlington", suggestedPostcode: "DL1 1NH" },
    ],
  },
  {
    name: "Yorkshire",
    cities: [
      { slug: "leeds", name: "Leeds", suggestedPostcode: "LS1 6AZ" },
      { slug: "sheffield", name: "Sheffield", suggestedPostcode: "S1 2GE" },
      { slug: "york", name: "York", suggestedPostcode: "YO1 9TL" },
      { slug: "bradford", name: "Bradford", suggestedPostcode: "BD1 1HJ" },
      { slug: "hull", name: "Hull", suggestedPostcode: "HU1 3EA" },
      { slug: "doncaster", name: "Doncaster", suggestedPostcode: "DN1 1NH" },
      { slug: "harrogate", name: "Harrogate", suggestedPostcode: "HG1 1BS" },
    ],
  },
  {
    name: "Wales",
    cities: [
      { slug: "cardiff", name: "Cardiff", suggestedPostcode: "CF10 1EP" },
      { slug: "swansea", name: "Swansea", suggestedPostcode: "SA1 3QW" },
      { slug: "newport", name: "Newport", suggestedPostcode: "NP20 1FW" },
      { slug: "wrexham", name: "Wrexham", suggestedPostcode: "LL11 1AY" },
      { slug: "aberystwyth", name: "Aberystwyth", suggestedPostcode: "SY23 2AX" },
    ],
  },
  {
    name: "Scotland",
    cities: [
      { slug: "edinburgh", name: "Edinburgh", suggestedPostcode: "EH1 1RE" },
      { slug: "glasgow", name: "Glasgow", suggestedPostcode: "G1 3SL" },
      { slug: "aberdeen", name: "Aberdeen", suggestedPostcode: "AB10 1XG" },
      { slug: "dundee", name: "Dundee", suggestedPostcode: "DD1 4QB" },
      { slug: "inverness", name: "Inverness", suggestedPostcode: "IV1 1QY" },
      { slug: "stirling", name: "Stirling", suggestedPostcode: "FK8 2EA" },
    ],
  },
  {
    name: "Northern Ireland",
    cities: [
      { slug: "belfast", name: "Belfast", suggestedPostcode: "BT1 5GS" },
      { slug: "derry", name: "Derry", suggestedPostcode: "BT48 6HQ" },
      { slug: "lisburn", name: "Lisburn", suggestedPostcode: "BT28 1AL" },
      { slug: "newry", name: "Newry", suggestedPostcode: "BT34 1AN" },
    ],
  },
];

// ---------------------------------------------------------------------------
// SEO metadata
// ---------------------------------------------------------------------------

export const metadata: Metadata = {
  title: "Hearing Test Locations Across the UK | hearingtest.co.uk",
  description:
    "Find and compare hearing test appointments in every major UK city and town. Browse audiologists by region, check availability, and book online in seconds.",
  keywords: [
    "hearing test near me",
    "audiologists near me",
    "hearing test locations UK",
    "book hearing test",
    "local audiologists",
    "NHS hearing test",
  ],
  openGraph: {
    title: "Hearing Test Locations Across the UK | hearingtest.co.uk",
    description:
      "Find and compare hearing test appointments in every major UK city and town. Browse audiologists by region and book online.",
    url: "https://www.hearingtest.co.uk/locations",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/locations",
  },
};

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default function LocationsPage() {
  const totalCities = regions.reduce((sum, r) => sum + r.cities.length, 0);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Hearing Test Locations Across the UK",
    description:
      "Find and compare hearing test appointments in every major UK city and town.",
    url: "https://www.hearingtest.co.uk/locations",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    mainEntity: {
      "@type": "ItemList",
      numberOfItems: totalCities,
      itemListElement: regions.flatMap((region, ri) =>
        region.cities.map((city, ci) => ({
          "@type": "ListItem",
          position: ri * 20 + ci + 1,
          name: `Hearing Tests in ${city.name}`,
          url: `https://www.hearingtest.co.uk/locations/${city.slug}`,
        }))
      ),
    },
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Locations",
        item: "https://www.hearingtest.co.uk/locations",
      },
    ],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />

        {/* Hero */}
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Locations" },
          ]}
        >
          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Find hearing tests{" "}
            <span className="text-[var(--color-primary)]">
              anywhere in the UK
            </span>
          </h1>
          <p className="text-base sm:text-lg text-white/70 mb-8 max-w-xl mx-auto">
            Browse audiologists in your area, compare prices and availability,
            and book your next hearing test online.
          </p>
        </PageHero>

        {/* Regions grid */}
        <section className="py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Browse by region
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We cover every major city and town across the UK. Select a
                region below to find audiologists near you.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {regions.map(({ name, cities }) => (
                <div
                  key={name}
                  className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center">
                      <svg
                        className="w-5 h-5 text-[var(--color-primary)]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                    </div>
                    <h3
                      className="text-lg font-semibold text-[var(--color-navy)]"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {name}
                    </h3>
                  </div>

                  <ul className="space-y-1.5">
                    {cities.slice(0, 6).map((city) => (
                      <li key={city.slug}>
                        <Link
                          href={`/locations/${city.slug}`}
                          className="flex items-center justify-between text-sm text-gray-600 hover:text-[var(--color-primary)] transition-colors py-1 group"
                        >
                          <span>{city.name}</span>
                          <svg
                            className="w-4 h-4 text-gray-300 group-hover:text-[var(--color-primary)] transition-colors"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth="2"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M9 5l7 7-7 7"
                            />
                          </svg>
                        </Link>
                      </li>
                    ))}
                  </ul>

                  {cities.length > 6 && (
                    <p className="mt-3 text-xs text-gray-400">
                      +{cities.length - 6} more location
                      {cities.length - 6 !== 1 ? "s" : ""}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why use hearingtest.co.uk */}
        <section className="py-16 sm:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Why search with hearingtest.co.uk?
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We help you find great local audiologists you didn&apos;t know
                existed. Save hours searching and book instantly.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z",
                  title: "Compare instantly",
                  desc: "See prices, availability, and services from every audiologist near you in one search.",
                },
                {
                  icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
                  title: "Same-day slots",
                  desc: "Find appointments available today, tomorrow, or at a time that suits you.",
                },
                {
                  icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
                  title: "NHS & private",
                  desc: "Filter by NHS-funded and private hearing tests. See who offers free tests.",
                },
                {
                  icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
                  title: "100% free",
                  desc: "Our service is completely free. No hidden charges, no sign-up required.",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm"
                >
                  <div className="w-12 h-12 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center text-[var(--color-primary)] mb-4">
                    <svg
                      className="w-6 h-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d={item.icon}
                      />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-[var(--color-navy)] mb-2">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-600">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Bottom CTA */}
        <section className="py-16 sm:py-20">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to book your hearing test?
            </h2>
            <p className="text-gray-600 mb-8">
              Enter your postcode to compare audiologists, check live availability,
              and book an appointment online.
            </p>
            <Link
              href="/search"
              className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:opacity-90 text-white font-semibold text-base px-8 py-4 rounded-full transition-all hover:shadow-lg"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              Find Hearing Tests Near You
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
