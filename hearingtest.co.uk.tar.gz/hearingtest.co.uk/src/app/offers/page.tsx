import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

// ---------------------------------------------------------------------------
// SEO metadata
// ---------------------------------------------------------------------------

export const metadata: Metadata = {
  title:
    "Hearing Test Offers & Deals — Compare UK Audiologist Promotions | hearingtest.co.uk",
  description:
    "Compare the latest hearing test offers and deals from Specsavers, Boots Hearingcare, Hidden Hearing, Amplifon, and more. Find free hearing tests, hearing aid discounts, and special promotions — updated regularly.",
  keywords: [
    "hearing test offers",
    "free hearing test",
    "hearing aid deals",
    "specsavers hearing test",
    "boots hearingcare offers",
    "hidden hearing deals",
    "amplifon offers",
    "cheap hearing test",
    "hearing test deals UK",
    "free hearing check",
  ],
  openGraph: {
    title:
      "Hearing Test Offers & Deals — Compare UK Audiologist Promotions | hearingtest.co.uk",
    description:
      "Compare the latest hearing test offers from major UK audiologists. Free hearing tests, hearing aid deals, and more — all in one place.",
    url: "https://www.hearingtest.co.uk/offers",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/offers",
  },
};

// ---------------------------------------------------------------------------
// Offer data
// ---------------------------------------------------------------------------

interface Offer {
  brand: string;
  slug: string;
  offerTitle: string;
  description: string;
  validDates: string;
  linkText: string;
  linkHref: string;
  color: string;
  tag: string;
}

const offers: Offer[] = [
  {
    brand: "Specsavers",
    slug: "specsavers",
    offerTitle: "Free hearing test",
    description:
      "Book a free hearing test at any Specsavers Audiologists location. The assessment includes a full audiogram and takes around 30 minutes. No referral needed — book online or in-store.",
    validDates: "Ongoing offer",
    linkText: "View Specsavers hearing",
    linkHref: "/audiologists/specsavers",
    color: "#1a4d2e",
    tag: "Free",
  },
  {
    brand: "Boots Hearingcare",
    slug: "boots-hearingcare",
    offerTitle: "Free hearing health check",
    description:
      "Boots Hearingcare offers a free 15-minute hearing health check at participating stores. If a full assessment is recommended, this is also available free of charge. Home visits available in selected areas.",
    validDates: "Ongoing offer",
    linkText: "View Boots Hearingcare",
    linkHref: "/audiologists/boots-hearingcare",
    color: "#0d4d8b",
    tag: "Free",
  },
  {
    brand: "Hidden Hearing",
    slug: "hidden-hearing",
    offerTitle: "Free home hearing test",
    description:
      "Hidden Hearing offers a completely free hearing assessment in the comfort of your own home. An HCPC-registered audiologist will visit at a time that suits you, with no obligation to purchase hearing aids.",
    validDates: "Ongoing offer",
    linkText: "View Hidden Hearing",
    linkHref: "/audiologists/hidden-hearing",
    color: "#6b2fa0",
    tag: "Free + Home Visit",
  },
  {
    brand: "THCP",
    slug: "thcp",
    offerTitle: "Free hearing assessment at your local optician",
    description:
      "The Hearing Care Partnership (THCP) provides free hearing assessments at independent optician practices across the UK. Audiologists are embedded within optician practices, making appointments convenient and easily accessible.",
    validDates: "Ongoing offer",
    linkText: "View THCP",
    linkHref: "/audiologists/thcp",
    color: "#2e5a88",
    tag: "Free",
  },
  {
    brand: "Scrivens",
    slug: "scrivens",
    offerTitle: "Free hearing test + ear wax check",
    description:
      "Scrivens offers a free hearing test that includes a complimentary ear wax check. Available at Scrivens branches across England and Wales. The assessment uses the latest audiometric equipment for accurate results.",
    validDates: "Ongoing offer",
    linkText: "View Scrivens",
    linkHref: "/audiologists/scrivens",
    color: "#c41230",
    tag: "Free + Wax Check",
  },
  {
    brand: "Amplifon",
    slug: "amplifon",
    offerTitle: "Free hearing test online and in-store",
    description:
      "Amplifon offers a free online hearing screening you can take from home, plus free in-store hearing assessments at their UK clinics. Results reviewed by qualified audiologists with personalised recommendations.",
    validDates: "Ongoing offer",
    linkText: "View Amplifon",
    linkHref: "/audiologists/amplifon",
    color: "#e6007e",
    tag: "Free + Online Option",
  },
];

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default function OffersPage() {
  /* ---- Structured data ---- */
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Hearing Test Offers & Deals — UK Audiologist Promotions",
    description:
      "Compare the latest hearing test offers and deals from major UK audiologists including Specsavers, Boots Hearingcare, Hidden Hearing, and Amplifon.",
    url: "https://www.hearingtest.co.uk/offers",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Offers",
        item: "https://www.hearingtest.co.uk/offers",
      },
    ],
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />

        {/* ================================================================ */}
        {/* 1. HERO                                                         */}
        {/* ================================================================ */}
        <PageHero
          breadcrumbs={[{ label: "Home", href: "/" }, { label: "Offers" }]}
          compact
        >
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur-sm px-4 py-1.5 text-sm text-white/90 mb-6">
            <span className="inline-block w-2 h-2 rounded-full bg-[var(--color-success)] animate-pulse" />
            Updated June 2026
          </div>

          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white mb-4 tracking-tight"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Hearing Test Offers &amp; Deals
          </h1>
          <p className="text-base sm:text-lg text-white/80 max-w-2xl mx-auto mb-8">
            Compare <strong className="text-white">{offers.length} offers</strong>{" "}
            from the UK&rsquo;s leading hearing care providers. Free hearing tests,
            home visits, and hearing aid deals &mdash; all in one place.
          </p>

          <a
            href="#offers"
            className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold text-sm sm:text-base px-8 py-3.5 rounded-full transition-all hover:shadow-lg"
          >
            View all offers
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </a>
        </PageHero>

        {/* ================================================================ */}
        {/* 2. OFFER CARDS GRID                                             */}
        {/* ================================================================ */}
        <section id="offers" className="py-16 sm:py-20 scroll-mt-24">
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Current hearing test offers
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Here are the latest deals from major UK hearing care providers.
                Most offer free hearing assessments with no obligation.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {offers.map((offer) => (
                <div
                  key={offer.slug}
                  id={offer.slug}
                  className="bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden flex flex-col"
                >
                  {/* Brand header bar */}
                  <div
                    className="px-6 py-4"
                    style={{ backgroundColor: offer.color }}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-white font-bold text-lg">
                        {offer.brand}
                      </h3>
                      <span className="text-xs bg-white/20 text-white px-3 py-1 rounded-full font-medium">
                        {offer.tag}
                      </span>
                    </div>
                  </div>

                  {/* Card body */}
                  <div className="p-6 flex-1 flex flex-col">
                    <h4
                      className="text-lg font-bold text-[var(--color-navy)] mb-2"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {offer.offerTitle}
                    </h4>
                    <p className="text-sm text-gray-600 leading-relaxed mb-4 flex-1">
                      {offer.description}
                    </p>

                    {/* Valid dates */}
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-4">
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="1.5"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5"
                        />
                      </svg>
                      <span>{offer.validDates}</span>
                    </div>

                    {/* Link to brand page */}
                    <Link
                      href={offer.linkHref}
                      className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] transition-colors"
                    >
                      {offer.linkText}
                      <svg
                        className="w-4 h-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 3. IMPORTANT NOTE                                               */}
        {/* ================================================================ */}
        <section className="py-12 sm:py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <div className="bg-white border border-gray-100 rounded-2xl p-6 sm:p-8 shadow-sm">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
                  <svg
                    className="w-5 h-5 text-amber-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
                    />
                  </svg>
                </div>
                <div>
                  <h2
                    className="text-lg font-bold text-[var(--color-navy)] mb-2"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Always check with the provider
                  </h2>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    Offers listed on this page are sourced from each
                    provider&rsquo;s website and verified regularly. However,
                    promotions may change without notice, and some offers may
                    vary by location. We recommend confirming the details
                    directly with the provider before booking your appointment.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 4. NHS HEARING TEST INFO                                        */}
        {/* ================================================================ */}
        <section className="py-12 sm:py-16 bg-[#f0f7ff]">
          <div className="max-w-4xl mx-auto px-4">
            <div className="rounded-2xl bg-white border border-[#005eb8]/10 p-6 sm:p-8 shadow-sm">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-[#005eb8] flex items-center justify-center">
                  <span className="text-white text-lg font-bold">NHS</span>
                </div>
                <div>
                  <h2
                    className="text-xl font-bold text-[var(--color-navy)] mb-2"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    NHS hearing tests are always free
                  </h2>
                  <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                    If your GP refers you to an NHS audiology department, your
                    hearing test and any hearing aids you are prescribed are
                    completely free of charge. NHS hearing aids are digital,
                    behind-the-ear models and include free batteries, repairs,
                    and follow-up appointments. Ask your GP for a referral if you
                    have concerns about your hearing.
                  </p>
                  <Link
                    href="/hearing-health/nhs-hearing-tests"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-[#005eb8] hover:underline"
                  >
                    Learn about NHS hearing tests
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 5. LAST UPDATED NOTE                                            */}
        {/* ================================================================ */}
        <section className="py-8 bg-white border-t border-gray-100">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <p className="text-xs text-gray-400">
              Offers are sourced directly from each provider&rsquo;s website and
              verified regularly. Last updated:{" "}
              <strong>June 2026</strong>. Promotions may vary by branch. Always
              confirm details with the provider before booking.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
