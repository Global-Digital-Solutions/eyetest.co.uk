import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "Privacy Policy | hearingtest.co.uk",
  description:
    "Read the hearingtest.co.uk privacy policy. Learn how we collect, use, and protect your personal data in accordance with UK GDPR.",
  openGraph: {
    title: "Privacy Policy | hearingtest.co.uk",
    description:
      "Read the hearingtest.co.uk privacy policy. Learn how we collect, use, and protect your personal data in accordance with UK GDPR.",
    url: "https://www.hearingtest.co.uk/privacy",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/privacy",
  },
};

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Privacy Policy" },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Privacy Policy
          </h1>
          <p className="mt-4 text-lg text-white/90">
            Last updated: June 2025
          </p>
        </PageHero>

        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="prose prose-lg max-w-none prose-headings:font-semibold prose-headings:text-[var(--color-navy)]">
            <p>
              This privacy policy explains how <strong>hearingtest.co.uk</strong>{" "}
              (operated by <strong>Global Digital Solutions Limited</strong>)
              collects, uses, stores, and protects your personal data when you
              use our website. We are committed to protecting your privacy and
              complying with the UK General Data Protection Regulation (UK GDPR)
              and the Data Protection Act 2018.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              1. Who we are
            </h2>
            <p>
              hearingtest.co.uk is operated by Global Digital Solutions Limited,
              a company registered in England and Wales. For the purposes of
              data protection law, we are the data controller.
            </p>
            <p>
              If you have any questions about this policy or your personal data,
              you can contact us at:{" "}
              <a href="mailto:info@hearingtest.co.uk">info@hearingtest.co.uk</a>
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              2. What data we collect
            </h2>
            <p>We may collect the following types of personal data:</p>
            <ul>
              <li>
                <strong>Information you provide:</strong> Your name, email
                address, phone number, and postcode when you submit a form or
                enquiry on our website.
              </li>
              <li>
                <strong>Usage data:</strong> Information about how you use our
                website, including pages visited, time spent on pages, and
                navigation paths.
              </li>
              <li>
                <strong>Technical data:</strong> Your IP address, browser type
                and version, operating system, device type, and screen
                resolution.
              </li>
              <li>
                <strong>Location data:</strong> Your approximate location based
                on the postcode you enter when searching for hearing tests.
              </li>
              <li>
                <strong>Cookie data:</strong> Information collected through
                cookies and similar technologies (see our cookies section
                below).
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              3. How we use your data
            </h2>
            <p>We use your personal data for the following purposes:</p>
            <ul>
              <li>
                To provide our service — helping you find and compare hearing
                test providers near you
              </li>
              <li>
                To respond to your enquiries and provide customer support
              </li>
              <li>
                To improve our website and services through analytics and user
                feedback
              </li>
              <li>
                To send you relevant information about hearing test services, if
                you have opted in to receive communications from us
              </li>
              <li>
                To comply with legal obligations and protect our legitimate
                interests
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              4. Legal basis for processing
            </h2>
            <p>
              We process your personal data on the following legal bases under
              UK GDPR:
            </p>
            <ul>
              <li>
                <strong>Consent:</strong> Where you have given clear consent for
                us to process your personal data for a specific purpose, such as
                subscribing to communications.
              </li>
              <li>
                <strong>Legitimate interests:</strong> Where processing is
                necessary for our legitimate interests, such as improving our
                service and understanding how users interact with our website.
              </li>
              <li>
                <strong>Legal obligation:</strong> Where we need to process your
                data to comply with a legal requirement.
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>5. Cookies</h2>
            <p>
              Our website uses cookies and similar technologies to improve your
              experience and help us understand how the site is used. We use the
              following types of cookies:
            </p>
            <ul>
              <li>
                <strong>Essential cookies:</strong> Required for the website to
                function properly. These cannot be disabled.
              </li>
              <li>
                <strong>Analytics cookies:</strong> Help us understand how
                visitors use our website (e.g. Google Analytics). These collect
                anonymised data about page views, traffic sources, and user
                behaviour.
              </li>
              <li>
                <strong>Functional cookies:</strong> Remember your preferences
                and settings, such as your postcode for repeat searches.
              </li>
            </ul>
            <p>
              You can control and manage cookies through your browser settings.
              Please note that disabling certain cookies may affect the
              functionality of our website.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              6. Third-party services
            </h2>
            <p>
              We use the following third-party services that may process your
              data:
            </p>
            <ul>
              <li>
                <strong>Google Analytics:</strong> For website usage analysis.
                Google processes data in accordance with their privacy policy.
              </li>
              <li>
                <strong>Mapbox:</strong> For displaying maps and location-based
                search results.
              </li>
              <li>
                <strong>Vercel:</strong> Our website hosting provider.
              </li>
              <li>
                <strong>Supabase:</strong> Our database provider for storing
                service-related data.
              </li>
            </ul>
            <p>
              We do not sell your personal data to third parties. We only share
              data with third parties where necessary to provide our service or
              where required by law.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              7. Data retention
            </h2>
            <p>
              We retain your personal data only for as long as necessary to
              fulfil the purposes for which it was collected:
            </p>
            <ul>
              <li>
                <strong>Enquiry data:</strong> Retained for up to 2 years after
                your last interaction with us.
              </li>
              <li>
                <strong>Analytics data:</strong> Retained in anonymised form for
                up to 26 months.
              </li>
              <li>
                <strong>Cookie data:</strong> Retained for the duration
                specified in our cookie settings, typically up to 12 months.
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              8. Your rights under UK GDPR
            </h2>
            <p>
              Under UK data protection law, you have the following rights
              regarding your personal data:
            </p>
            <ul>
              <li>
                <strong>Right of access:</strong> You can request a copy of the
                personal data we hold about you.
              </li>
              <li>
                <strong>Right to rectification:</strong> You can ask us to
                correct any inaccurate or incomplete data.
              </li>
              <li>
                <strong>Right to erasure:</strong> You can ask us to delete your
                personal data in certain circumstances.
              </li>
              <li>
                <strong>Right to restrict processing:</strong> You can ask us to
                limit how we use your data.
              </li>
              <li>
                <strong>Right to data portability:</strong> You can request your
                data in a structured, commonly used format.
              </li>
              <li>
                <strong>Right to object:</strong> You can object to processing
                based on legitimate interests or for direct marketing purposes.
              </li>
              <li>
                <strong>Right to withdraw consent:</strong> Where we rely on
                consent, you can withdraw it at any time.
              </li>
            </ul>
            <p>
              To exercise any of these rights, please contact us at{" "}
              <a href="mailto:info@hearingtest.co.uk">info@hearingtest.co.uk</a>
              . We will respond to your request within one month.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              9. Data security
            </h2>
            <p>
              We take appropriate technical and organisational measures to
              protect your personal data against unauthorised access, loss,
              destruction, or alteration. Our website uses HTTPS encryption, and
              we regularly review our security practices.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              10. Children&apos;s privacy
            </h2>
            <p>
              Our website is not directed at children under 16. We do not
              knowingly collect personal data from children. If you believe we
              have inadvertently collected data from a child, please contact us
              and we will delete it promptly.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              11. Changes to this policy
            </h2>
            <p>
              We may update this privacy policy from time to time. Any changes
              will be posted on this page with an updated &quot;Last
              updated&quot; date. We encourage you to review this policy
              periodically.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              12. Complaints
            </h2>
            <p>
              If you are not satisfied with how we handle your personal data,
              you have the right to lodge a complaint with the Information
              Commissioner&apos;s Office (ICO), the UK&apos;s supervisory
              authority for data protection:
            </p>
            <ul>
              <li>
                Website:{" "}
                <a
                  href="https://ico.org.uk"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  ico.org.uk
                </a>
              </li>
              <li>Telephone: 0303 123 1113</li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              13. Contact us
            </h2>
            <p>
              If you have any questions about this privacy policy or how we
              handle your personal data, please contact us:
            </p>
            <ul>
              <li>
                Email:{" "}
                <a href="mailto:info@hearingtest.co.uk">
                  info@hearingtest.co.uk
                </a>
              </li>
              <li>Company: Global Digital Solutions Limited</li>
            </ul>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
