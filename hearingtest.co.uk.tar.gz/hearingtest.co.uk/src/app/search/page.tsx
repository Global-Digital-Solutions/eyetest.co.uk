import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Find Hearing Tests Near You | hearingtest.co.uk",
  description:
    "Search for hearing test appointments near you. Compare audiologists, check availability, and book online across the UK.",
  openGraph: {
    title: "Find Hearing Tests Near You | hearingtest.co.uk",
    description:
      "Search for hearing test appointments near you. Compare audiologists, check availability, and book online across the UK.",
    url: "https://www.hearingtest.co.uk/search",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/search",
  },
};

export default function SearchPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <h1 className="sr-only">Find hearing tests near you</h1>

        {/* Search bar */}
        <section className="bg-gradient-to-br from-[var(--color-navy)] to-[var(--color-primary)] py-10 md:py-14">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2
              className="text-2xl md:text-3xl font-bold text-white text-center"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Search for hearing tests
            </h2>
            <p className="mt-2 text-center text-white/80">
              Enter your postcode to find audiologists near you
            </p>
            <div className="mt-6 flex items-center gap-3">
              <div className="relative flex-1">
                <svg
                  className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                  />
                </svg>
                <input
                  type="text"
                  placeholder="Enter your postcode, e.g. SW1A 1AA"
                  className="w-full rounded-full border-0 bg-white py-3.5 pl-12 pr-4 text-base text-[var(--color-navy)] placeholder:text-gray-400 shadow-lg focus:outline-none focus:ring-2 focus:ring-white/50"
                  aria-label="Postcode"
                />
              </div>
              <button
                type="button"
                className="rounded-full bg-white px-6 py-3.5 text-base font-semibold text-[var(--color-primary)] shadow-lg transition hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-white/50"
              >
                Search
              </button>
            </div>
          </div>
        </section>

        {/* Search results placeholder */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[var(--color-primary)]/10">
              <svg
                className="h-8 w-8 text-[var(--color-primary)]"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
                />
              </svg>
            </div>
            <h3
              className="mt-4 text-xl font-semibold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Find hearing tests near you
            </h3>
            <p className="mt-2 text-gray-600 max-w-md mx-auto">
              Enter your postcode above to search for hearing tests near you.
              We&apos;ll compare availability from audiologists across the UK.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
