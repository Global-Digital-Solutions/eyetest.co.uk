import type { MetadataRoute } from "next";
import { getAllSlugs as getAllHearingTestSlugs } from "@/data/hearing-tests";
import { getAllConditionSlugs, getAllGuideSlugs } from "@/data/hearing-health";
import { getAllArticleSlugs } from "@/data/articles";
import { audiologists, getAllAudiologistSlugs } from "@/data/audiologists";
import { getAllLocationSlugs } from "@/data/locations";
import { getAllSearchQuerySlugs } from "@/data/search-queries";

const BASE = "https://www.hearingtest.co.uk";
const NOW = new Date().toISOString();

export default function sitemap(): MetadataRoute.Sitemap {
  /* ------------------------------------------------------------------ */
  /* Static pages                                                        */
  /* ------------------------------------------------------------------ */

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${BASE}/`, lastModified: NOW, changeFrequency: "daily", priority: 1.0 },
    { url: `${BASE}/search`, lastModified: NOW, changeFrequency: "weekly", priority: 0.9 },
    { url: `${BASE}/hearing-tests`, lastModified: NOW, changeFrequency: "weekly", priority: 0.9 },
    { url: `${BASE}/hearing-health`, lastModified: NOW, changeFrequency: "weekly", priority: 0.8 },
    { url: `${BASE}/articles`, lastModified: NOW, changeFrequency: "weekly", priority: 0.8 },
    { url: `${BASE}/audiologists`, lastModified: NOW, changeFrequency: "weekly", priority: 0.9 },
    { url: `${BASE}/locations`, lastModified: NOW, changeFrequency: "weekly", priority: 0.8 },
    { url: `${BASE}/find`, lastModified: NOW, changeFrequency: "weekly", priority: 0.7 },
    { url: `${BASE}/offers`, lastModified: NOW, changeFrequency: "weekly", priority: 0.6 },
    { url: `${BASE}/get-listed`, lastModified: NOW, changeFrequency: "monthly", priority: 0.5 },
    { url: `${BASE}/at-home-hearing-tests`, lastModified: NOW, changeFrequency: "monthly", priority: 0.7 },
    { url: `${BASE}/about`, lastModified: NOW, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/privacy`, lastModified: NOW, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/terms`, lastModified: NOW, changeFrequency: "monthly", priority: 0.3 },
    { url: `${BASE}/disclaimer`, lastModified: NOW, changeFrequency: "monthly", priority: 0.3 },
  ];

  /* ------------------------------------------------------------------ */
  /* Hearing tests — /hearing-tests/[slug]                               */
  /* ------------------------------------------------------------------ */

  const hearingTestPages: MetadataRoute.Sitemap = getAllHearingTestSlugs().map(
    (slug) => ({
      url: `${BASE}/hearing-tests/${slug}`,
      lastModified: NOW,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Hearing health conditions — /hearing-health/conditions/[slug]       */
  /* ------------------------------------------------------------------ */

  const conditionPages: MetadataRoute.Sitemap = getAllConditionSlugs().map(
    (slug) => ({
      url: `${BASE}/hearing-health/conditions/${slug}`,
      lastModified: NOW,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Hearing health guides — /hearing-health/guides/[slug]               */
  /* ------------------------------------------------------------------ */

  const guidePages: MetadataRoute.Sitemap = getAllGuideSlugs().map(
    (slug) => ({
      url: `${BASE}/hearing-health/guides/${slug}`,
      lastModified: NOW,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Articles — /articles/[slug]                                         */
  /* ------------------------------------------------------------------ */

  const articlePages: MetadataRoute.Sitemap = getAllArticleSlugs().map(
    (slug) => ({
      url: `${BASE}/articles/${slug}`,
      lastModified: NOW,
      changeFrequency: "weekly" as const,
      priority: 0.6,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Audiologists — /audiologists/[slug]                                  */
  /* ------------------------------------------------------------------ */

  const audiologistPages: MetadataRoute.Sitemap = getAllAudiologistSlugs().map(
    (slug) => ({
      url: `${BASE}/audiologists/${slug}`,
      lastModified: NOW,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Audiologist × Location — /audiologists/[brand]/[location]           */
  /* ------------------------------------------------------------------ */

  const brandLocationPages: MetadataRoute.Sitemap = audiologists.flatMap(
    (a) =>
      a.storeLocations.map((loc) => ({
        url: `${BASE}/audiologists/${a.slug}/${loc}`,
        lastModified: NOW,
        changeFrequency: "weekly" as const,
        priority: 0.6,
      }))
  );

  /* ------------------------------------------------------------------ */
  /* Locations — /locations/[city]                                       */
  /* ------------------------------------------------------------------ */

  const locationPages: MetadataRoute.Sitemap = getAllLocationSlugs().map(
    (slug) => ({
      url: `${BASE}/locations/${slug}`,
      lastModified: NOW,
      changeFrequency: "weekly" as const,
      priority: 0.6,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Find / search queries — /find/[slug]                                */
  /* ------------------------------------------------------------------ */

  const findPages: MetadataRoute.Sitemap = getAllSearchQuerySlugs().map(
    (slug) => ({
      url: `${BASE}/find/${slug}`,
      lastModified: NOW,
      changeFrequency: "monthly" as const,
      priority: 0.5,
    })
  );

  /* ------------------------------------------------------------------ */
  /* Combined                                                            */
  /* ------------------------------------------------------------------ */

  return [
    ...staticPages,
    ...hearingTestPages,
    ...conditionPages,
    ...guidePages,
    ...articlePages,
    ...audiologistPages,
    ...brandLocationPages,
    ...locationPages,
    ...findPages,
  ];
}
