import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

export const metadata: Metadata = {
  title: "Terms and Conditions | hearingtest.co.uk",
  description:
    "Read the terms and conditions for using hearingtest.co.uk. Understand your rights and responsibilities when using our hearing test comparison service.",
  openGraph: {
    title: "Terms and Conditions | hearingtest.co.uk",
    description:
      "Read the terms and conditions for using hearingtest.co.uk. Understand your rights and responsibilities when using our hearing test comparison service.",
    url: "https://www.hearingtest.co.uk/terms",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/terms",
  },
};

export default function TermsPage() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <PageHero
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Terms and Conditions" },
          ]}
          compact
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Terms and Conditions
          </h1>
          <p className="mt-4 text-lg text-white/90">
            Last updated: June 2025
          </p>
        </PageHero>

        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          <div className="prose prose-lg max-w-none prose-headings:font-semibold prose-headings:text-[var(--color-navy)]">
            <p>
              Please read these terms and conditions carefully before using the
              hearingtest.co.uk website. By accessing or using this website, you
              agree to be bound by these terms. If you do not agree, please do
              not use the website.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              1. Acceptance of terms
            </h2>
            <p>
              These terms and conditions govern your use of the
              hearingtest.co.uk website (the &quot;Website&quot;), operated by
              Global Digital Solutions Limited (the &quot;Company&quot;,
              &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;). By using the
              Website, you confirm that you accept these terms and agree to
              comply with them. These terms apply to all visitors, users, and
              others who access the Website.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              2. About our service
            </h2>
            <p>
              hearingtest.co.uk is a comparison and information service that
              helps users find and compare hearing test providers across the UK.
              We aggregate availability information from audiologist chains and
              independent providers to help you find appointments near you.
            </p>
            <p>
              <strong>We are not a healthcare provider.</strong> We do not
              provide hearing tests, medical advice, or audiological services.
              When you book a hearing test through our website, your appointment
              is with the third-party provider, not with us. The provider&apos;s
              own terms and conditions will apply to your appointment.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              3. Use of the website
            </h2>
            <p>You agree to use the Website only for lawful purposes and in a manner that does not:</p>
            <ul>
              <li>
                Infringe the rights of, restrict, or inhibit the use and
                enjoyment of the Website by any third party
              </li>
              <li>
                Introduce viruses, trojans, worms, or other malicious software
              </li>
              <li>
                Attempt to gain unauthorised access to the Website, its servers,
                or any connected database
              </li>
              <li>
                Use automated systems, bots, or scrapers to access or extract
                data from the Website without our written permission
              </li>
              <li>
                Reproduce, duplicate, copy, sell, or otherwise exploit any
                portion of the Website for commercial purposes without our
                express written consent
              </li>
            </ul>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              4. Information accuracy
            </h2>
            <p>
              We make reasonable efforts to ensure that the information on our
              Website is accurate and up to date. However, we do not guarantee
              the accuracy, completeness, or reliability of any information
              provided, including but not limited to:
            </p>
            <ul>
              <li>Hearing test availability and appointment times</li>
              <li>Pricing information for hearing tests and hearing aids</li>
              <li>Provider locations and opening hours</li>
              <li>
                Health and medical information published on the Website
              </li>
            </ul>
            <p>
              Availability and pricing information is sourced from third-party
              providers and may change without notice. Always confirm details
              directly with your chosen provider before attending an
              appointment.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              5. Medical disclaimer
            </h2>
            <p>
              The health-related content on this Website is provided for general
              informational purposes only and is not intended as a substitute
              for professional medical advice, diagnosis, or treatment. Always
              seek the advice of a qualified audiologist, GP, or other
              healthcare professional with any questions regarding a medical
              condition or your hearing health.
            </p>
            <p>
              Never disregard professional medical advice or delay seeking it
              because of something you have read on this Website.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              6. Intellectual property
            </h2>
            <p>
              All content on the Website — including text, graphics, logos,
              icons, images, audio clips, data compilations, and software — is
              the property of Global Digital Solutions Limited or its content
              suppliers and is protected by UK and international copyright,
              trademark, and other intellectual property laws.
            </p>
            <p>
              You may not reproduce, distribute, modify, create derivative
              works from, publicly display, or otherwise use any content from
              the Website without our prior written permission, except for
              personal, non-commercial use such as viewing pages or printing
              individual pages for your own reference.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              7. Third-party links
            </h2>
            <p>
              The Website may contain links to third-party websites and
              services. These links are provided for your convenience and do
              not imply endorsement by us. We have no control over the content,
              privacy policies, or practices of third-party websites and accept
              no responsibility for them. We encourage you to review the terms
              and privacy policies of any third-party websites you visit.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              8. Limitation of liability
            </h2>
            <p>
              To the fullest extent permitted by law, Global Digital Solutions
              Limited shall not be liable for any direct, indirect, incidental,
              special, consequential, or punitive damages arising from:
            </p>
            <ul>
              <li>Your use of, or inability to use, the Website</li>
              <li>
                Any errors or omissions in the Website&apos;s content
              </li>
              <li>
                Any action taken by you in reliance on information provided on
                the Website
              </li>
              <li>
                Any issues arising from appointments booked through third-party
                providers found via the Website
              </li>
              <li>
                Any unauthorised access to or alteration of your data
              </li>
            </ul>
            <p>
              Nothing in these terms excludes or limits our liability for death
              or personal injury caused by our negligence, fraud or fraudulent
              misrepresentation, or any other liability that cannot be excluded
              or limited by English law.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              9. Indemnification
            </h2>
            <p>
              You agree to indemnify, defend, and hold harmless Global Digital
              Solutions Limited, its directors, officers, employees, and agents
              from and against any claims, liabilities, damages, losses, and
              expenses arising from your use of the Website or your violation
              of these terms.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              10. Modifications to terms
            </h2>
            <p>
              We reserve the right to modify these terms at any time. Changes
              will be effective immediately upon posting on the Website with an
              updated &quot;Last updated&quot; date. Your continued use of the
              Website after changes are posted constitutes your acceptance of
              the modified terms.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              11. Termination
            </h2>
            <p>
              We may suspend or terminate your access to the Website at any
              time, without prior notice or liability, for any reason,
              including if you breach these terms. Upon termination, your right
              to use the Website will cease immediately.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              12. Governing law
            </h2>
            <p>
              These terms and conditions are governed by and construed in
              accordance with the laws of England and Wales. Any disputes
              arising from these terms or your use of the Website shall be
              subject to the exclusive jurisdiction of the courts of England
              and Wales.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              13. Severability
            </h2>
            <p>
              If any provision of these terms is found to be invalid or
              unenforceable by a court of competent jurisdiction, the remaining
              provisions shall remain in full force and effect.
            </p>

            <h2 style={{ fontFamily: "var(--font-display)" }}>
              14. Contact us
            </h2>
            <p>
              If you have any questions about these terms and conditions, please
              contact us:
            </p>
            <ul>
              <li>
                Email:{" "}
                <a href="mailto:info@hearingtest.co.uk">
                  info@hearingtest.co.uk
                </a>
              </li>
              <li>Company: Global Digital Solutions Limited</li>
            </ul>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
