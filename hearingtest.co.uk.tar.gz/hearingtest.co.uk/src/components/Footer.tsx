import Link from "next/link";
import { hearingTests } from "@/data/hearing-tests";
import { hearingConditions, hearingGuides } from "@/data/hearing-health";
import { audiologists } from "@/data/audiologists";
import { articles } from "@/data/articles";
import { searchQueries } from "@/data/search-queries";

/* ------------------------------------------------------------------ */
/*  Footer link data (derived from data files)                         */
/* ------------------------------------------------------------------ */

const footerLinks = {
  "Hearing Tests": [
    ...hearingTests.slice(0, 10).map((t) => ({
      label: t.name,
      href: `/hearing-tests/${t.slug}`,
    })),
    { label: "View All Hearing Tests", href: "/hearing-tests" },
  ],
  Audiologists: [
    ...audiologists.slice(0, 9).map((a) => ({
      label: a.shortName,
      href: `/audiologists/${a.slug}`,
    })),
    { label: "Compare All Audiologists", href: "/audiologists" },
  ],
  "Hearing Health": [
    ...hearingConditions.slice(0, 6).map((c) => ({
      label: c.name,
      href: `/hearing-health/conditions/${c.slug}`,
    })),
    ...hearingGuides.slice(0, 2).map((g) => ({
      label: g.title.length > 30 ? g.title.slice(0, 30) + "..." : g.title,
      href: `/hearing-health/guides/${g.slug}`,
    })),
    { label: "Hearing Health Hub", href: "/hearing-health" },
  ],
  Resources: [
    ...articles.slice(0, 4).map((a) => ({
      label: a.title.length > 35 ? a.title.slice(0, 35) + "..." : a.title,
      href: `/articles/${a.slug}`,
    })),
    ...searchQueries.slice(0, 3).map((q) => ({
      label: q.keyword,
      href: `/find/${q.slug}`,
    })),
    { label: "All Articles", href: "/articles" },
    { label: "All Search Topics", href: "/find" },
    { label: "About Us", href: "/about" },
    { label: "Get Listed", href: "/get-listed" },
  ],
};

/* ------------------------------------------------------------------ */
/*  SEO locations grid                                                 */
/* ------------------------------------------------------------------ */

const seoLocations: Record<string, { label: string; href: string }[]> = {
  London: [
    { label: "London", href: "/locations/london" },
    { label: "Croydon", href: "/locations/croydon" },
    { label: "Bromley", href: "/locations/bromley" },
    { label: "Kingston upon Thames", href: "/locations/kingston-upon-thames" },
    { label: "Richmond", href: "/locations/richmond" },
    { label: "Ealing", href: "/locations/ealing" },
  ],
  "South East": [
    { label: "Brighton", href: "/locations/brighton" },
    { label: "Southampton", href: "/locations/southampton" },
    { label: "Portsmouth", href: "/locations/portsmouth" },
    { label: "Reading", href: "/locations/reading" },
    { label: "Oxford", href: "/locations/oxford" },
    { label: "Canterbury", href: "/locations/canterbury" },
    { label: "Guildford", href: "/locations/guildford" },
    { label: "Milton Keynes", href: "/locations/milton-keynes" },
    { label: "Maidstone", href: "/locations/maidstone" },
    { label: "Slough", href: "/locations/slough" },
    { label: "Crawley", href: "/locations/crawley" },
    { label: "Basingstoke", href: "/locations/basingstoke" },
    { label: "Tunbridge Wells", href: "/locations/tunbridge-wells" },
    { label: "Woking", href: "/locations/woking" },
    { label: "Epsom", href: "/locations/epsom" },
  ],
  "South West": [
    { label: "Bristol", href: "/locations/bristol" },
    { label: "Plymouth", href: "/locations/plymouth" },
    { label: "Exeter", href: "/locations/exeter" },
    { label: "Bath", href: "/locations/bath" },
    { label: "Cheltenham", href: "/locations/cheltenham" },
    { label: "Gloucester", href: "/locations/gloucester" },
    { label: "Swindon", href: "/locations/swindon" },
    { label: "Bournemouth", href: "/locations/bournemouth" },
    { label: "Salisbury", href: "/locations/salisbury" },
    { label: "Taunton", href: "/locations/taunton" },
    { label: "Torquay", href: "/locations/torquay" },
  ],
  "East of England": [
    { label: "Norwich", href: "/locations/norwich" },
    { label: "Cambridge", href: "/locations/cambridge" },
    { label: "Ipswich", href: "/locations/ipswich" },
    { label: "Colchester", href: "/locations/colchester" },
    { label: "Chelmsford", href: "/locations/chelmsford" },
    { label: "Luton", href: "/locations/luton" },
    { label: "Southend-on-Sea", href: "/locations/southend-on-sea" },
    { label: "Peterborough", href: "/locations/peterborough" },
    { label: "St Albans", href: "/locations/st-albans" },
    { label: "Watford", href: "/locations/watford" },
  ],
  "West Midlands": [
    { label: "Birmingham", href: "/locations/birmingham" },
    { label: "Coventry", href: "/locations/coventry" },
    { label: "Wolverhampton", href: "/locations/wolverhampton" },
    { label: "Stoke-on-Trent", href: "/locations/stoke-on-trent" },
    { label: "Worcester", href: "/locations/worcester" },
    { label: "Hereford", href: "/locations/hereford" },
  ],
  "East Midlands": [
    { label: "Nottingham", href: "/locations/nottingham" },
    { label: "Leicester", href: "/locations/leicester" },
    { label: "Derby", href: "/locations/derby" },
    { label: "Northampton", href: "/locations/northampton" },
    { label: "Lincoln", href: "/locations/lincoln" },
  ],
  "North West": [
    { label: "Manchester", href: "/locations/manchester" },
    { label: "Liverpool", href: "/locations/liverpool" },
    { label: "Preston", href: "/locations/preston" },
    { label: "Bolton", href: "/locations/bolton" },
    { label: "Blackpool", href: "/locations/blackpool" },
    { label: "Chester", href: "/locations/chester" },
    { label: "Warrington", href: "/locations/warrington" },
    { label: "Wigan", href: "/locations/wigan" },
    { label: "Lancaster", href: "/locations/lancaster" },
  ],
  "North East": [
    { label: "Newcastle", href: "/locations/newcastle" },
    { label: "Sunderland", href: "/locations/sunderland" },
    { label: "Middlesbrough", href: "/locations/middlesbrough" },
    { label: "Durham", href: "/locations/durham" },
    { label: "Darlington", href: "/locations/darlington" },
  ],
  Yorkshire: [
    { label: "Leeds", href: "/locations/leeds" },
    { label: "Sheffield", href: "/locations/sheffield" },
    { label: "Bradford", href: "/locations/bradford" },
    { label: "Hull", href: "/locations/hull" },
    { label: "York", href: "/locations/york" },
    { label: "Huddersfield", href: "/locations/huddersfield" },
    { label: "Doncaster", href: "/locations/doncaster" },
    { label: "Harrogate", href: "/locations/harrogate" },
  ],
  Wales: [
    { label: "Cardiff", href: "/locations/cardiff" },
    { label: "Swansea", href: "/locations/swansea" },
    { label: "Newport", href: "/locations/newport" },
    { label: "Wrexham", href: "/locations/wrexham" },
    { label: "Bangor", href: "/locations/bangor" },
    { label: "Aberystwyth", href: "/locations/aberystwyth" },
  ],
  Scotland: [
    { label: "Glasgow", href: "/locations/glasgow" },
    { label: "Edinburgh", href: "/locations/edinburgh" },
    { label: "Aberdeen", href: "/locations/aberdeen" },
    { label: "Dundee", href: "/locations/dundee" },
    { label: "Inverness", href: "/locations/inverness" },
    { label: "Stirling", href: "/locations/stirling" },
    { label: "Perth", href: "/locations/perth" },
  ],
  "Northern Ireland": [
    { label: "Belfast", href: "/locations/belfast" },
    { label: "Derry", href: "/locations/derry" },
    { label: "Lisburn", href: "/locations/lisburn" },
  ],
};

/* ------------------------------------------------------------------ */
/*  Component                                                         */
/* ------------------------------------------------------------------ */

export default function Footer() {
  return (
    <footer className="bg-[var(--color-navy)] text-white">
      {/* ── Postcode search bar ────────────────────────────────────── */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="max-w-xl mx-auto text-center">
            <h3
              className="text-xl font-bold text-white mb-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Find hearing tests near you
            </h3>
            <p className="text-sm text-white/60 mb-5">
              Enter your postcode to compare audiologists and book online
            </p>
            <form action="/search" method="GET" className="flex flex-col sm:flex-row gap-3 sm:gap-0 sm:bg-white/10 sm:backdrop-blur-sm sm:rounded-full sm:p-1.5">
              <div className="relative flex-1">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  name="postcode"
                  placeholder="Enter your postcode, e.g. SW1A 1AA"
                  className="w-full pl-12 pr-4 py-3 text-sm text-white bg-white/10 sm:bg-transparent rounded-xl sm:rounded-full border border-white/20 sm:border-none focus:outline-none placeholder:text-white/40"
                  aria-label="Enter your postcode"
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 bg-[var(--color-primary)] hover:bg-blue-700 text-white font-semibold text-sm px-6 py-3 rounded-xl sm:rounded-full transition-all cursor-pointer"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Search
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* ── Main footer links ──────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 py-12 sm:py-16">
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-sm font-semibold text-white/80 uppercase tracking-wider mb-4">
                {category}
              </h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-white/50 hover:text-white transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* ── SEO locations grid ─────────────────────────────────────── */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <h3
            className="text-base font-bold text-white/80 mb-6"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Hearing Tests Across the UK
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-6">
            {Object.entries(seoLocations).map(([region, cities]) => (
              <div key={region}>
                <h4 className="text-xs font-semibold text-white/60 uppercase tracking-wider mb-2">
                  {region}
                </h4>
                <ul className="space-y-1">
                  {cities.map((city) => (
                    <li key={city.href}>
                      <Link
                        href={city.href}
                        className="text-xs text-white/40 hover:text-white/80 transition-colors"
                      >
                        {city.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <Link
              href="/locations"
              className="text-xs font-medium text-[var(--color-primary)] hover:text-blue-400 transition-colors"
            >
              View all UK locations &rarr;
            </Link>
          </div>
        </div>
      </div>

      {/* ── Bottom bar ─────────────────────────────────────────────── */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
            <Link href="/" className="flex items-center gap-2">
              <svg
                className="w-6 h-6 text-[var(--color-primary)]"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M6 8.5a6 6 0 0 1 12 0c0 3-2 4.5-2 7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2c0-1.5-.5-2-1.5-3" />
                <path d="M11 12.5a2 2 0 0 0 2 2" />
                <path d="M13.5 8.5a2.5 2.5 0 0 0-5 0" />
              </svg>
              <span
                className="text-base font-bold text-white"
                style={{ fontFamily: "var(--font-display)" }}
              >
                hearingtest.co.uk
              </span>
            </Link>
            <div className="flex items-center gap-4 text-xs text-white/40">
              <Link href="/privacy" className="hover:text-white/70 transition-colors">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-white/70 transition-colors">Terms of Service</Link>
              <Link href="/disclaimer" className="hover:text-white/70 transition-colors">Disclaimer</Link>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-white/10">
            <div className="text-xs text-white/30 text-center sm:text-left">
              <p>&copy; {new Date().getFullYear()} hearingtest.co.uk &mdash; Global Digital Solutions Limited</p>
              <p className="mt-0.5">20a High Street, Glastonbury, Somerset, BA6 9DU</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-white/40">
              <a href="mailto:help@hearingtest.co.uk" className="hover:text-white/70 transition-colors">
                help@hearingtest.co.uk
              </a>
              <span className="w-px h-3 bg-white/20" />
              <a href="tel:02081230993" className="hover:text-white/70 transition-colors">
                0208 1230993
              </a>
              <span className="w-px h-3 bg-white/20" />
              <a
                href="https://www.eyetest.co.uk"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white/70 transition-colors"
              >
                Sister site: eyetest.co.uk
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
