// =============================================================================
// hearing-health.ts
// Hearing conditions and guides data for hearingtest.co.uk
// =============================================================================

export type HearingCondition = {
  slug: string;
  name: string;
  shortDescription: string;
  fullDescription: string;
  symptoms: string[];
  causes: string[];
  treatments: string[];
  whenToSeek: string;
  icon: string;
  relatedConditions: string[];
  relatedTests: string[];
};

export type HearingGuide = {
  slug: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  keyPoints: string[];
  icon: string;
  relatedGuides: string[];
};

// =============================================================================
// HEARING CONDITIONS (22)
// =============================================================================

export const hearingConditions: HearingCondition[] = [
  // -------------------------------------------------------------------------
  // 1. Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "hearing-loss",
    name: "Hearing Loss",
    shortDescription:
      "A common condition affecting around 12 million adults in the UK, hearing loss ranges from mild difficulty following conversations to profound deafness.",
    fullDescription: `Hearing loss is one of the most prevalent health conditions in the United Kingdom, affecting approximately 12 million adults — roughly one in five of the population. It can occur at any age, though it becomes significantly more common as people get older. Understanding the different types and degrees of hearing loss is the first step towards effective management and treatment.

There are three main types of hearing loss. Sensorineural hearing loss is the most common form and occurs when the tiny hair cells in the inner ear (cochlea) or the auditory nerve become damaged. This type is usually permanent and is most often associated with ageing or prolonged noise exposure. Conductive hearing loss happens when sound cannot pass efficiently through the outer or middle ear — common causes include ear wax build-up, fluid in the middle ear, a perforated eardrum, or problems with the tiny bones (ossicles) in the middle ear. Mixed hearing loss is a combination of both sensorineural and conductive components.

Hearing loss is measured in decibels (dB) and categorised by severity. Mild hearing loss (26-40 dB) means you may struggle to follow speech in noisy environments. Moderate loss (41-70 dB) makes it difficult to follow normal conversation without hearing aids. Severe (71-90 dB) and profound (91 dB or more) hearing loss mean you may rely heavily on hearing aids, cochlear implants, lip-reading, or sign language.

In the UK, the NHS provides free hearing tests and hearing aids to those who need them. Your GP is usually the first point of contact and can refer you to an NHS audiology department. Private audiologists also offer comprehensive hearing assessments, often with shorter waiting times and a wider range of hearing aid styles. Early identification is crucial — untreated hearing loss has been linked to social isolation, depression, cognitive decline, and an increased risk of dementia. If you suspect you or a family member may have hearing loss, booking a hearing test is a straightforward and important first step.`,
    symptoms: [
      "Difficulty following conversations, especially in noisy environments",
      "Frequently asking people to repeat themselves",
      "Turning up the volume on the television or radio higher than others find comfortable",
      "Difficulty hearing on the telephone",
      "Feeling that others are mumbling or not speaking clearly",
      "Withdrawing from social situations due to difficulty hearing",
      "Trouble hearing high-pitched sounds such as doorbells or birdsong",
      "A sensation of fullness or pressure in the ears",
    ],
    causes: [
      "Ageing (presbycusis) — the most common cause in the UK",
      "Prolonged or repeated exposure to loud noise (occupational or recreational)",
      "Ear infections or fluid build-up in the middle ear",
      "Genetic factors and family history of hearing loss",
      "Certain medications (ototoxic drugs) including some antibiotics and chemotherapy agents",
      "Head injuries or trauma to the ear",
    ],
    treatments: [
      "Hearing aids — available free on the NHS or privately with a wider choice of styles",
      "Cochlear implants for severe to profound sensorineural hearing loss",
      "Bone-anchored hearing aids (BAHA) for conductive or mixed hearing loss",
      "Ear wax removal (microsuction, irrigation, or manual removal)",
      "Medical or surgical treatment for underlying conditions such as ear infections or otosclerosis",
      "Assistive listening devices, lip-reading classes, and communication strategies",
    ],
    whenToSeek:
      "See your GP if you notice a gradual or sudden change in your hearing, if hearing difficulty is affecting your daily life, or if you experience hearing loss alongside other symptoms such as dizziness, ear pain, or tinnitus. Sudden hearing loss in one or both ears should be treated as a medical emergency — seek urgent medical attention within 24 hours.",
    icon: "ear",
    relatedConditions: ["age-related-hearing-loss", "noise-induced-hearing-loss", "tinnitus"],
    relatedTests: ["standard-hearing-test", "tympanometry", "bone-conduction-test"],
  },

  // -------------------------------------------------------------------------
  // 2. Tinnitus
  // -------------------------------------------------------------------------
  {
    slug: "tinnitus",
    name: "Tinnitus",
    shortDescription:
      "Tinnitus is the perception of sound — such as ringing, buzzing, or hissing — when there is no external source. It affects around 7.1 million people in the UK.",
    fullDescription: `Tinnitus is the experience of hearing sounds that do not come from an external source. These sounds are often described as ringing, buzzing, hissing, whistling, humming, or whooshing, and they can be heard in one or both ears, or perceived as coming from inside the head. Tinnitus is extremely common in the UK, with the British Tinnitus Association estimating that approximately 7.1 million adults are affected.

Tinnitus is not a disease in itself, but rather a symptom that can be associated with a wide range of underlying conditions. The most common link is with hearing loss — particularly sensorineural hearing loss caused by ageing or noise exposure. When the hair cells in the cochlea are damaged, the brain may compensate by generating its own signals, which are perceived as tinnitus. However, tinnitus can also occur in people with normal hearing and may be triggered by stress, ear infections, ear wax build-up, Meniere's disease, head or neck injuries, or certain medications.

For most people, tinnitus is a mild inconvenience that comes and goes. However, for a significant minority, it can become persistent and distressing, leading to difficulty concentrating, sleep problems, anxiety, and depression. The emotional impact of tinnitus should not be underestimated, and effective support and management strategies are available.

There is currently no single cure for tinnitus, but a range of treatments can help manage the condition effectively. The NHS offers tinnitus assessments through audiology departments, and your GP can refer you for specialist support. Sound therapy — using background sounds to reduce the contrast between the tinnitus and silence — is one of the most widely used approaches. Cognitive behavioural therapy (CBT) adapted for tinnitus has strong evidence for reducing the distress it causes. Hearing aids are often beneficial, particularly when tinnitus is accompanied by hearing loss, as amplifying external sounds can make the tinnitus less noticeable. Tinnitus retraining therapy (TRT) combines sound therapy with counselling to help the brain learn to reclassify the tinnitus signal as unimportant. Self-help strategies such as relaxation techniques, mindfulness, regular exercise, and avoiding excessive caffeine or alcohol can also make a meaningful difference.`,
    symptoms: [
      "Ringing, buzzing, hissing, whistling, or humming sounds in one or both ears",
      "Sounds that may be constant or intermittent",
      "Difficulty concentrating due to persistent internal noise",
      "Sleep disturbance caused by awareness of tinnitus in quiet environments",
      "Increased sensitivity to external sounds (hyperacusis) in some cases",
      "Anxiety, stress, or low mood related to the tinnitus",
      "Pulsatile tinnitus — a rhythmic sound that matches your heartbeat",
    ],
    causes: [
      "Hearing loss (sensorineural), particularly age-related or noise-induced",
      "Exposure to loud noise — concerts, headphones at high volume, occupational noise",
      "Ear wax build-up blocking the ear canal",
      "Ear infections or middle ear conditions such as otitis media",
      "Meniere's disease",
      "Certain medications including high-dose aspirin, some antibiotics, and loop diuretics",
    ],
    treatments: [
      "Sound therapy using white noise generators, nature sounds, or bedside sound machines",
      "Cognitive behavioural therapy (CBT) specifically adapted for tinnitus",
      "Hearing aids — particularly helpful when tinnitus accompanies hearing loss",
      "Tinnitus retraining therapy (TRT) combining counselling with sound enrichment",
      "Relaxation techniques, mindfulness meditation, and stress management",
      "Treatment of underlying causes such as ear wax removal or medication review",
    ],
    whenToSeek:
      "See your GP if tinnitus is persistent, affecting your sleep or concentration, causing you distress, or if it develops suddenly — particularly in one ear only. Pulsatile tinnitus (a rhythmic sound matching your heartbeat) should always be investigated by a doctor, as it may indicate a vascular condition.",
    icon: "volume-x",
    relatedConditions: ["hearing-loss", "menieres-disease", "hyperacusis"],
    relatedTests: ["tinnitus-assessment", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 3. Age-Related Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "age-related-hearing-loss",
    name: "Age-Related Hearing Loss",
    shortDescription:
      "Presbycusis is the gradual loss of hearing that occurs as people get older, typically affecting high-frequency sounds first. It is the most common cause of hearing loss in the UK.",
    fullDescription: `Age-related hearing loss, medically known as presbycusis, is the gradual deterioration of hearing that occurs naturally as part of the ageing process. It is the single most common cause of hearing loss in the United Kingdom, affecting more than 40% of people over 50 and approximately 70% of those over 70. The condition typically develops slowly over many years, which means many people do not immediately realise the extent of their hearing difficulty.

Presbycusis primarily affects the ability to hear high-frequency sounds. This means that consonant sounds such as "s", "f", "th", and "sh" become harder to distinguish, making speech sound muffled or unclear — even when it is loud enough to hear. Background noise compounds the problem significantly, which is why people with age-related hearing loss often find restaurants, family gatherings, and busy workplaces particularly challenging. The condition usually affects both ears equally, though one ear may decline slightly faster than the other.

The underlying cause of presbycusis is the gradual degeneration of the hair cells in the cochlea (inner ear), which convert sound vibrations into electrical signals for the brain. Unlike hair cells in some other animals, human cochlear hair cells do not regenerate once damaged. Additional contributing factors include reduced blood supply to the inner ear, changes in the auditory nerve, and cumulative exposure to noise over a lifetime. Genetic predisposition also plays a significant role — if your parents or grandparents experienced hearing loss, you may be more likely to develop it yourself.

In the UK, age-related hearing loss is managed primarily through hearing aids, which are available free of charge on the NHS. A GP referral leads to an audiology assessment where the degree and pattern of hearing loss are measured using pure tone audiometry. Behind-the-ear (BTE) hearing aids are the standard NHS provision, though private audiologists offer a broader range of styles including receiver-in-canal (RIC) and completely-in-canal (CIC) devices. Beyond hearing aids, communication strategies, assistive listening devices, and lip-reading classes can significantly improve quality of life. Research has consistently shown that addressing hearing loss early helps maintain social engagement and may reduce the risk of cognitive decline and dementia.`,
    symptoms: [
      "Gradual difficulty hearing speech, particularly in noisy environments",
      "Trouble distinguishing consonant sounds such as 's', 'f', 'th', and 'sh'",
      "Frequently asking others to repeat themselves or speak more slowly",
      "Needing to increase the volume on the television or radio",
      "Difficulty hearing on the telephone, especially mobile phones",
      "Finding it harder to follow conversations in groups or at social events",
      "Perceiving that others are mumbling rather than recognising own hearing difficulty",
      "Withdrawal from social situations due to communication difficulties",
    ],
    causes: [
      "Natural degeneration of cochlear hair cells over time",
      "Reduced blood supply to the inner ear with ageing",
      "Cumulative lifetime exposure to noise (occupational and recreational)",
      "Genetic predisposition and family history of hearing loss",
      "Cardiovascular conditions that affect blood flow to the ear",
      "Changes in the auditory nerve and central auditory processing pathways",
    ],
    treatments: [
      "Hearing aids — available free on the NHS (behind-the-ear models) or privately with more style options",
      "Assistive listening devices such as amplified telephones and TV listeners",
      "Lip-reading classes available through local NHS audiology departments or charities",
      "Communication strategies including face-to-face positioning and reducing background noise",
      "Regular hearing reviews to monitor progression and adjust hearing aid settings",
      "Cochlear implants in cases of severe to profound hearing loss where hearing aids are insufficient",
    ],
    whenToSeek:
      "Book a hearing test if you are over 50 and notice any changes in your hearing, or if family and friends comment that you may not be hearing well. The earlier hearing loss is identified and managed, the better the outcomes. There is no need to wait until hearing difficulty becomes severe — modern hearing aids are discreet and highly effective even for mild hearing loss.",
    icon: "clock",
    relatedConditions: ["hearing-loss", "tinnitus", "otosclerosis"],
    relatedTests: ["standard-hearing-test", "bone-conduction-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 4. Noise-Induced Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "noise-induced-hearing-loss",
    name: "Noise-Induced Hearing Loss",
    shortDescription:
      "Permanent hearing damage caused by exposure to loud sounds, whether from a single intense event or prolonged exposure over time. It is entirely preventable.",
    fullDescription: `Noise-induced hearing loss (NIHL) occurs when the delicate sensory hair cells in the inner ear are damaged by exposure to sounds that are too loud, too close, or sustained for too long. Unlike age-related hearing loss, NIHL can affect people of any age and is one of the most common occupational diseases in the United Kingdom. The Health and Safety Executive (HSE) estimates that over one million workers in the UK are exposed to noise levels that put their hearing at risk.

Sound is measured in decibels (dB). Normal conversation is around 60 dB, a busy road is approximately 80 dB, and a nightclub or live concert can reach 100-110 dB. Under UK regulations (the Control of Noise at Work Regulations 2005), employers must take action when noise levels reach 80 dB and provide hearing protection at 85 dB. Prolonged exposure at 85 dB or above can cause permanent hearing damage. At very high levels — such as a gunshot at 140 dB — a single exposure can cause immediate and irreversible damage.

The damage caused by excessive noise is to the stereocilia, the tiny hair-like structures on top of the inner ear's sensory cells. When overstimulated, these structures can become bent, broken, or destroyed. Since human hair cells cannot regenerate, the resulting hearing loss is permanent. NIHL typically affects high-frequency hearing first, creating a characteristic "noise notch" visible on an audiogram at around 4000 Hz. People may initially notice difficulty hearing in background noise before recognising that their hearing has declined.

Industries with particularly high risk include construction, manufacturing, mining, agriculture, the military, and the entertainment industry. However, recreational noise exposure is an increasingly significant concern — personal music players at high volume, live music, motorsports, and shooting are all common causes. The World Health Organization has warned that over one billion young people worldwide are at risk of hearing loss from unsafe listening practices.

Prevention is the most effective approach to NIHL, as the damage is irreversible. Employers in the UK are legally required to assess noise risks, provide hearing protection, and offer regular hearing surveillance. Individuals should use well-fitted ear plugs or ear defenders in noisy environments, follow the 60/60 rule for headphone use (no more than 60% volume for no more than 60 minutes), and take regular breaks from noise exposure. If noise-induced hearing loss has already occurred, hearing aids can help manage the condition, and tinnitus management may also be needed, as the two conditions frequently co-occur.`,
    symptoms: [
      "Gradual difficulty hearing high-pitched sounds",
      "Speech sounds muffled or distorted, especially in noisy settings",
      "Tinnitus (ringing, buzzing, or hissing) — often the first warning sign",
      "A temporary shift in hearing after loud noise exposure (temporary threshold shift)",
      "Needing to raise your voice to be heard by someone at arm's length",
      "Difficulty understanding speech on the telephone",
      "Sounds seeming duller or less clear than they used to",
    ],
    causes: [
      "Prolonged occupational noise exposure (construction, manufacturing, military)",
      "Listening to music at high volume through headphones or earbuds",
      "Attending loud concerts, nightclubs, or festivals without ear protection",
      "Use of power tools, lawnmowers, or other loud equipment without protection",
      "Shooting or hunting without adequate hearing protection",
      "A single exposure to an extremely loud sound such as an explosion (acoustic trauma)",
    ],
    treatments: [
      "Hearing aids to amplify sounds and improve speech clarity",
      "Tinnitus management including sound therapy and CBT where tinnitus co-occurs",
      "Custom-moulded ear plugs for ongoing noise exposure (musicians' plugs, industrial plugs)",
      "Workplace hearing conservation programmes and regular audiometric monitoring",
      "Communication strategies and assistive listening devices",
      "Research into hair cell regeneration is ongoing but not yet clinically available",
    ],
    whenToSeek:
      "See your GP or an audiologist if you notice any change in your hearing after noise exposure, if you experience persistent tinnitus, or if you work in a noisy environment and have not had a recent hearing test. Temporary hearing loss after noise exposure is a warning sign that permanent damage may follow. Under UK law, your employer should provide hearing surveillance if you are exposed to noise above 85 dB.",
    icon: "volume-2",
    relatedConditions: ["hearing-loss", "tinnitus", "hyperacusis"],
    relatedTests: ["standard-hearing-test", "otoacoustic-emissions", "bone-conduction-test"],
  },

  // -------------------------------------------------------------------------
  // 5. Ear Infections
  // -------------------------------------------------------------------------
  {
    slug: "ear-infections",
    name: "Ear Infections",
    shortDescription:
      "Infections of the outer ear (otitis externa) or middle ear (otitis media) are common, particularly in children. They can cause temporary hearing loss, pain, and discharge.",
    fullDescription: `Ear infections are among the most common reasons for GP visits in the United Kingdom, particularly in children under five. They are broadly classified by location: otitis media (middle ear infection) and otitis externa (outer ear infection, sometimes called "swimmer's ear"). Both types can cause pain, temporary hearing loss, and general discomfort, but they have different causes, presentations, and treatments.

Otitis media occurs when the space behind the eardrum becomes infected, usually by bacteria or viruses. It is extremely common in young children because their Eustachian tubes — the narrow passages connecting the middle ear to the back of the throat — are shorter and more horizontal than in adults, making them more susceptible to blockage and infection. Symptoms include earache, fever, irritability in young children, temporary hearing loss, and sometimes a discharge if the eardrum perforates. Most cases of acute otitis media resolve on their own within a few days. NHS guidelines recommend a "watch and wait" approach for the first 48-72 hours, using paracetamol or ibuprofen for pain relief, before considering antibiotics. Recurrent middle ear infections or persistent fluid (glue ear) may require referral to an ENT specialist.

Otitis externa is an infection or inflammation of the ear canal — the passage between the outer ear and the eardrum. It is commonly caused by water remaining in the ear canal after swimming (hence "swimmer's ear"), creating a moist environment in which bacteria or fungi can thrive. Other causes include damage to the ear canal from cotton buds, hearing aids, or ear plugs, as well as skin conditions such as eczema or psoriasis. Symptoms include ear pain (often severe, especially when the ear is touched or pulled), itching, discharge, and temporary hearing loss due to swelling or debris in the canal. Treatment typically involves antibiotic or antifungal ear drops, keeping the ear dry, and pain relief.

Prevention measures include keeping ears dry (using a towel or hair dryer on a low setting after swimming), avoiding inserting cotton buds or other objects into the ear canal, and treating underlying skin conditions promptly. Children who experience frequent ear infections may benefit from referral to an ENT surgeon, who may recommend grommets (ventilation tubes) to prevent fluid build-up in the middle ear.`,
    symptoms: [
      "Ear pain (otalgia) — may be sharp, throbbing, or a dull ache",
      "Temporary hearing loss or muffled hearing in the affected ear",
      "Discharge from the ear (clear, yellow, or greenish fluid)",
      "Fever, particularly with middle ear infections in children",
      "Itching in or around the ear canal (more common with otitis externa)",
      "A feeling of fullness or pressure in the ear",
      "Irritability, poor feeding, or tugging at the ear in young children",
      "Swelling or redness of the ear canal or outer ear",
    ],
    causes: [
      "Bacterial or viral infection of the middle ear, often following a cold or upper respiratory infection",
      "Water trapped in the ear canal after swimming or bathing",
      "Damage to the ear canal from cotton buds, hearing aids, or ear plugs",
      "Eustachian tube dysfunction — common in young children due to tube anatomy",
      "Skin conditions affecting the ear canal such as eczema, psoriasis, or dermatitis",
      "Allergies causing inflammation and mucus build-up in the Eustachian tubes",
    ],
    treatments: [
      "Pain relief with paracetamol or ibuprofen (appropriate doses for age)",
      "Antibiotic ear drops for otitis externa, or oral antibiotics for severe otitis media",
      "Antifungal ear drops if fungal infection is identified",
      "Keeping the ear dry and avoiding swimming until the infection clears",
      "Microsuction or ear toilet to remove debris from the ear canal if needed",
      "Grommets (ventilation tubes) for children with recurrent otitis media or persistent glue ear",
    ],
    whenToSeek:
      "See your GP if ear pain is severe or lasts more than 48 hours, if there is discharge from the ear, if a child under two has symptoms of an ear infection, or if you experience hearing loss, dizziness, or swelling around the ear. Seek urgent medical attention if there is severe pain with fever, facial weakness, or if symptoms worsen despite treatment.",
    icon: "thermometer",
    relatedConditions: ["glue-ear", "perforated-eardrum", "hearing-loss"],
    relatedTests: ["tympanometry", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 6. Meniere's Disease
  // -------------------------------------------------------------------------
  {
    slug: "menieres-disease",
    name: "Meniere's Disease",
    shortDescription:
      "A chronic inner ear condition causing episodes of vertigo, hearing loss, tinnitus, and a feeling of fullness in the ear. It most commonly affects people aged 20-60.",
    fullDescription: `Meniere's disease is a chronic condition of the inner ear that causes recurring episodes of vertigo (a spinning sensation), fluctuating hearing loss, tinnitus, and a feeling of fullness or pressure in the affected ear. It is named after the French physician Prosper Meniere, who first described the condition in 1861. The Meniere's Society estimates that around 1 in 1,000 people in the UK are affected.

The exact cause of Meniere's disease is not fully understood, but it is associated with an abnormal build-up of fluid (endolymph) in the labyrinth of the inner ear, a condition known as endolymphatic hydrops. This excess fluid disrupts the normal balance and hearing signals sent from the inner ear to the brain. What triggers this fluid imbalance is unclear, though it may involve a combination of genetic predisposition, immune system dysfunction, viral infections, abnormal fluid drainage, and possibly migraines. The condition most commonly develops between the ages of 20 and 60 and usually affects one ear initially, though it can eventually involve both ears in some cases.

Episodes of Meniere's disease are unpredictable and can vary greatly in severity and frequency. A typical attack begins with a feeling of fullness in the ear, followed by increasing tinnitus and reduced hearing, culminating in a bout of vertigo that can last from 20 minutes to several hours. During an episode, nausea and vomiting are common due to the intensity of the vertigo. Between attacks, hearing may return to near-normal levels in the early stages, but over time, many people experience progressive hearing loss as the condition advances.

In the UK, diagnosis is typically made by an ENT consultant based on clinical history and a series of tests including pure tone audiometry, tympanometry, and balance assessments. MRI scanning may be performed to rule out other conditions such as acoustic neuroma. Treatment focuses on managing symptoms and reducing the frequency of attacks. Dietary modifications — particularly reducing salt, caffeine, and alcohol intake — can help reduce fluid retention in the inner ear. Betahistine is the most commonly prescribed medication in the UK and works by improving blood flow to the inner ear. During acute attacks, prochlorperazine or other anti-sickness medications can help manage vertigo and nausea. Vestibular rehabilitation therapy can improve balance between episodes. In severe cases that do not respond to conservative treatment, surgical options including endolymphatic sac decompression, gentamicin injections, or labyrinthectomy may be considered.`,
    symptoms: [
      "Episodes of rotational vertigo lasting 20 minutes to several hours",
      "Fluctuating hearing loss, typically affecting low frequencies initially",
      "Tinnitus — often described as a low roaring or buzzing sound",
      "A sensation of fullness or pressure in the affected ear (aural fullness)",
      "Nausea and vomiting during vertigo episodes",
      "Imbalance and unsteadiness, which may persist between attacks",
      "Drop attacks (Tumarkin crises) — sudden falls without loss of consciousness in advanced cases",
    ],
    causes: [
      "Abnormal build-up of endolymph (fluid) in the inner ear (endolymphatic hydrops)",
      "Genetic predisposition — the condition can run in families",
      "Immune system dysfunction or autoimmune factors",
      "Viral infections that may trigger or contribute to the condition",
      "Abnormal drainage of inner ear fluid",
      "Possible association with migraine",
    ],
    treatments: [
      "Dietary changes — reducing salt, caffeine, and alcohol to minimise fluid retention",
      "Betahistine — the most commonly prescribed medication for Meniere's disease in the UK",
      "Anti-emetics such as prochlorperazine for managing acute vertigo and nausea",
      "Vestibular rehabilitation therapy to improve balance and reduce dizziness",
      "Hearing aids to manage fluctuating or progressive hearing loss",
      "Surgical interventions in severe cases (endolymphatic sac surgery, gentamicin injections, labyrinthectomy)",
    ],
    whenToSeek:
      "See your GP if you experience episodes of vertigo lasting more than 20 minutes, fluctuating hearing loss, persistent tinnitus, or a recurring feeling of fullness in your ear. Your GP can refer you to an ENT specialist for further investigation. Seek urgent medical attention if you experience sudden hearing loss, severe vertigo with vomiting, or if symptoms significantly affect your ability to carry out daily activities.",
    icon: "rotate-ccw",
    relatedConditions: ["tinnitus", "hearing-loss", "hyperacusis"],
    relatedTests: ["balance-assessment", "standard-hearing-test", "tympanometry"],
  },

  // -------------------------------------------------------------------------
  // 7. Otosclerosis
  // -------------------------------------------------------------------------
  {
    slug: "otosclerosis",
    name: "Otosclerosis",
    shortDescription:
      "A condition where abnormal bone growth in the middle ear prevents the stapes bone from vibrating normally, causing progressive conductive hearing loss.",
    fullDescription: `Otosclerosis is a condition in which abnormal bone remodelling occurs in the middle ear, most commonly affecting the stapes (stirrup) — the smallest bone in the human body. The stapes normally vibrates freely in response to sound waves, transmitting them from the eardrum through the oval window into the inner ear. In otosclerosis, new spongy bone growth gradually fixes the stapes in place, preventing it from vibrating properly and causing progressive conductive hearing loss. The condition affects approximately 1-2% of the UK population and is one of the most common causes of hearing loss in young and middle-aged adults.

Otosclerosis typically develops between the ages of 15 and 45, with symptoms usually beginning in the twenties or thirties. It is twice as common in women as in men, and pregnancy can accelerate the progression of the disease — possibly due to hormonal changes. There is a strong genetic component, with approximately half of those affected having a family history of the condition. It is most common in white Europeans and is rare in people of African and Asian descent.

The hallmark symptom of otosclerosis is a gradual hearing loss that usually begins in one ear before affecting both. Characteristically, people with otosclerosis may find they can hear better in noisy environments than in quiet ones — a phenomenon known as paracusis of Willis. This occurs because people tend to raise their voices in noisy settings, making it easier for someone with conductive hearing loss to hear. Tinnitus is also common, and some people experience mild balance problems or dizziness.

Diagnosis is made by an audiologist or ENT specialist using pure tone audiometry, which typically shows a conductive hearing loss pattern, and tympanometry, which may appear normal. A Carhart notch — a dip in bone conduction at 2000 Hz on the audiogram — is a classic finding suggestive of otosclerosis. CT scanning of the temporal bone may be performed to confirm the diagnosis and assess the extent of bony changes.

Treatment options depend on the severity of hearing loss and patient preference. Hearing aids are an effective non-surgical option and are suitable for many people. Stapedectomy or stapedotomy — surgical procedures in which the fixed stapes is replaced with a prosthetic piston — is the definitive treatment and is highly successful, with hearing improvement achieved in over 90% of cases. The operation is typically performed under local anaesthetic as a day case. Sodium fluoride supplements have been used in some cases to slow the progression of otosclerosis, though evidence for their effectiveness is limited.`,
    symptoms: [
      "Gradual hearing loss, usually starting in one ear and progressing to both",
      "Hearing better in noisy environments than in quiet ones (paracusis of Willis)",
      "Tinnitus — often a low-pitched buzzing or humming",
      "Speaking more quietly than usual (as your own voice sounds louder through bone conduction)",
      "Difficulty hearing low-pitched sounds and whispered speech",
      "Mild dizziness or balance disturbance in some cases",
    ],
    causes: [
      "Abnormal bone remodelling around the stapes footplate in the middle ear",
      "Genetic factors — approximately 50% of cases have a family history",
      "Hormonal influences — pregnancy and oestrogen may accelerate progression",
      "Possible viral triggers, including measles virus",
      "Ethnic predisposition — most common in white European populations",
    ],
    treatments: [
      "Hearing aids — effective for managing mild to moderate conductive hearing loss",
      "Stapedectomy or stapedotomy — surgical replacement of the fixed stapes with a prosthesis",
      "Sodium fluoride supplements — may slow disease progression in some cases",
      "Regular audiometric monitoring to track hearing changes over time",
      "Vestibular rehabilitation if balance symptoms are present",
    ],
    whenToSeek:
      "See your GP if you notice a gradual hearing loss, particularly if it begins in your twenties or thirties, if you have a family history of otosclerosis, or if hearing loss is accompanied by tinnitus. Your GP can refer you to an ENT specialist or audiologist for further assessment, including audiometry and tympanometry.",
    icon: "bone",
    relatedConditions: ["hearing-loss", "tinnitus", "age-related-hearing-loss"],
    relatedTests: ["standard-hearing-test", "tympanometry", "bone-conduction-test"],
  },

  // -------------------------------------------------------------------------
  // 8. Glue Ear
  // -------------------------------------------------------------------------
  {
    slug: "glue-ear",
    name: "Glue Ear",
    shortDescription:
      "Glue ear (otitis media with effusion) is a build-up of sticky fluid in the middle ear, common in young children. It is the most frequent cause of hearing loss in childhood.",
    fullDescription: `Glue ear, known medically as otitis media with effusion (OME), is a condition in which thick, sticky fluid accumulates in the middle ear space behind the eardrum. It is the most common cause of hearing loss in children in the United Kingdom, affecting around 80% of children at some point before the age of ten, with peak incidence between ages two and five. While it can also affect adults, it is primarily a childhood condition.

The middle ear is an air-filled space that relies on the Eustachian tube to ventilate and drain. In children, the Eustachian tube is shorter, more horizontal, and more easily blocked than in adults. When the tube becomes dysfunctional — due to colds, allergies, enlarged adenoids, or passive smoke exposure — air cannot enter the middle ear, creating negative pressure that draws fluid from the surrounding tissues. This fluid can become thick and glue-like, hence the common name. The fluid dampens the movement of the eardrum and ossicles (the tiny bones of the middle ear), reducing the transmission of sound and causing conductive hearing loss.

The hearing loss associated with glue ear is usually mild to moderate (typically 20-40 dB) but can have a significant impact on a child's development. Children with glue ear may struggle to hear their teacher in a busy classroom, have difficulty learning to speak clearly, become frustrated or withdrawn, and may be mistakenly labelled as inattentive or poorly behaved. Recognising glue ear early is therefore important to support a child's learning and social development.

Glue ear is diagnosed using otoscopy (examining the eardrum, which may appear dull, retracted, or amber-coloured) and tympanometry, which measures the movement of the eardrum and typically shows a flat (Type B) trace. A hearing test will confirm the degree of hearing loss.

In the UK, the NHS follows a watchful waiting approach, as glue ear resolves spontaneously in most children within three months. If the condition persists for more than three months and is causing significant hearing difficulty, the child may be referred to an ENT specialist. The most common surgical treatment is the insertion of grommets (ventilation tubes) — tiny tubes placed in the eardrum under general anaesthetic to allow air into the middle ear and fluid to drain. The procedure typically takes around 15 minutes and is one of the most commonly performed childhood operations in the UK. Grommets usually fall out on their own after 6-12 months. In some cases, adenoidectomy (removal of the adenoids) may be performed at the same time if enlarged adenoids are contributing to Eustachian tube dysfunction.`,
    symptoms: [
      "Difficulty hearing or responding to sounds — often noticed by parents or teachers",
      "Delayed speech and language development in young children",
      "Inattentiveness or poor concentration at school",
      "Asking for things to be repeated or turning up the volume on devices",
      "Ear discomfort or a feeling of fullness in the ear (older children may report this)",
      "Balance difficulties in some cases",
      "Behavioural changes — frustration, withdrawal, or being incorrectly labelled as naughty",
    ],
    causes: [
      "Eustachian tube dysfunction — very common in young children due to tube immaturity",
      "Upper respiratory tract infections (colds) leading to Eustachian tube swelling",
      "Enlarged adenoids blocking the Eustachian tube opening",
      "Allergies causing nasal and Eustachian tube congestion",
      "Passive exposure to cigarette smoke",
      "Bottle feeding while lying flat (in infants) — associated with increased risk",
    ],
    treatments: [
      "Watchful waiting — most cases resolve within three months without treatment",
      "Autoinflation — using a special balloon blown through the nose (Otovent) to open the Eustachian tube",
      "Grommets (ventilation tubes) inserted under general anaesthetic for persistent cases",
      "Adenoidectomy if enlarged adenoids are contributing to Eustachian tube blockage",
      "Hearing aids as a non-surgical alternative while waiting for resolution",
      "Preferential classroom seating and additional educational support while hearing is affected",
    ],
    whenToSeek:
      "See your GP if you suspect your child is not hearing well, if their speech development seems delayed, or if a teacher reports that your child is inattentive or struggling to hear in class. Adults who experience persistent muffled hearing or a sensation of fullness in the ear should also seek assessment. Your GP can examine the ears and refer for tympanometry and a hearing test if glue ear is suspected.",
    icon: "droplets",
    relatedConditions: ["ear-infections", "hearing-loss", "perforated-eardrum"],
    relatedTests: ["tympanometry", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 9. Auditory Processing Disorder
  // -------------------------------------------------------------------------
  {
    slug: "auditory-processing-disorder",
    name: "Auditory Processing Disorder",
    shortDescription:
      "APD is a condition where the brain has difficulty processing and interpreting sounds, even though hearing itself may be normal. It affects an estimated 2-7% of children.",
    fullDescription: `Auditory processing disorder (APD), sometimes called central auditory processing disorder (CAPD), is a condition in which the brain has difficulty processing and making sense of the sounds it receives from the ears. Unlike hearing loss, where the ears themselves may not detect sounds properly, in APD the ears typically work normally — the problem lies in how the brain interprets the auditory information. APD is estimated to affect 2-7% of children, though it can also be diagnosed in adults and may persist from childhood or develop following brain injury, infection, or neurological conditions.

People with APD often have normal results on standard hearing tests (pure tone audiometry) because they can detect sounds at normal volume levels. However, they struggle in real-world listening situations, particularly when there is background noise, when speech is rapid, or when instructions are complex. This can lead to significant difficulties in school, at work, and in social situations. APD shares some features with other conditions such as ADHD, dyslexia, and autism spectrum disorder, which can make diagnosis challenging — and these conditions may co-exist with APD.

In children, APD often presents as difficulty following spoken instructions (especially multi-step ones), problems with reading and spelling, poor concentration in noisy classrooms, frequently asking "what?" or "huh?", and difficulty distinguishing between similar-sounding words. Adults with APD may struggle to follow conversations in noisy environments, have difficulty with phone calls, find it hard to enjoy music, and may need more time to process spoken information.

Diagnosis of APD in the UK is carried out by a specialist audiologist, typically in an NHS audiology department or a specialist centre. A battery of specialised listening tests is used to assess different aspects of auditory processing, including the ability to understand speech in noise, process rapid speech, detect gaps in sound, and integrate information from both ears (dichotic listening). These tests are generally only reliable from around age seven, as auditory processing pathways are still maturing in younger children.

Management of APD involves a combination of environmental modifications, compensatory strategies, and direct auditory training. In schools, a radio aid or FM system can transmit the teacher's voice directly to the child's ears, improving the signal-to-noise ratio. Classroom accommodations such as preferential seating, written instructions alongside verbal ones, and a quieter learning environment can make a significant difference. Speech and language therapy may help develop listening skills, and computer-based auditory training programmes can improve the brain's ability to process sounds. In the UK, the NHS provides APD assessment and management through specialist audiology services, though waiting times can be lengthy, and some families choose to access private assessment.`,
    symptoms: [
      "Difficulty understanding speech in noisy environments despite normal hearing",
      "Frequently asking for repetition or saying 'what?' or 'huh?'",
      "Difficulty following multi-step or complex verbal instructions",
      "Problems with reading, spelling, and phonics (in children)",
      "Poor concentration and listening in group settings or noisy classrooms",
      "Difficulty distinguishing between similar-sounding words",
      "Delayed response to spoken questions or instructions",
      "Struggling to follow conversations on the telephone",
    ],
    causes: [
      "Developmental differences in the auditory processing pathways of the brain",
      "Recurrent ear infections (otitis media) in early childhood affecting auditory development",
      "Head injury or trauma affecting the brain's auditory centres",
      "Neurological conditions or brain infections such as meningitis",
      "Genetic factors — APD can run in families",
      "Ageing — some age-related auditory processing decline can resemble APD",
    ],
    treatments: [
      "FM systems or radio aids to improve the signal-to-noise ratio in classrooms and workplaces",
      "Environmental modifications — preferential seating, reduced background noise, visual aids",
      "Computer-based auditory training programmes to improve sound processing skills",
      "Speech and language therapy to develop listening and comprehension strategies",
      "Classroom and workplace accommodations including written instructions alongside verbal ones",
      "Cognitive behavioural strategies to manage frustration and build confidence",
    ],
    whenToSeek:
      "See your GP if you or your child has persistent difficulty understanding speech despite normal hearing, particularly if it affects learning, work, or social interactions. Your GP can refer you to a specialist audiology service for APD assessment. In children, it is important to first rule out hearing loss and other conditions such as ADHD or language disorders. Specialist APD testing is generally reliable from around age seven.",
    icon: "brain",
    relatedConditions: ["hearing-loss", "glue-ear", "ear-infections"],
    relatedTests: ["standard-hearing-test", "auditory-brainstem-response", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 10. Sudden Sensorineural Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "sudden-hearing-loss",
    name: "Sudden Sensorineural Hearing Loss",
    shortDescription:
      "SSHL is a rapid loss of hearing, usually in one ear, that develops within 72 hours. It is a medical emergency requiring urgent treatment for the best chance of recovery.",
    fullDescription: `Sudden sensorineural hearing loss (SSHL) is defined as a rapid loss of hearing of at least 30 decibels across three or more consecutive frequencies, occurring within 72 hours. It most commonly affects one ear and can range from mild hearing difficulty to complete deafness in the affected ear. SSHL is a medical emergency, and prompt treatment significantly improves the chances of hearing recovery. In the UK, it is estimated to affect approximately 5-20 people per 100,000 each year, though the true incidence may be higher as some cases go unreported.

The onset of SSHL is often sudden and dramatic — many people notice it upon waking in the morning or hear a loud "pop" before their hearing disappears. Approximately 90% of cases are unilateral (affecting one ear), and tinnitus accompanies the hearing loss in around 70% of cases. Vertigo or dizziness is present in about 30-40% of cases and may indicate more extensive inner ear involvement.

The cause of SSHL can be identified in only about 10-15% of cases. Known causes include viral infections (such as mumps, measles, or herpes simplex), autoimmune inner ear disease, vascular events affecting the blood supply to the cochlea, Meniere's disease, acoustic neuroma, head trauma, and ototoxic medications. In the majority of cases, however, the cause remains unknown (idiopathic SSHL), and a viral or vascular mechanism is suspected.

Early treatment is critical. UK and international guidelines recommend that oral corticosteroids (typically prednisolone) should be started as soon as possible, ideally within 72 hours of onset. The most commonly used regimen is a course of high-dose oral steroids tapered over two to three weeks. If oral steroids are ineffective or contraindicated, intratympanic steroid injections (steroids injected directly through the eardrum into the middle ear) may be offered as an alternative or salvage therapy. Hyperbaric oxygen therapy is used in some centres as an adjunctive treatment.

In the UK, the recommended pathway is to seek urgent medical attention — either through your GP (requesting an emergency appointment), NHS 111, or A&E if necessary. Referral to an ENT specialist or emergency audiology service should be made within 24 hours. An urgent audiogram is essential to confirm the diagnosis and determine the severity. MRI of the internal auditory canals is usually recommended to rule out acoustic neuroma or other structural causes.

Recovery rates vary depending on the severity of hearing loss, how quickly treatment is started, the patient's age, and whether vertigo is present. Overall, approximately one-third of patients recover fully, one-third recover partially, and one-third have little or no improvement. Younger patients and those treated early generally have the best outcomes. For those with permanent hearing loss following SSHL, hearing aids or, in cases of profound unilateral loss, CROS hearing aids or bone-anchored hearing aids may be recommended.`,
    symptoms: [
      "Rapid hearing loss in one ear, often noticed upon waking",
      "A loud 'pop' or sudden change in hearing",
      "Tinnitus in the affected ear — ringing, roaring, or buzzing",
      "A feeling of fullness or blockage in the affected ear",
      "Dizziness or vertigo, present in around one-third of cases",
      "Difficulty understanding speech on the side of the affected ear",
    ],
    causes: [
      "Idiopathic (unknown cause) in 85-90% of cases — viral or vascular mechanism suspected",
      "Viral infections such as mumps, measles, herpes simplex, or influenza",
      "Autoimmune inner ear disease",
      "Vascular events disrupting blood supply to the cochlea",
      "Acoustic neuroma (vestibular schwannoma)",
      "Ototoxic medications, head trauma, or Meniere's disease",
    ],
    treatments: [
      "Urgent oral corticosteroids (prednisolone) — ideally started within 72 hours",
      "Intratympanic steroid injections as salvage therapy if oral steroids are ineffective",
      "Hyperbaric oxygen therapy — available at some specialist centres",
      "MRI scan to rule out acoustic neuroma or structural causes",
      "Hearing aids or CROS hearing aids for permanent unilateral hearing loss",
      "Bone-anchored hearing aids (BAHA) for profound single-sided deafness",
    ],
    whenToSeek:
      "Sudden hearing loss is a medical emergency. If you experience a rapid loss of hearing in one or both ears, seek urgent medical attention the same day. Contact your GP for an emergency appointment, call NHS 111, or attend A&E. Do not wait to see if it resolves on its own — early treatment with steroids within 72 hours gives the best chance of recovery.",
    icon: "alert-triangle",
    relatedConditions: ["hearing-loss", "acoustic-neuroma", "menieres-disease"],
    relatedTests: ["standard-hearing-test", "auditory-brainstem-response", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 11. Acoustic Neuroma
  // -------------------------------------------------------------------------
  {
    slug: "acoustic-neuroma",
    name: "Acoustic Neuroma",
    shortDescription:
      "A benign (non-cancerous) tumour growing on the vestibulocochlear nerve. It is slow-growing and can cause gradual hearing loss, tinnitus, and balance problems.",
    fullDescription: `An acoustic neuroma, more accurately called a vestibular schwannoma, is a benign (non-cancerous) tumour that develops on the vestibulocochlear nerve — the nerve that connects the inner ear to the brain and is responsible for hearing and balance. These tumours grow from the Schwann cells that form the insulating sheath around the nerve. Acoustic neuromas are rare, with approximately 1,200 new cases diagnosed in the UK each year, accounting for about 6-8% of all primary brain tumours.

Acoustic neuromas are slow-growing tumours, typically enlarging by 1-2 millimetres per year, though growth rates vary. As the tumour grows, it presses on the hearing and balance portions of the vestibulocochlear nerve, causing gradual hearing loss and balance disturbance. If it becomes large enough, it can press on adjacent cranial nerves (particularly the facial nerve and trigeminal nerve) and, rarely, on the brainstem itself.

The most common presenting symptom is asymmetric sensorineural hearing loss — hearing loss that is worse in one ear than the other. This develops gradually over months or years and is often accompanied by tinnitus in the affected ear. Balance problems such as unsteadiness (rather than true vertigo) are common. Larger tumours may cause facial numbness or, in rare cases, facial weakness. Sudden hearing loss can occasionally be the first presentation.

Diagnosis is made by MRI scan with gadolinium contrast, which is the gold standard investigation for acoustic neuroma. In the UK, any patient presenting with asymmetric sensorineural hearing loss or unilateral tinnitus should be considered for MRI according to NICE guidelines. An audiogram will typically show unilateral or asymmetric sensorineural hearing loss, often with poor speech discrimination scores.

Management depends on the size and growth rate of the tumour, the patient's symptoms, age, general health, and hearing in both ears. There are three main approaches. Conservative management (watch and wait) involves regular MRI scans to monitor the tumour's growth, typically every 6-12 months. This is often recommended for small, slow-growing tumours, particularly in older patients, as many acoustic neuromas remain stable for years. Stereotactic radiosurgery (Gamma Knife) delivers a precisely focused dose of radiation to the tumour to halt or slow its growth. It is typically used for small to medium tumours (up to 2.5-3 cm) and has a tumour control rate of approximately 95%. Microsurgery involves removing the tumour through an operation, which may be recommended for larger tumours or those causing significant symptoms. In the UK, acoustic neuroma surgery is performed at specialist neurosurgical centres and usually involves a team of neurosurgeons and ENT surgeons.`,
    symptoms: [
      "Gradual hearing loss in one ear (unilateral sensorineural hearing loss)",
      "Tinnitus in the affected ear — often high-pitched",
      "Unsteadiness or balance problems, particularly in the dark or on uneven surfaces",
      "A feeling of fullness in the affected ear",
      "Facial numbness or tingling on the side of the tumour (larger tumours)",
      "Headaches — uncommon and usually associated with larger tumours",
    ],
    causes: [
      "Sporadic (random) mutation in the Schwann cells of the vestibulocochlear nerve — most cases",
      "Neurofibromatosis type 2 (NF2) — a genetic condition causing bilateral acoustic neuromas",
      "Possible association with prolonged loud noise exposure, though evidence is inconclusive",
      "No established environmental or lifestyle risk factors in the majority of cases",
    ],
    treatments: [
      "Conservative management (watch and wait) with regular MRI monitoring for small, stable tumours",
      "Stereotactic radiosurgery (Gamma Knife) for small to medium tumours — high tumour control rate",
      "Microsurgery to remove the tumour — recommended for larger or rapidly growing tumours",
      "Hearing aids for residual hearing loss following treatment",
      "CROS hearing aids or bone-anchored hearing aids for single-sided deafness",
      "Vestibular rehabilitation for post-treatment balance difficulties",
    ],
    whenToSeek:
      "See your GP if you experience gradual hearing loss or tinnitus that is worse in one ear, or if you have unexplained unsteadiness or balance problems. Asymmetric hearing loss should always be investigated with an MRI scan to rule out acoustic neuroma. Your GP can refer you urgently if acoustic neuroma is suspected.",
    icon: "activity",
    relatedConditions: ["hearing-loss", "tinnitus", "sudden-hearing-loss"],
    relatedTests: ["auditory-brainstem-response", "standard-hearing-test", "balance-assessment"],
  },

  // -------------------------------------------------------------------------
  // 12. Hyperacusis
  // -------------------------------------------------------------------------
  {
    slug: "hyperacusis",
    name: "Hyperacusis",
    shortDescription:
      "Hyperacusis is an increased sensitivity to everyday sounds that most people can tolerate comfortably. It can cause physical discomfort or pain and significantly affect quality of life.",
    fullDescription: `Hyperacusis is a condition in which everyday sounds that most people can tolerate comfortably are perceived as uncomfortably loud, overwhelming, or even painful. It is distinct from simply having sensitive hearing — people with hyperacusis may find sounds like running water, cutlery clinking, paper rustling, or normal conversation levels genuinely distressing. The condition is thought to affect approximately 2% of the adult population in the UK, though varying degrees of sound sensitivity are much more common.

Hyperacusis can be broadly categorised into different types. Loudness hyperacusis means ordinary sounds are perceived as louder than they should be. Pain hyperacusis (sometimes called noxacusis) involves physical pain in response to sounds that would not normally cause discomfort. Fear hyperacusis (phonophobia) is an anxiety response where the anticipation of sound becomes distressing. These types can overlap, and many people experience a combination.

The condition is closely linked to tinnitus, with around 40% of people with tinnitus also reporting some degree of hyperacusis, and vice versa. It can occur alongside hearing loss but also affects people with normal hearing thresholds on standard audiometry. Hyperacusis can develop following exposure to a single loud noise event, after a period of illness, as a result of certain neurological conditions (such as migraine, head injury, or Lyme disease), or in association with conditions like autism spectrum disorder and Williams syndrome.

The mechanisms behind hyperacusis are not fully understood, but current research suggests that it may involve changes in how the brain's auditory system processes and responds to sound. When the ears or auditory pathways are damaged or disrupted, the brain may turn up its "gain" or sensitivity to compensate, resulting in an amplified response to normal-level sounds. This central gain theory explains why hyperacusis can occur even when the ears themselves are structurally normal.

Management of hyperacusis in the UK typically involves a combination of sound therapy, counselling, and gradual desensitisation. The key principle is to avoid silence and overprotection of the ears — while it is tempting to wear ear plugs constantly, this can actually make hyperacusis worse by causing the brain to further increase its sensitivity. Instead, a programme of controlled sound enrichment using broadband noise generators (worn like hearing aids) or environmental sounds is used to gradually retrain the brain's response. Cognitive behavioural therapy (CBT) can help address the anxiety and avoidance behaviours that often accompany hyperacusis. Tinnitus retraining therapy (TRT) incorporates both sound therapy and counselling and is used for people with co-existing tinnitus and hyperacusis. NHS audiology departments offer hyperacusis management, though specialist services may have longer waiting times.`,
    symptoms: [
      "Everyday sounds perceived as uncomfortably loud or overwhelming",
      "Physical discomfort or ear pain in response to normal-level sounds",
      "Anxiety or distress when anticipating exposure to sound",
      "Avoidance of social situations, public places, or noisy environments",
      "Difficulty tolerating sounds such as cutlery, running water, traffic, or conversation",
      "Co-existing tinnitus in many cases",
      "Fatigue and emotional exhaustion from constant sound sensitivity",
      "Impact on work, relationships, and overall quality of life",
    ],
    causes: [
      "Exposure to a sudden loud noise event (acoustic trauma)",
      "Tinnitus — the two conditions frequently co-occur",
      "Head injury or whiplash",
      "Neurological conditions including migraine and Lyme disease",
      "Autism spectrum disorder or Williams syndrome",
      "Prolonged use of ear plugs or avoidance of sound (which can increase sensitivity)",
    ],
    treatments: [
      "Sound therapy using broadband noise generators to gradually desensitise the auditory system",
      "Cognitive behavioural therapy (CBT) to manage anxiety and avoidance behaviours",
      "Tinnitus retraining therapy (TRT) for co-existing tinnitus and hyperacusis",
      "Environmental sound enrichment — avoiding silence without overloading with sound",
      "Gradual controlled exposure to everyday sounds to rebuild tolerance",
      "Counselling and education about the condition and its management",
    ],
    whenToSeek:
      "See your GP if you find that everyday sounds cause you discomfort, pain, or distress, or if sound sensitivity is affecting your ability to work, socialise, or carry out daily activities. Your GP can refer you to an audiology department for assessment and management. Avoid over-protecting your ears with ear plugs in everyday situations, as this can worsen the condition.",
    icon: "zap",
    relatedConditions: ["tinnitus", "hearing-loss", "noise-induced-hearing-loss"],
    relatedTests: ["tinnitus-assessment", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 13. Ear Wax Build-Up
  // -------------------------------------------------------------------------
  {
    slug: "ear-wax-buildup",
    name: "Ear Wax Build-Up",
    shortDescription:
      "Cerumen impaction occurs when ear wax accumulates and blocks the ear canal, causing hearing loss, discomfort, and tinnitus. It is one of the most common ear problems seen by GPs.",
    fullDescription: `Ear wax (cerumen) is a natural substance produced by glands in the ear canal. It plays an important protective role — trapping dust, debris, and microorganisms, moisturising the skin of the ear canal, and helping to prevent infections. In most people, ear wax naturally migrates outwards and falls out of the ear without any intervention. However, in some people, wax can accumulate and become impacted, partially or completely blocking the ear canal. Ear wax build-up is one of the most common ear-related problems in the UK and is a frequent cause of temporary hearing loss.

Certain factors increase the likelihood of ear wax impaction. These include naturally narrow or tortuous ear canals, excessive wax production, use of cotton buds (which push wax deeper into the canal), regular use of hearing aids or ear plugs (which can prevent natural wax migration), hairy ear canals, increasing age (as wax becomes harder and drier with age), and skin conditions affecting the ear canal. It is estimated that around 2.3 million people in the UK experience problematic ear wax each year, and approximately 4 million ears are syringed annually by NHS services.

Symptoms of ear wax impaction typically include a feeling of fullness or blockage in the ear, muffled hearing, tinnitus, earache, dizziness, and occasionally a reflex cough (due to stimulation of the vagus nerve). These symptoms can develop gradually as wax accumulates or suddenly — for example, after water enters the ear and causes the wax to swell.

In the UK, ear wax removal services are available through the NHS, though access varies by region, and some GP practices no longer offer the service directly. The three main methods of professional wax removal are microsuction (the use of a small suction device under direct vision, considered the safest method), ear irrigation (controlled flushing of the ear canal with warm water), and manual removal using specialist instruments. Ear syringing using a metal syringe is no longer recommended due to the higher risk of complications.

Self-care with olive oil or sodium bicarbonate ear drops is often the recommended first step. Applying two to three drops of olive oil (at room temperature) into the affected ear twice daily for five to seven days can soften the wax sufficiently for it to migrate out naturally, and also prepares the ear for professional removal if needed. Over-the-counter ear wax removal drops containing hydrogen peroxide or carbamide peroxide are also available from pharmacies. Cotton buds should never be used to remove ear wax, as they push the wax deeper and risk damaging the ear canal or eardrum.`,
    symptoms: [
      "A feeling of fullness or blockage in the ear",
      "Muffled hearing or reduced hearing in the affected ear",
      "Tinnitus — ringing, buzzing, or humming in the ear",
      "Earache or discomfort",
      "Itching in the ear canal",
      "Dizziness or a sense of imbalance",
      "A reflex cough caused by wax pressing on the ear canal wall",
    ],
    causes: [
      "Natural overproduction of cerumen (ear wax) by the glands in the ear canal",
      "Use of cotton buds, which push wax deeper into the ear canal",
      "Regular use of hearing aids, ear plugs, or in-ear headphones that prevent natural wax migration",
      "Narrow, tortuous, or hairy ear canals that trap wax",
      "Ageing — ear wax becomes harder and drier with age",
      "Skin conditions affecting the ear canal such as eczema or psoriasis",
    ],
    treatments: [
      "Olive oil or sodium bicarbonate ear drops to soften wax (2-3 drops twice daily for 5-7 days)",
      "Microsuction — removal using a small suction device under direct vision (safest method)",
      "Ear irrigation — controlled flushing with warm water using an electronic irrigator",
      "Manual removal using specialist instruments such as Jobson-Horne probes or curettes",
      "Over-the-counter ear drops containing hydrogen peroxide or carbamide peroxide",
      "Regular olive oil drops as a preventive measure for people prone to wax build-up",
    ],
    whenToSeek:
      "See your GP or an ear care professional if you experience a blocked or muffled feeling in your ear that does not resolve after using olive oil drops for a week, if you have ear pain, discharge, or sudden hearing loss, or if you wear hearing aids and find they are not fitting properly due to wax. Never attempt to remove wax with cotton buds, hairpins, or other objects.",
    icon: "shield",
    relatedConditions: ["hearing-loss", "tinnitus", "ear-infections"],
    relatedTests: ["standard-hearing-test", "tympanometry", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 14. Perforated Eardrum
  // -------------------------------------------------------------------------
  {
    slug: "perforated-eardrum",
    name: "Perforated Eardrum",
    shortDescription:
      "A hole or tear in the tympanic membrane (eardrum), which can cause hearing loss, pain, and increased susceptibility to ear infections. Most perforations heal on their own.",
    fullDescription: `A perforated eardrum (tympanic membrane perforation) is a hole or tear in the thin tissue that separates the ear canal from the middle ear. The eardrum plays two critical roles: it vibrates in response to sound waves, transmitting them to the ossicles in the middle ear, and it acts as a barrier protecting the middle ear from water, bacteria, and debris. When the eardrum is perforated, both of these functions are compromised to varying degrees.

Perforated eardrums are a common presentation in UK GP practices and ENT departments. They can result from a variety of causes, including middle ear infections (where pressure from pus or fluid causes the eardrum to rupture), trauma (such as a blow to the ear, insertion of objects into the ear canal, or sudden pressure changes from flying or diving — barotrauma), very loud sounds (blast injury), and medical procedures such as grommet insertion or ear syringing.

The symptoms of a perforated eardrum depend on the size and location of the perforation. Small perforations may cause only mild hearing loss and minimal discomfort, while larger tears can result in more significant conductive hearing loss (typically 10-40 dB) and increased vulnerability to middle ear infections. A perforation caused by infection is often accompanied by ear discharge (otorrhoea) and pain, which typically improves once the eardrum ruptures and the infected fluid drains. A sudden perforation from trauma usually causes sharp pain, followed by immediate hearing reduction and possibly tinnitus, bleeding from the ear, or dizziness.

Diagnosis is straightforward — the perforation is visible on otoscopy (examination with an auriscope). An audiogram and tympanometry may be performed to assess the impact on hearing. Most traumatic perforations heal spontaneously within two to three months without surgical intervention. During the healing period, it is essential to keep the ear dry — using cotton wool coated in petroleum jelly (Vaseline) when showering or bathing and avoiding swimming. Antibiotic ear drops may be prescribed if there are signs of infection.

If a perforation fails to heal on its own, or if it is large or causing significant hearing loss, surgical repair may be recommended. The operation is called a myringoplasty (or tympanoplasty if the ossicles also need repair). The procedure involves grafting a small piece of tissue — usually taken from the connective tissue covering the muscle above the ear (temporalis fascia) — over the perforation. Myringoplasty has a success rate of approximately 85-90% and is typically performed as a day-case procedure under general anaesthetic.`,
    symptoms: [
      "Sudden sharp pain in the ear (particularly with traumatic perforation)",
      "Hearing loss in the affected ear — usually mild to moderate",
      "Ear discharge — watery, bloody, or pus-like depending on the cause",
      "Tinnitus — ringing or buzzing in the affected ear",
      "A feeling of fullness or pressure in the ear",
      "Dizziness or vertigo — uncommon but can occur if the inner ear is affected",
    ],
    causes: [
      "Middle ear infection (otitis media) causing pressure build-up and eardrum rupture",
      "Trauma — a blow to the ear, insertion of objects (cotton buds), or ear syringing complications",
      "Barotrauma — sudden pressure changes from flying, diving, or a blast injury",
      "Very loud sounds (acoustic trauma) causing the eardrum to rupture",
      "Previous grommet insertion — the eardrum usually heals after grommets fall out, but occasionally a perforation persists",
    ],
    treatments: [
      "Watchful waiting — most traumatic perforations heal within 2-3 months without surgery",
      "Keeping the ear dry during healing — cotton wool with Vaseline when bathing, avoiding swimming",
      "Antibiotic ear drops if there are signs of infection",
      "Pain relief with paracetamol or ibuprofen",
      "Myringoplasty (surgical repair) for persistent perforations or those causing significant hearing loss",
      "Tympanoplasty if the ossicles (middle ear bones) also require repair",
    ],
    whenToSeek:
      "See your GP if you experience sudden ear pain followed by hearing loss or discharge from the ear, or if you suspect your eardrum may have been perforated. Seek urgent medical attention if there is significant bleeding from the ear, severe dizziness, or if the perforation was caused by a significant head injury. While most perforations heal on their own, medical assessment is important to rule out infection and monitor healing.",
    icon: "circle-slash",
    relatedConditions: ["ear-infections", "hearing-loss", "cholesteatoma"],
    relatedTests: ["tympanometry", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 15. Cholesteatoma
  // -------------------------------------------------------------------------
  {
    slug: "cholesteatoma",
    name: "Cholesteatoma",
    shortDescription:
      "A cholesteatoma is an abnormal collection of skin cells that grows behind the eardrum in the middle ear. Left untreated, it can erode bone and cause serious complications.",
    fullDescription: `A cholesteatoma is an abnormal, non-cancerous growth of skin cells (keratinising squamous epithelium) that develops in the middle ear, usually behind or within a retraction pocket of the eardrum. Despite its name, a cholesteatoma is not a tumour — it is essentially a cyst-like collection of dead skin cells that forms a pearl-like mass. However, cholesteatomas are locally destructive: as they grow, they can erode the tiny bones of the middle ear (ossicles), the bone surrounding the middle ear, and, in advanced cases, damage the inner ear, facial nerve, or structures of the skull base.

Cholesteatomas can be congenital (present from birth, rare) or acquired (developing during life, much more common). Acquired cholesteatomas typically develop in association with chronic Eustachian tube dysfunction, which creates negative pressure in the middle ear and causes the eardrum to be drawn inwards, forming a retraction pocket. Dead skin cells accumulate within this pocket and cannot migrate outwards normally, leading to the formation of a cholesteatoma. Recurrent ear infections and previous perforated eardrums are also risk factors. Cholesteatomas are estimated to affect approximately 9-12 per 100,000 people in the UK each year.

The early symptoms of a cholesteatoma often include a persistent, foul-smelling discharge from the ear and progressive hearing loss on the affected side. Unlike simple ear infections, the discharge from a cholesteatoma is characteristically offensive due to the breakdown of accumulated skin debris and secondary infection. Hearing loss is conductive (caused by erosion of the ossicles or blockage of the middle ear space) and gradually worsens as the cholesteatoma enlarges. If left untreated, complications can include erosion into the inner ear causing sensorineural hearing loss, vertigo, facial nerve damage (leading to facial weakness), mastoiditis (infection of the mastoid bone), meningitis, or brain abscess — though these serious complications are rare with modern medical care.

Diagnosis is made by clinical examination (otoscopy may reveal a retraction pocket with accumulated white debris or a polyp in the ear canal), audiometry, and CT scanning of the temporal bone to assess the extent of the cholesteatoma and any bony erosion.

Treatment for cholesteatoma is almost always surgical. The operation, called a mastoidectomy with or without tympanoplasty, aims to completely remove the cholesteatoma, eradicate infection, and where possible, reconstruct the hearing mechanism. There are two main surgical approaches: canal wall up (CWU) and canal wall down (CWD), each with advantages and disadvantages that the surgeon will discuss. Regular follow-up is essential after surgery, as cholesteatomas have a recurrence rate of approximately 10-30% depending on the type and extent of the initial disease. MRI scanning with diffusion-weighted imaging is increasingly used for surveillance, reducing the need for second-look surgery. In the UK, cholesteatoma surgery is performed by ENT surgeons in NHS hospitals, and lifelong follow-up is typically recommended.`,
    symptoms: [
      "Persistent, foul-smelling discharge from the ear",
      "Progressive hearing loss in the affected ear",
      "A feeling of fullness or pressure in the ear",
      "Earache or discomfort — though pain is not always present",
      "Dizziness or vertigo in advanced cases (indicating inner ear involvement)",
      "Facial weakness — rare but a sign of facial nerve involvement requiring urgent attention",
    ],
    causes: [
      "Chronic Eustachian tube dysfunction creating negative pressure and eardrum retraction",
      "Recurrent middle ear infections (chronic otitis media)",
      "Previous eardrum perforation, particularly marginal perforations",
      "Congenital cholesteatoma — skin cells trapped behind an intact eardrum during development (rare)",
      "Previous ear surgery or grommet insertion (uncommon contributing factor)",
    ],
    treatments: [
      "Surgical removal (mastoidectomy) — the definitive treatment for cholesteatoma",
      "Tympanoplasty — reconstruction of the eardrum and middle ear hearing mechanism",
      "Ossiculoplasty — reconstruction of the ossicular chain if bones have been eroded",
      "Antibiotic ear drops or aural toilet to manage infection before surgery",
      "Regular post-operative follow-up including MRI surveillance to monitor for recurrence",
      "Hearing aids if hearing reconstruction is not possible or hearing loss persists after surgery",
    ],
    whenToSeek:
      "See your GP urgently if you have a persistent or recurrent foul-smelling ear discharge, progressive hearing loss in one ear, or if you develop dizziness, facial weakness, or severe headache alongside ear symptoms. Cholesteatoma requires specialist ENT assessment and treatment. Early diagnosis and surgery reduce the risk of serious complications.",
    icon: "alert-circle",
    relatedConditions: ["perforated-eardrum", "ear-infections", "hearing-loss"],
    relatedTests: ["tympanometry", "standard-hearing-test", "bone-conduction-test"],
  },

  // -------------------------------------------------------------------------
  // 16. Otitis Media (Middle Ear Infection)
  // -------------------------------------------------------------------------
  {
    slug: "otitis-media",
    name: "Otitis Media",
    shortDescription:
      "Otitis media is an infection or inflammation of the middle ear, common in children but also affecting adults. It can cause ear pain, temporary hearing loss, and fever.",
    fullDescription: `Otitis media refers to infection or inflammation of the middle ear — the air-filled space behind the eardrum that contains the three tiny bones (ossicles) responsible for transmitting sound. It is one of the most common childhood illnesses in the United Kingdom, with most children experiencing at least one episode before the age of five. However, it also affects adults and can present as acute otitis media (a sudden, short-lived infection), chronic otitis media (persistent or recurrent infection lasting more than three months), or otitis media with effusion (fluid build-up without active infection, commonly known as glue ear).

Acute otitis media typically develops following an upper respiratory tract infection such as a cold. The infection causes swelling and inflammation of the Eustachian tube, which connects the middle ear to the back of the throat. When this tube becomes blocked, fluid accumulates in the middle ear, providing an ideal environment for bacteria or viruses to multiply. In children, the Eustachian tubes are shorter and more horizontal than in adults, making them particularly susceptible to blockage and infection.

Symptoms of acute otitis media include earache (which can be severe and throbbing), temporary hearing loss in the affected ear, fever, irritability and crying in young children, poor feeding in babies, and sometimes discharge from the ear if the eardrum perforates under pressure. The National Institute for Health and Care Excellence (NICE) guidelines recommend a "watch and wait" approach for most cases, as the majority resolve spontaneously within 48 to 72 hours. Pain relief with age-appropriate paracetamol or ibuprofen is the mainstay of treatment. Antibiotics are generally reserved for children under two with bilateral infection, those with discharge from the ear, or anyone with severe or worsening symptoms.

Chronic otitis media can lead to persistent or intermittent ear discharge, progressive hearing loss, and, in rare cases, complications such as mastoiditis (infection of the mastoid bone behind the ear), cholesteatoma, or intracranial infection. Recurrent acute episodes — defined as three or more infections in six months, or four or more in twelve months — may warrant referral to an ENT specialist. Treatment options for chronic or recurrent otitis media include long-term low-dose antibiotics, adenoidectomy (removal of the adenoids, which can harbour bacteria and block the Eustachian tube), or insertion of grommets (ventilation tubes) to allow the middle ear to drain and ventilate.

Prevention strategies include keeping up to date with childhood vaccinations (the pneumococcal vaccine helps reduce bacterial otitis media), breastfeeding for at least six months where possible, avoiding exposure to tobacco smoke, and not bottle-feeding infants in a lying-down position. Adults who experience recurrent middle ear infections should have their Eustachian tube function assessed and may benefit from nasal steroid sprays or treatment for underlying allergies.`,
    symptoms: [
      "Ear pain (otalgia) — often severe, throbbing, and worse at night",
      "Temporary hearing loss or muffled hearing in the affected ear",
      "Fever, particularly in young children",
      "Irritability, crying, and poor feeding in babies and toddlers",
      "Ear discharge (otorrhoea) — if the eardrum perforates",
      "A feeling of fullness or pressure in the ear",
      "Balance disturbance or clumsiness in young children",
      "Nausea or vomiting in some cases",
    ],
    causes: [
      "Bacterial infection — commonly Streptococcus pneumoniae, Haemophilus influenzae, or Moraxella catarrhalis",
      "Viral upper respiratory tract infections (colds and flu) leading to Eustachian tube swelling",
      "Eustachian tube dysfunction — especially common in children due to shorter, more horizontal tubes",
      "Enlarged adenoids blocking the Eustachian tube opening",
      "Allergies causing nasal congestion and Eustachian tube inflammation",
      "Exposure to tobacco smoke, which impairs mucociliary clearance",
    ],
    treatments: [
      "Pain relief with paracetamol or ibuprofen — the first-line treatment per NICE guidelines",
      "Watchful waiting for 48-72 hours, as most cases resolve without antibiotics",
      "Antibiotics (amoxicillin first-line) for severe cases, children under two with bilateral infection, or those with discharge",
      "Grommets (ventilation tubes) for recurrent or chronic otitis media",
      "Adenoidectomy if enlarged adenoids contribute to recurrent infections",
      "Nasal steroid sprays and antihistamines for underlying allergic causes",
    ],
    whenToSeek:
      "See your GP if earache is severe or lasts more than 48 hours, if there is discharge from the ear, if a child under two has symptoms of ear infection, or if symptoms recur frequently. Seek urgent medical attention if there is swelling, redness, or tenderness behind the ear (possible mastoiditis), high fever with severe headache, or facial weakness.",
    icon: "thermometer",
    relatedConditions: ["ear-infections", "glue-ear", "eustachian-tube-dysfunction"],
    relatedTests: ["tympanometry", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 17. Eustachian Tube Dysfunction
  // -------------------------------------------------------------------------
  {
    slug: "eustachian-tube-dysfunction",
    name: "Eustachian Tube Dysfunction",
    shortDescription:
      "Eustachian tube dysfunction occurs when the tubes connecting the middle ear to the back of the throat become blocked or fail to open properly, causing pressure, pain, and muffled hearing.",
    fullDescription: `The Eustachian tubes are narrow passages approximately 36 millimetres long that connect each middle ear to the nasopharynx (the area at the back of the nose and top of the throat). Their primary functions are to equalise air pressure between the middle ear and the outside environment, drain fluid and mucus from the middle ear, and protect the middle ear from pathogens. Eustachian tube dysfunction (ETD) occurs when these tubes become blocked, swollen, or fail to open and close properly, disrupting the pressure balance and drainage of the middle ear.

ETD is extremely common and is one of the most frequent reasons for GP consultations related to ear problems in the UK. It can affect people of all ages but is particularly prevalent in children (whose Eustachian tubes are shorter and more horizontal) and in adults with allergies, frequent colds, or sinus problems. Many people experience temporary ETD during flights, when driving through mountains, or when they have a cold — the familiar feeling of blocked or popping ears is a mild form of the condition.

The most common causes of ETD include upper respiratory tract infections (colds and flu), which cause swelling of the Eustachian tube lining; allergic rhinitis (hay fever) and other allergies that inflame the nasal passages and tube openings; sinusitis; enlarged adenoids in children; smoking or exposure to tobacco smoke; rapid altitude or pressure changes (flying, diving, or driving through mountains); and gastro-oesophageal reflux disease (GORD), where stomach acid can irritate the tube openings.

Symptoms of ETD include a feeling of fullness, pressure, or blockage in one or both ears; muffled hearing; popping, clicking, or crackling sounds in the ears; ear pain or discomfort (particularly during swallowing, yawning, or pressure changes); tinnitus; and dizziness or balance problems in some cases. The condition can be temporary — resolving once the underlying cause (such as a cold) clears — or chronic, lasting weeks or months.

Treatment depends on the underlying cause. For mild or temporary ETD, self-help measures are often effective: the Valsalva manoeuvre (gently blowing with the nose pinched and mouth closed), swallowing, yawning, or chewing gum can help open the tubes and equalise pressure. The Otovent device — a small balloon blown up through the nose — is available on prescription or over the counter and is recommended by NICE for both children and adults with ETD. Nasal decongestant sprays (such as xylometazoline) can provide short-term relief but should not be used for more than seven days due to the risk of rebound congestion. Nasal corticosteroid sprays (such as fluticasone or mometasone) are the mainstay of treatment for allergic ETD and can be used long-term. Antihistamines are helpful when allergies are a contributing factor. For persistent ETD that does not respond to conservative treatment, ENT referral may be appropriate — treatment options include grommet insertion or, more recently, Eustachian tube balloon dilation, a minimally invasive procedure that is increasingly available in the UK.`,
    symptoms: [
      "A feeling of fullness, pressure, or blockage in one or both ears",
      "Muffled or reduced hearing",
      "Popping, clicking, or crackling sounds when swallowing or yawning",
      "Ear pain or discomfort, particularly during altitude changes or flying",
      "Tinnitus — ringing or buzzing in the affected ear",
      "Difficulty equalising ear pressure (ears 'won't pop')",
      "Dizziness or mild balance problems in some cases",
    ],
    causes: [
      "Upper respiratory tract infections (colds and flu) causing Eustachian tube swelling",
      "Allergic rhinitis (hay fever) and other allergies inflaming the nasal passages",
      "Sinusitis — inflammation of the sinuses blocking the tube openings",
      "Enlarged adenoids, particularly in children",
      "Rapid altitude or pressure changes — flying, diving, or driving through mountains",
      "Smoking or exposure to tobacco smoke",
    ],
    treatments: [
      "Self-help techniques: Valsalva manoeuvre, swallowing, yawning, or chewing gum to open the tubes",
      "Otovent nasal balloon device — recommended by NICE for autoinflation",
      "Nasal corticosteroid sprays (fluticasone, mometasone) for allergic ETD — safe for long-term use",
      "Short-term nasal decongestant sprays (maximum seven days to avoid rebound congestion)",
      "Antihistamines for allergy-related Eustachian tube dysfunction",
      "Eustachian tube balloon dilation — a newer minimally invasive procedure for persistent cases",
    ],
    whenToSeek:
      "See your GP if you have persistent ear fullness, muffled hearing, or ear pressure lasting more than two weeks, if ETD is affecting your daily life or hearing, or if symptoms recur frequently. Seek urgent advice if you develop severe ear pain, hearing loss, or dizziness. Your GP can examine your ears and nasal passages and refer you to an ENT specialist if conservative treatments are not effective.",
    icon: "arrow-up-down",
    relatedConditions: ["otitis-media", "glue-ear", "ear-infections"],
    relatedTests: ["tympanometry", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 18. Misophonia
  // -------------------------------------------------------------------------
  {
    slug: "misophonia",
    name: "Misophonia",
    shortDescription:
      "Misophonia is a condition where specific everyday sounds — such as chewing, breathing, or clicking — trigger intense emotional reactions including anger, anxiety, or disgust.",
    fullDescription: `Misophonia, which translates literally as "hatred of sound," is a condition in which certain everyday sounds provoke strong negative emotional and physiological responses. Unlike hyperacusis, where a wide range of sounds are perceived as uncomfortably loud, misophonia is characterised by intense reactions to specific trigger sounds — most commonly oral or nasal sounds such as chewing, slurping, lip-smacking, breathing, sniffing, or throat-clearing. Other common triggers include repetitive sounds like pen-clicking, keyboard tapping, or clock ticking.

The condition is increasingly recognised by audiologists and psychologists in the UK, though it is not yet classified as a formal diagnosis in the ICD-11 or DSM-5. Research suggests it may affect up to 20% of the population to some degree, though severe misophonia that significantly impacts daily life is less common. It typically develops in childhood or early adolescence, often around the age of 10-12, and can worsen over time if not addressed. Trigger sounds often originate from family members initially before generalising to other sources.

The emotional responses triggered by misophonia are involuntary and can be overwhelming. People describe feelings of intense anger, rage, anxiety, panic, disgust, or a "fight or flight" response when exposed to their trigger sounds. These reactions can be accompanied by physical symptoms including increased heart rate, muscle tension, sweating, and a strong urge to escape the situation. The reactions are disproportionate to the actual sound and are typically recognised by the individual as irrational, yet they cannot be suppressed through willpower alone.

It is important to distinguish misophonia from hyperacusis. In hyperacusis, sounds are perceived as too loud and can cause physical discomfort or pain — the issue is with sound volume across a broad range of sounds. In misophonia, the sounds are typically at normal volume — the issue is with specific sounds that trigger an emotional response. However, the two conditions can co-occur, and some people experience elements of both.

Management of misophonia in the UK is evolving as understanding of the condition grows. Cognitive behavioural therapy (CBT) is currently the most evidence-based psychological treatment, helping people identify and modify the thought patterns and behaviours that maintain the condition. Exposure therapy — carefully controlled, gradual exposure to trigger sounds — may help reduce the intensity of reactions over time when guided by a specialist. Sound therapy, including the use of background noise or white noise generators to reduce the impact of trigger sounds, can provide relief. Audiologists with expertise in sound sensitivity conditions can offer assessment and management. Some NHS audiology departments now include misophonia in their tinnitus and hyperacusis services, though access varies across the UK. The British Tinnitus Association and Misophonia Institute provide information and support resources.`,
    symptoms: [
      "Intense anger, rage, or irritation triggered by specific sounds",
      "Anxiety or panic in response to hearing or anticipating trigger sounds",
      "Feelings of disgust when exposed to oral sounds such as chewing or slurping",
      "A strong urge to escape or flee from situations with trigger sounds",
      "Physical reactions: increased heart rate, muscle tension, sweating",
      "Avoidance of social situations, restaurants, or shared meals due to triggers",
      "Emotional distress that is recognised as disproportionate but cannot be controlled",
    ],
    causes: [
      "Abnormal connectivity between the auditory system and the limbic (emotional) system in the brain",
      "Typically develops in childhood or early adolescence, often around age 10-12",
      "May have a genetic component — the condition can run in families",
      "Possible association with anxiety disorders, OCD, or autism spectrum conditions",
      "Heightened sensitivity to pattern-based or repetitive sounds",
      "Conditioning and negative associations that strengthen over time",
    ],
    treatments: [
      "Cognitive behavioural therapy (CBT) to address thought patterns and behavioural responses",
      "Graduated exposure therapy with a specialist to reduce sensitivity to trigger sounds",
      "Sound therapy — background noise or white noise generators to mask triggers",
      "Mindfulness and relaxation techniques to manage the stress response",
      "Noise-reducing ear plugs or in-ear devices for particularly difficult environments",
      "Audiological assessment through NHS tinnitus and hyperacusis services where available",
    ],
    whenToSeek:
      "Seek help from your GP if misophonia is affecting your relationships, work, social life, or mental health. Your GP can refer you to an audiologist experienced in sound sensitivity conditions or to a psychologist for CBT. If you are experiencing significant anxiety or depression alongside misophonia, mental health support should be prioritised.",
    icon: "volume-x",
    relatedConditions: ["hyperacusis", "tinnitus", "hearing-loss"],
    relatedTests: ["tinnitus-assessment", "standard-hearing-test", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 19. Vestibular Neuritis
  // -------------------------------------------------------------------------
  {
    slug: "vestibular-neuritis",
    name: "Vestibular Neuritis",
    shortDescription:
      "Vestibular neuritis is an inner ear condition caused by inflammation of the vestibular nerve, leading to sudden, severe vertigo that can last several days.",
    fullDescription: `Vestibular neuritis is an inflammatory condition affecting the vestibular nerve — the branch of the vestibulocochlear nerve (cranial nerve VIII) that carries balance information from the inner ear to the brain. When this nerve becomes inflamed, it sends abnormal or reduced balance signals, causing sudden and often severe vertigo. Vestibular neuritis is one of the most common causes of acute peripheral vertigo in the UK, typically affecting adults between the ages of 30 and 60.

The condition is most commonly caused by a viral infection, either directly infecting the nerve or triggering an immune-mediated inflammatory response. Herpes simplex virus type 1 (HSV-1) has been most strongly implicated, though other viruses including varicella-zoster, influenza, and adenovirus may also be involved. The inflammation typically affects the superior branch of the vestibular nerve, though the inferior branch can also be involved.

The hallmark feature of vestibular neuritis is the sudden onset of severe rotational vertigo — a sensation that the world is spinning around you or that you are spinning within the room. This vertigo is continuous (not episodic like Meniere's disease) and is typically most intense during the first 24 to 48 hours. It is accompanied by nausea and vomiting, which can be significant, and a marked unsteadiness on the feet. The vertigo is worsened by head movement but is present even at rest. Critically, unlike labyrinthitis (a closely related condition), vestibular neuritis does not cause hearing loss — hearing remains normal because the cochlear portion of the nerve is unaffected. If hearing loss accompanies the vertigo, the diagnosis is more likely labyrinthitis.

Diagnosis is clinical, based on the characteristic history and examination findings. The head impulse test (a quick head-turning test performed by the doctor) is a key bedside test that helps differentiate vestibular neuritis from more serious central causes of vertigo. Caloric testing and videonystagmography (VNG) may be performed in specialist settings to confirm and quantify the vestibular deficit. MRI scanning may be requested to rule out stroke or other central nervous system causes, particularly in older patients or those with vascular risk factors.

Treatment in the acute phase focuses on symptom relief. Short-term vestibular suppressant medications such as prochlorperazine (Stemetil), cyclizine, or cinnarizine can help manage the vertigo and nausea. Anti-emetics such as domperidone or ondansetron may be needed if vomiting is severe. These medications should be used for the shortest possible time (typically no more than 48 to 72 hours) as they can delay the brain's natural compensation process. Oral corticosteroids (such as prednisolone) may be considered in the early stages, though evidence for their benefit is mixed.

Recovery from vestibular neuritis follows a characteristic pattern. The severe vertigo typically subsides within a few days as the brain begins to compensate for the imbalanced signals. Most people are able to return to daily activities within one to two weeks, though some residual unsteadiness and dizziness with rapid head movements can persist for weeks or months. Vestibular rehabilitation therapy (VRT) — a programme of exercises designed to promote central compensation — is the most effective treatment for ongoing symptoms and is recommended by NICE. VRT is available through NHS physiotherapy services and specialist balance clinics.`,
    symptoms: [
      "Sudden onset of severe rotational vertigo lasting several days",
      "Nausea and vomiting, often intense during the first 48 hours",
      "Marked unsteadiness and difficulty walking or standing",
      "Vertigo worsened by head movement but present at rest",
      "Nystagmus (involuntary eye movements) observable during acute episode",
      "No hearing loss — a key distinction from labyrinthitis",
      "Residual imbalance and dizziness with head movement lasting weeks to months",
    ],
    causes: [
      "Viral infection, most commonly herpes simplex virus type 1 (HSV-1)",
      "Post-viral immune-mediated inflammation of the vestibular nerve",
      "Other viral triggers including varicella-zoster, influenza, and adenovirus",
      "Possible reactivation of latent virus within the vestibular ganglion",
      "Reduced blood supply to the vestibular nerve in some cases",
    ],
    treatments: [
      "Short-term vestibular suppressants (prochlorperazine, cyclizine, cinnarizine) for acute symptom relief",
      "Anti-emetics for nausea and vomiting in the acute phase",
      "Vestibular rehabilitation therapy (VRT) — the most effective treatment for ongoing symptoms",
      "Gradual mobilisation and return to activity once acute vertigo subsides",
      "Oral corticosteroids may be considered in the first 72 hours (evidence is mixed)",
      "NHS physiotherapy and specialist balance clinic referral for persistent symptoms",
    ],
    whenToSeek:
      "Seek urgent medical attention if you experience sudden severe vertigo, particularly if accompanied by hearing loss, severe headache, double vision, facial weakness, slurred speech, or difficulty swallowing — these may indicate a stroke rather than vestibular neuritis. See your GP if vertigo is persistent, if you are unable to keep fluids down, or if balance problems continue beyond two to three weeks. Your GP can refer you for vestibular rehabilitation or specialist balance assessment.",
    icon: "rotate-ccw",
    relatedConditions: ["labyrinthitis", "menieres-disease", "hearing-loss"],
    relatedTests: ["balance-assessment", "standard-hearing-test", "auditory-brainstem-response"],
  },

  // -------------------------------------------------------------------------
  // 20. Labyrinthitis
  // -------------------------------------------------------------------------
  {
    slug: "labyrinthitis",
    name: "Labyrinthitis",
    shortDescription:
      "Labyrinthitis is inflammation of the labyrinth in the inner ear, causing sudden vertigo combined with hearing loss and tinnitus — distinguishing it from vestibular neuritis.",
    fullDescription: `Labyrinthitis is an inflammatory condition affecting the labyrinth — the complex system of fluid-filled channels and chambers in the inner ear responsible for both hearing and balance. When the labyrinth becomes inflamed, both the cochlea (the hearing organ) and the vestibular apparatus (the balance organ) are affected, resulting in a combination of vertigo, hearing loss, and tinnitus. This dual involvement of hearing and balance is the key feature that distinguishes labyrinthitis from vestibular neuritis, which affects the balance nerve alone and does not cause hearing loss.

Labyrinthitis can be caused by viral infection (viral labyrinthitis, the more common form) or bacterial infection (bacterial labyrinthitis, which is rarer but more serious). Viral labyrinthitis often follows an upper respiratory tract infection and is thought to be caused by the same viruses implicated in vestibular neuritis, including herpes simplex, influenza, and adenovirus. Bacterial labyrinthitis can develop as a complication of otitis media (middle ear infection) or, more rarely, meningitis. Bacterial labyrinthitis is a medical emergency requiring urgent antibiotic treatment, as it can lead to permanent profound hearing loss if not treated promptly.

The symptoms of viral labyrinthitis typically include sudden onset of vertigo (a spinning sensation), hearing loss in the affected ear (which may range from mild to severe), tinnitus, nausea and vomiting, and unsteadiness. The vertigo is usually most severe during the first few days and gradually improves over one to three weeks as the brain compensates for the disrupted signals. Hearing loss may be temporary or permanent depending on the severity of the inflammation and any damage to the cochlear hair cells.

Diagnosis is based on clinical history and examination. The combination of acute vertigo with unilateral hearing loss and tinnitus strongly suggests labyrinthitis. An audiogram should be performed to document the hearing loss and establish a baseline for monitoring recovery. The head impulse test helps confirm a peripheral (inner ear) cause of vertigo. MRI scanning may be performed to rule out other causes, including stroke and acoustic neuroma. In cases of suspected bacterial labyrinthitis, urgent CT or MRI imaging and hospital admission for intravenous antibiotics are required.

Treatment of viral labyrinthitis is similar to vestibular neuritis. In the acute phase, vestibular suppressant medications (prochlorperazine, cyclizine, or cinnarizine) and anti-emetics help manage vertigo and nausea. These should be used for the minimum time necessary — typically no more than 72 hours — to avoid delaying central compensation. Oral corticosteroids (prednisolone) may be prescribed in the early stages to reduce inflammation and potentially improve hearing outcomes, though the evidence base is still developing. Antiviral medications (such as aciclovir) may be considered if a herpes virus infection is suspected, though their benefit in labyrinthitis is uncertain.

Recovery from viral labyrinthitis typically follows the same pattern as vestibular neuritis: severe vertigo resolves within days, with residual imbalance improving over weeks to months with vestibular rehabilitation therapy (VRT). Hearing loss may partially or fully recover, but some degree of permanent sensorineural hearing loss may remain. An audiological follow-up is recommended to monitor hearing recovery and consider hearing aids if needed. VRT through NHS physiotherapy services is the most effective intervention for persistent balance symptoms.`,
    symptoms: [
      "Sudden onset of severe vertigo (spinning sensation)",
      "Hearing loss in the affected ear — ranging from mild to profound",
      "Tinnitus (ringing, buzzing, or hissing) in the affected ear",
      "Nausea and vomiting, often severe in the first few days",
      "Unsteadiness and difficulty with balance and walking",
      "Nystagmus (involuntary rhythmic eye movements)",
      "A feeling of fullness or pressure in the affected ear",
    ],
    causes: [
      "Viral infection — most commonly following an upper respiratory tract infection",
      "Herpes simplex virus, influenza, adenovirus, or other viral pathogens",
      "Bacterial infection — a complication of otitis media or meningitis (rarer but more serious)",
      "Autoimmune inflammation of the inner ear in some cases",
      "Spread of infection from the middle ear through the round or oval window",
    ],
    treatments: [
      "Short-term vestibular suppressants (prochlorperazine, cyclizine) for acute vertigo relief",
      "Anti-emetics for nausea and vomiting during the acute phase",
      "Oral corticosteroids (prednisolone) to reduce inflammation — may help preserve hearing",
      "Urgent intravenous antibiotics for bacterial labyrinthitis (medical emergency)",
      "Vestibular rehabilitation therapy (VRT) for ongoing balance problems",
      "Hearing aids if permanent sensorineural hearing loss results",
    ],
    whenToSeek:
      "Seek urgent medical attention if you experience sudden vertigo accompanied by hearing loss — particularly if there is a concurrent or recent ear infection, as bacterial labyrinthitis requires emergency treatment. See your GP promptly for any episode of sudden vertigo with hearing loss or tinnitus. If vertigo is accompanied by severe headache, facial weakness, double vision, or difficulty speaking, call 999 as these may indicate a stroke.",
    icon: "rotate-ccw",
    relatedConditions: ["vestibular-neuritis", "menieres-disease", "otitis-media"],
    relatedTests: ["balance-assessment", "standard-hearing-test", "auditory-brainstem-response"],
  },

  // -------------------------------------------------------------------------
  // 21. Swimmer's Ear (Otitis Externa)
  // -------------------------------------------------------------------------
  {
    slug: "swimmers-ear",
    name: "Swimmer's Ear",
    shortDescription:
      "Swimmer's ear (otitis externa) is an infection of the outer ear canal, commonly caused by water exposure. It causes pain, itching, discharge, and temporary hearing loss.",
    fullDescription: `Swimmer's ear, medically known as otitis externa, is an infection or inflammation of the external ear canal — the passage from the outer ear (pinna) to the eardrum. It is called "swimmer's ear" because frequent water exposure is one of the most common causes, but the condition can affect anyone and has many other triggers. Otitis externa is a very common presentation in UK GP practices, accounting for a significant proportion of ear-related consultations, with peak incidence during the summer months when swimming and water activities increase.

The ear canal is normally protected by a thin layer of acidic cerumen (ear wax) that inhibits bacterial and fungal growth. When this protective layer is disrupted — by water exposure, excessive cleaning with cotton buds, scratching, or the use of hearing aids or ear plugs — the skin of the ear canal becomes vulnerable to infection. In swimmer's ear, water trapped in the ear canal creates a warm, moist environment that promotes the growth of bacteria (most commonly Pseudomonas aeruginosa and Staphylococcus aureus) or fungi (Aspergillus or Candida species). Fungal otitis externa (otomycosis) is increasingly recognised in the UK and can be more difficult to treat.

The primary symptom of swimmer's ear is ear pain (otalgia), which is often severe and characteristically worsened by pulling the pinna (outer ear) or pressing on the tragus (the small cartilage flap in front of the ear canal). This distinguishes otitis externa from otitis media, where pinna manipulation is not typically painful. Other symptoms include itching in the ear canal (often an early symptom), redness and swelling of the ear canal, discharge (clear, yellowish, or greenish), a feeling of fullness or blockage, and temporary hearing loss caused by swelling, debris, or discharge in the canal.

Diagnosis is made by clinical examination with an otoscope, which reveals a red, swollen, and often debris-filled ear canal. In more severe cases, the canal may be so swollen that the eardrum cannot be visualised. Antibiotic and anti-inflammatory ear drops are the standard treatment — commonly a combination of an antibiotic (such as ciprofloxacin or neomycin) and a corticosteroid (such as dexamethasone). Acetic acid ear drops (such as EarCalm, available over the counter in UK pharmacies) can be effective for mild cases and work by restoring the natural acidic environment of the ear canal. If the ear canal is very swollen, an ear wick (a small sponge inserted into the canal) may be used to ensure the drops reach the infected area. Oral antibiotics are rarely needed unless the infection has spread beyond the ear canal or the patient is immunocompromised.

Prevention is key for people prone to recurrent swimmer's ear. Keeping the ears dry is the most important measure — using well-fitted swim plugs, drying the ears thoroughly after swimming or showering (tilting the head to drain water, and using a hair dryer on the lowest setting held at arm's length), and avoiding cotton buds or other objects in the ear canal. Acetic acid drops (a 2% solution, or equal parts white vinegar and rubbing alcohol) used after swimming can help prevent infection by maintaining the ear canal's acidic pH. People who wear hearing aids should ensure their moulds are cleaned regularly and allow the ears to "breathe" by removing aids for periods during the day.`,
    symptoms: [
      "Ear pain (otalgia) — often severe, worsened by pulling the outer ear or pressing the tragus",
      "Itching in the ear canal, often an early symptom before pain develops",
      "Redness and swelling of the ear canal",
      "Discharge from the ear — clear, yellow, greenish, or foul-smelling",
      "A feeling of fullness or blockage in the affected ear",
      "Temporary hearing loss due to swelling and debris in the canal",
      "Tenderness and sometimes swelling of the lymph nodes near the ear",
      "Flaking or peeling skin in the ear canal in chronic or fungal cases",
    ],
    causes: [
      "Water trapped in the ear canal after swimming, bathing, or water sports",
      "Damage to the ear canal skin from cotton buds, fingernails, or other objects",
      "Regular use of hearing aids, ear plugs, or in-ear headphones disrupting the protective wax layer",
      "Skin conditions affecting the ear canal — eczema, psoriasis, or seborrhoeic dermatitis",
      "Bacterial infection (most commonly Pseudomonas aeruginosa or Staphylococcus aureus)",
      "Fungal infection (otomycosis) — Aspergillus or Candida species",
    ],
    treatments: [
      "Antibiotic and corticosteroid ear drops (e.g., ciprofloxacin/dexamethasone) — the mainstay of treatment",
      "Acetic acid ear drops (EarCalm) for mild cases — available over the counter in UK pharmacies",
      "Antifungal ear drops (clotrimazole) for fungal otitis externa",
      "Ear wick insertion if the canal is too swollen for drops to penetrate",
      "Pain relief with paracetamol or ibuprofen",
      "Keeping the ear dry throughout treatment — avoiding swimming, using cotton wool with Vaseline when showering",
    ],
    whenToSeek:
      "See your GP if you have ear pain that is worsening, if there is discharge from the ear, if hearing loss develops, or if symptoms have not improved after using over-the-counter ear drops for 48 hours. Seek urgent medical attention if there is severe pain with fever, spreading redness or swelling around the ear, or if you have diabetes or a weakened immune system, as these increase the risk of malignant (necrotising) otitis externa — a serious complication requiring hospital treatment.",
    icon: "droplets",
    relatedConditions: ["ear-infections", "ear-wax-buildup", "hearing-loss"],
    relatedTests: ["standard-hearing-test", "tympanometry", "otoacoustic-emissions"],
  },

  // -------------------------------------------------------------------------
  // 22. Barotrauma
  // -------------------------------------------------------------------------
  {
    slug: "barotrauma",
    name: "Barotrauma",
    shortDescription:
      "Ear barotrauma is pressure-related damage to the ear caused by rapid changes in altitude or depth, commonly experienced during flying, diving, or driving through mountains.",
    fullDescription: `Ear barotrauma (also known as aerotitis media or barotitis media) occurs when the air pressure in the middle ear fails to equalise with the external environmental pressure, causing stress and damage to the eardrum and middle ear structures. It is an extremely common condition — most people have experienced at least mild barotrauma during a flight, particularly during descent when the cabin pressure rises and the ears feel blocked or painful.

The middle ear is an air-filled space sealed by the eardrum on one side and connected to the throat via the Eustachian tube on the other. For the eardrum to function properly, the air pressure on both sides must be equal. During ascent (in an aircraft or while surfacing from a dive), the air in the middle ear expands and typically escapes passively through the Eustachian tube. During descent, however, the increasing external pressure compresses the air in the middle ear, creating negative pressure that retracts the eardrum inwards. The Eustachian tube must actively open (through swallowing, yawning, or the Valsalva manoeuvre) to allow air into the middle ear and restore the pressure balance. If the tube fails to open — due to congestion, infection, swelling, or anatomical factors — barotrauma can result.

Barotrauma is classified by severity. Mild barotrauma causes ear fullness, discomfort, and mild hearing reduction, with the eardrum appearing slightly retracted but intact. Moderate barotrauma involves more significant pain, bleeding into the middle ear (haemotympanum — visible as a blue or red discolouration behind the eardrum), and more pronounced hearing loss. Severe barotrauma can cause eardrum perforation, middle ear effusion, severe pain, hearing loss, vertigo, and, in rare cases during diving, inner ear barotrauma (with a risk of perilymphatic fistula, a leak of inner ear fluid that can cause permanent hearing loss and prolonged vertigo).

People at increased risk of ear barotrauma include those with colds, upper respiratory infections, allergic rhinitis, or sinusitis (all of which cause Eustachian tube swelling); young children (whose Eustachian tubes are less efficient); people with a history of ear surgery; frequent flyers and divers; and those with known Eustachian tube dysfunction.

Prevention is the most effective approach and is straightforward for most people. During flights, chew gum, swallow frequently, yawn, or perform the Valsalva manoeuvre (gently blowing with the nose pinched and mouth closed) during descent. Feed babies or offer a dummy during descent, as the sucking and swallowing motion helps open the Eustachian tubes. Use a nasal decongestant spray (such as xylometazoline) 30 to 60 minutes before descent if you are congested or prone to barotrauma — NHS and aviation medicine guidelines support this practice. Oral decongestants (pseudoephedrine) taken an hour before flying are another option. Avoid flying when you have a significant cold or sinus infection if possible. The Otovent nasal balloon can be useful for pre-flight Eustachian tube preparation.

For divers, proper equalisation technique during descent is critical. The Valsalva or Frenzel manoeuvre should be performed frequently and early during the dive — if pressure builds up before equalising, it becomes much harder to open the tubes. Never dive with a cold or congested nose. If ear pain develops during a dive, stop the descent, ascend slightly, and attempt to equalise.

Treatment of barotrauma depends on severity. Mild cases resolve spontaneously once pressure equalises. Nasal decongestants and antihistamines can help the Eustachian tube recover its function. For moderate cases with middle ear effusion or haemotympanum, conservative management with monitoring is usually appropriate, and symptoms typically resolve within one to three weeks. Antibiotic ear drops may be prescribed if eardrum perforation occurs to prevent secondary infection. Severe cases, particularly inner ear barotrauma from diving, require urgent ENT assessment and may need surgical intervention.`,
    symptoms: [
      "Ear pain or discomfort during pressure changes (descent in an aircraft, diving, driving through mountains)",
      "A feeling of fullness or blockage in one or both ears",
      "Muffled hearing or temporary hearing loss",
      "Tinnitus — ringing or buzzing following a pressure change",
      "Dizziness or vertigo in more severe cases",
      "Bleeding from the ear or visible blood behind the eardrum (haemotympanum)",
      "Eardrum perforation in severe cases — sudden pain relief followed by discharge",
    ],
    causes: [
      "Rapid descent in an aircraft — the most common cause of barotrauma in the UK",
      "Scuba diving — particularly during descent without adequate equalisation",
      "Upper respiratory infections or colds causing Eustachian tube congestion",
      "Allergic rhinitis or sinusitis preventing normal Eustachian tube function",
      "Driving through rapid altitude changes (mountain passes, tunnels)",
      "Hyperbaric oxygen therapy — pressure changes during treatment",
    ],
    treatments: [
      "Valsalva manoeuvre, swallowing, yawning, or chewing gum to equalise pressure",
      "Nasal decongestant sprays (xylometazoline) used 30-60 minutes before descent",
      "Oral decongestants (pseudoephedrine) taken one hour before flying",
      "Nasal corticosteroid sprays for people with allergic rhinitis or chronic congestion",
      "Conservative management with monitoring for mild to moderate cases",
      "Urgent ENT assessment for severe barotrauma, particularly inner ear barotrauma from diving",
    ],
    whenToSeek:
      "See your GP if ear pain, hearing loss, or fullness persists for more than 24 hours after a pressure change, or if you experience discharge or bleeding from the ear. Seek urgent medical attention if you develop severe vertigo, significant hearing loss, or facial weakness following diving or flying — these may indicate inner ear barotrauma or perilymphatic fistula requiring specialist assessment. If barotrauma is recurrent, ask your GP about referral for Eustachian tube function assessment.",
    icon: "plane",
    relatedConditions: ["eustachian-tube-dysfunction", "perforated-eardrum", "hearing-loss"],
    relatedTests: ["tympanometry", "standard-hearing-test", "balance-assessment"],
  },
];

// =============================================================================
// HEARING GUIDES (18)
// =============================================================================

export const hearingGuides: HearingGuide[] = [
  // -------------------------------------------------------------------------
  // 1. How Often Should You Have a Hearing Test?
  // -------------------------------------------------------------------------
  {
    slug: "how-often-hearing-test",
    title: "How Often Should You Have a Hearing Test?",
    shortDescription:
      "Regular hearing checks are important for maintaining ear health. Learn how often you should book a hearing test based on your age, occupation, and risk factors.",
    fullDescription: `Unlike routine eye tests and dental check-ups, hearing tests are not yet part of the standard NHS health screening programme for adults in the UK. However, hearing health experts and organisations including the Royal National Institute for Deaf People (RNID) recommend that adults should have their hearing tested regularly — particularly from middle age onwards — to catch any changes early and ensure the best possible outcomes.

As a general guideline, adults aged 18-50 with no known risk factors or concerns should have a baseline hearing test and then follow up every five to ten years. However, if you work in a noisy environment, have a family history of hearing loss, or are exposed to loud music or machinery, more frequent testing — ideally every one to three years — is advisable. Your employer is legally required to provide hearing surveillance under the Control of Noise at Work Regulations 2005 if you are regularly exposed to noise levels above 85 dB.

From age 50 onwards, hearing tests every three years are recommended, as age-related hearing loss (presbycusis) becomes increasingly common. By age 60, around 40% of adults have some degree of hearing loss, and by 70 this rises to approximately 70%. Regular testing allows gradual changes to be monitored and hearing aids to be fitted at the right time — research consistently shows that people who address hearing loss early adapt better to hearing aids and maintain better cognitive function.

For children, hearing screening is part of the NHS Newborn Hearing Screening Programme (NHSP), which tests all babies within the first few weeks of life. Further hearing checks are included in the Health Visitor developmental reviews at around 9-12 months and again before starting school. If there are any concerns about a child's hearing at any age, parents should not wait for a scheduled check — contact your GP or health visitor promptly.

You should book a hearing test sooner than your next scheduled check if you notice any change in your hearing, if you develop tinnitus, if you find yourself regularly asking people to repeat themselves, if you're turning up the volume on the television, or if a family member or colleague suggests your hearing may have changed. In the UK, hearing tests are available free on the NHS (via GP referral to an audiology department) and from many high-street audiologists who offer free hearing assessments.`,
    keyPoints: [
      "Adults aged 18-50 without risk factors: baseline test, then every 5-10 years",
      "Adults over 50: every 3 years, as age-related hearing loss becomes increasingly common",
      "Workers in noisy environments: annual or biennial audiometric testing (legally required above 85 dB)",
      "Newborns are screened through the NHS Newborn Hearing Screening Programme within weeks of birth",
      "Book a test sooner if you notice any change in hearing, develop tinnitus, or others comment on your hearing",
      "NHS hearing tests are free via GP referral; many high-street audiologists offer free assessments",
      "Early identification of hearing loss leads to better outcomes with hearing aids and reduced cognitive decline risk",
    ],
    icon: "calendar",
    relatedGuides: ["hearing-loss-signs", "nhs-hearing-services", "preparing-for-hearing-test"],
  },

  // -------------------------------------------------------------------------
  // 2. How to Prepare for a Hearing Test
  // -------------------------------------------------------------------------
  {
    slug: "preparing-for-hearing-test",
    title: "How to Prepare for a Hearing Test",
    shortDescription:
      "Knowing what to expect at a hearing test can help you feel prepared and get the most accurate results. Here is a practical guide to getting ready.",
    fullDescription: `A hearing test is a straightforward, painless appointment that typically lasts between 30 and 60 minutes. Whether you are attending an NHS audiology appointment or visiting a private audiologist, a little preparation can help ensure your results are as accurate as possible and that you get the most out of your appointment.

Before your appointment, it is helpful to use olive oil ear drops for a few days beforehand if you are prone to ear wax build-up. Excess wax can affect the accuracy of hearing tests, and in some cases, the audiologist may need to reschedule if the ear canals are blocked. Two to three drops of olive oil (at room temperature) in each ear, twice daily for three to five days before your appointment, can help soften and clear any wax. Avoid using cotton buds, as these push wax deeper.

Think about your hearing history before the appointment. The audiologist will ask you questions about your hearing — when you first noticed any changes, whether it affects one or both ears, whether you have tinnitus, any noise exposure history, your medical history (including ear infections, head injuries, or medications), and your family history of hearing loss. It can be helpful to jot down notes beforehand so you do not forget anything important. If a family member or partner has noticed changes in your hearing, consider bringing them along — they can provide useful additional perspective and can help you remember the audiologist's advice.

On the day of your test, try to avoid exposure to very loud noise in the 24 hours before your appointment, as temporary noise exposure can temporarily shift your hearing thresholds. This means avoiding concerts, loud music through headphones, power tools, or other intense noise sources. Arrive a few minutes early to allow time to fill in any questionnaires or registration forms.

During the test, you will typically undergo pure tone audiometry, where you wear headphones and press a button or raise your hand each time you hear a sound. You may also have speech audiometry (repeating words at different volumes), tympanometry (a quick pressure test of the eardrum), and otoscopy (a visual inspection of your ear canals and eardrums). The audiologist will explain each test as they go. Do not worry about "passing" or "failing" — it is not an exam. The aim is to get an accurate picture of your hearing.

After the test, the audiologist will explain your audiogram (a graph of your hearing results) and discuss any next steps. If hearing aids are recommended, they will discuss the options available. If you are attending an NHS appointment, behind-the-ear hearing aids are available free of charge. Ask questions — it is your appointment, and a good audiologist will take the time to ensure you understand your results and feel confident about the recommended management plan.`,
    keyPoints: [
      "Use olive oil ear drops for 3-5 days before your appointment if you are prone to ear wax",
      "Prepare notes on your hearing history, noise exposure, medications, and family hearing loss",
      "Avoid loud noise for 24 hours before the test for the most accurate results",
      "Consider bringing a family member or partner for additional perspective",
      "Tests are painless and typically last 30-60 minutes",
      "You will usually have pure tone audiometry, speech audiometry, and tympanometry",
      "Ask the audiologist to explain your results and discuss next steps clearly",
    ],
    icon: "clipboard-list",
    relatedGuides: ["understanding-audiogram", "how-often-hearing-test", "nhs-hearing-services"],
  },

  // -------------------------------------------------------------------------
  // 3. Understanding Your Audiogram Results
  // -------------------------------------------------------------------------
  {
    slug: "understanding-audiogram",
    title: "Understanding Your Audiogram Results",
    shortDescription:
      "An audiogram is a graph that shows the softest sounds you can hear at different pitches. Learn how to read and interpret your hearing test results.",
    fullDescription: `An audiogram is the standard visual representation of your hearing ability, produced during a pure tone audiometry test. Understanding how to read your audiogram can help you engage more fully with your hearing healthcare and make informed decisions about treatment. While your audiologist will explain your results, having a basic understanding of what the graph shows can be empowering.

The audiogram is a graph with two axes. The horizontal axis (x-axis) shows frequency (pitch) measured in Hertz (Hz), typically ranging from 250 Hz (low-pitched sounds, like a bass drum) on the left to 8000 Hz (high-pitched sounds, like a bird singing) on the right. The vertical axis (y-axis) shows intensity (volume) measured in decibels (dB HL), with quiet sounds at the top (around 0-10 dB) and loud sounds at the bottom (around 100-120 dB). This can feel counterintuitive — the "better" your hearing, the higher up the graph your marks will appear.

During the test, the audiologist finds the softest sound you can hear at each frequency — this is your hearing threshold. These thresholds are plotted on the audiogram. Typically, the right ear is marked with red circles and the left ear with blue crosses, though some audiologists use different conventions. Air conduction results (sounds delivered through headphones) show the overall hearing ability. Bone conduction results (sounds delivered through a vibrator placed on the bone behind your ear) test the inner ear directly, bypassing the outer and middle ear. Comparing air and bone conduction results helps determine the type of hearing loss: if both are reduced equally, the loss is sensorineural; if air conduction is worse than bone conduction, there is a conductive component.

Hearing loss is categorised by degree. Normal hearing is 0-25 dB, mild hearing loss is 26-40 dB (difficulty hearing soft speech and conversation in noisy environments), moderate is 41-70 dB (difficulty hearing normal conversation without amplification), severe is 71-90 dB (only loud sounds are audible without hearing aids), and profound is 91 dB or greater (most sounds are inaudible without powerful hearing aids or cochlear implants).

The pattern of hearing loss on the audiogram provides important diagnostic information. A flat audiogram shows equal loss across all frequencies. A high-frequency sloping loss (the most common pattern) suggests age-related or noise-induced hearing loss. A low-frequency loss may indicate Meniere's disease. A "cookie bite" pattern (loss in the mid-frequencies) can suggest a genetic cause. An asymmetric audiogram — where one ear is significantly different from the other — requires further investigation, including MRI, to rule out conditions such as acoustic neuroma.

Your audiogram results, combined with your symptoms and medical history, guide the audiologist's recommendations for management, which may include hearing aids, further tests, medical referral, or monitoring with repeat audiograms.`,
    keyPoints: [
      "The audiogram plots how loud sounds need to be for you to hear them at different pitches",
      "Lower marks on the graph mean poorer hearing — the scale runs from soft (top) to loud (bottom)",
      "Right ear is usually shown in red (circles), left ear in blue (crosses)",
      "Normal hearing thresholds are 0-25 dB; mild loss is 26-40 dB; moderate is 41-70 dB",
      "Air conduction vs bone conduction results help distinguish sensorineural from conductive hearing loss",
      "A high-frequency sloping loss is the most common pattern, often from ageing or noise exposure",
      "Asymmetric results (one ear significantly worse) should be investigated further with MRI",
      "Your audiologist will explain your specific results and recommend appropriate next steps",
    ],
    icon: "bar-chart-2",
    relatedGuides: ["preparing-for-hearing-test", "choosing-hearing-aids", "hearing-loss-signs"],
  },

  // -------------------------------------------------------------------------
  // 4. Choosing the Right Hearing Aids
  // -------------------------------------------------------------------------
  {
    slug: "choosing-hearing-aids",
    title: "Choosing the Right Hearing Aids",
    shortDescription:
      "A practical UK guide to choosing hearing aids — from understanding the types available on the NHS and privately to finding the right features for your lifestyle.",
    fullDescription: `If your hearing test shows that you would benefit from hearing aids, choosing the right ones can feel overwhelming given the range of options available. Understanding the different types, features, and how the NHS and private routes compare will help you make a confident and informed decision.

In the UK, hearing aids are available free of charge on the NHS. NHS hearing aids are typically behind-the-ear (BTE) models, which sit behind the ear with a tube directing sound into a mould in the ear canal. Modern NHS hearing aids are digital, programmable, and significantly more advanced than those available even a decade ago. They are supplied, fitted, and maintained (including batteries or rechargeable options) at no cost. The main limitation of the NHS route is that the range of styles available is narrower than the private market, and waiting times for appointments can vary from a few weeks to several months depending on your local audiology service.

Private audiologists offer a much wider range of hearing aid styles. Behind-the-ear (BTE) aids remain popular for their power and reliability. Receiver-in-canal (RIC) models are smaller, with the receiver (speaker) sitting inside the ear canal, offering a more discreet appearance and a natural sound quality. In-the-ear (ITE) aids fit into the bowl of the outer ear. In-the-canal (ITC) and completely-in-canal (CIC) aids are even smaller and less visible, though they may not be suitable for severe hearing loss or very small ear canals. Invisible-in-canal (IIC) aids sit deep in the ear canal and are virtually undetectable but are limited to mild to moderate hearing loss.

When choosing hearing aids, consider your lifestyle and listening needs. If you frequently attend meetings, social gatherings, or noisy restaurants, look for aids with directional microphones, noise reduction, and speech enhancement features. If you are active or spend time outdoors, water and dust resistance (IP68 rating) is valuable. Bluetooth connectivity allows hearing aids to stream phone calls, music, and television audio directly to your ears. Rechargeable models eliminate the need to change tiny batteries. Many modern hearing aids can be controlled and adjusted via smartphone apps, and some offer artificial intelligence-driven sound processing that automatically adapts to different environments.

The cost of private hearing aids in the UK typically ranges from around 500 to 3,500 per ear, depending on the technology level and features. This usually includes the hearing assessment, fitting, programming, and follow-up appointments. Some private audiologists offer payment plans or interest-free finance. It is important to compare providers and check what is included in the price — follow-up care, adjustments, and aftercare policies vary between clinics.

Regardless of whether you choose NHS or private hearing aids, a successful fitting depends on proper programming by an experienced audiologist, realistic expectations (hearing aids improve hearing but do not restore it to normal), a commitment to wearing them consistently (the brain needs time to adapt), and regular follow-up appointments to fine-tune the settings. Most people take two to four weeks to adjust to wearing hearing aids, and it is normal to find them tiring or overwhelming at first.`,
    keyPoints: [
      "NHS hearing aids are free, digital, and increasingly sophisticated — BTE models are standard",
      "Private hearing aids offer more styles (RIC, ITE, CIC, IIC) and advanced features like Bluetooth",
      "Consider your lifestyle: noisy environments need directional microphones and noise reduction",
      "Rechargeable hearing aids are convenient and eliminate the need for tiny batteries",
      "Private hearing aids typically cost 500-3,500 per ear, usually including fitting and aftercare",
      "Adjustment takes 2-4 weeks — wear aids consistently and attend all follow-up appointments",
      "A good audiologist will programme aids carefully and provide ongoing support",
    ],
    icon: "headphones",
    relatedGuides: ["understanding-audiogram", "hearing-aids-tips", "nhs-hearing-services"],
  },

  // -------------------------------------------------------------------------
  // 5. Protecting Your Hearing
  // -------------------------------------------------------------------------
  {
    slug: "protecting-your-hearing",
    title: "Protecting Your Hearing",
    shortDescription:
      "Noise-induced hearing loss is entirely preventable. Learn practical steps to protect your hearing at work, at home, and during leisure activities.",
    fullDescription: `Noise-induced hearing loss is the second most common form of hearing loss after age-related decline, and it is entirely preventable. The Health and Safety Executive (HSE) estimates that over 17,000 people in the UK suffer from work-related hearing problems caused or worsened by noise. Beyond the workplace, recreational noise from concerts, sporting events, personal music players, and power tools is an increasingly significant concern.

Understanding when noise is dangerous is the first step in protecting your hearing. Sound is measured in decibels (dB). Normal conversation is around 60 dB and poses no risk. A busy road is approximately 80 dB — the level at which long-term exposure can begin to cause damage. At 85 dB, exposure for more than eight hours can cause permanent hearing damage, and the safe exposure time halves for every 3 dB increase. A nightclub or live concert at 100 dB can damage hearing in just 15 minutes. A rough rule of thumb: if you need to raise your voice to be heard by someone at arm's length, the noise level is likely above 85 dB and hearing protection should be used.

In the workplace, UK employers have legal obligations under the Control of Noise at Work Regulations 2005. At 80 dB, employers must assess the risk and provide information and training. At 85 dB, hearing protection must be provided and its use enforced in designated hearing protection zones. Regular audiometric testing (hearing surveillance) should be offered to workers exposed above 85 dB. Employees have a responsibility to use the hearing protection provided and to report any changes in their hearing.

For personal and recreational noise, practical measures include using well-fitted ear plugs or ear defenders when using power tools, mowing the lawn, or attending motorsport events. Musicians' ear plugs, which reduce volume evenly across all frequencies without distorting sound quality, are ideal for concerts, festivals, and playing in bands. When using headphones or earbuds, follow the 60/60 rule: listen at no more than 60% of maximum volume for no more than 60 minutes at a time. Noise-cancelling headphones can be particularly helpful, as they reduce the need to turn up the volume to drown out background noise.

Look after your overall ear health by keeping ears clean and dry (but never inserting cotton buds into the ear canal), treating ear infections promptly, and being aware of medications that can affect hearing (ototoxic drugs). Finally, regular hearing tests can catch early signs of noise-induced damage before you notice symptoms yourself, allowing preventive measures to be strengthened.`,
    keyPoints: [
      "Noise above 85 dB can cause permanent hearing damage — this includes many workplaces and leisure activities",
      "Use well-fitted ear plugs or defenders for power tools, concerts, motorsport, and shooting",
      "Follow the 60/60 rule for headphones: max 60% volume for max 60 minutes at a time",
      "UK employers must provide hearing protection and surveillance for noise above 85 dB",
      "Musicians' ear plugs reduce volume without distorting sound quality",
      "Noise-cancelling headphones help reduce the temptation to turn volume up in noisy environments",
      "Regular hearing tests can catch early noise damage before symptoms become noticeable",
      "Never insert cotton buds into the ear canal — they push wax deeper and risk damage",
    ],
    icon: "shield-check",
    relatedGuides: ["workplace-hearing-safety", "hearing-loss-signs", "how-often-hearing-test"],
  },

  // -------------------------------------------------------------------------
  // 6. Signs You Might Have Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "hearing-loss-signs",
    title: "Signs You Might Have Hearing Loss",
    shortDescription:
      "Hearing loss often develops gradually, making it easy to miss. Learn the common signs that suggest your hearing may have changed.",
    fullDescription: `Hearing loss is one of the most common health conditions in the United Kingdom, yet it often goes unrecognised for years — sometimes even a decade — before people seek help. Because the most common forms of hearing loss develop gradually, people naturally adapt and compensate without realising how much they are missing. Recognising the early signs of hearing loss is crucial, as research consistently shows that early intervention leads to better outcomes.

One of the earliest and most telling signs is difficulty following conversations in noisy environments. If you find yourself struggling to hear clearly in restaurants, at family gatherings, or in busy workplaces, but manage reasonably well in quiet one-to-one situations, this is a classic pattern of mild high-frequency hearing loss. You may feel that people are "mumbling" rather than speaking clearly — this happens because consonant sounds (which carry most of the meaning in speech) are typically high-frequency and are lost first, while the lower-frequency vowel sounds remain audible. The result is speech that sounds loud enough but is not clear enough to understand.

Other common signs include frequently asking people to repeat themselves, turning up the volume on the television or radio to levels that others find uncomfortably loud, difficulty hearing on the telephone (particularly mobile phones), and missing doorbells, alarms, or notification sounds. You may find that you hear better when you can see the speaker's face, as you are unconsciously relying on lip-reading and facial expressions to fill in the gaps.

Social and emotional changes can also signal hearing loss. People with untreated hearing loss often become withdrawn from social situations because conversations are exhausting and stressful. You may feel fatigued after social events from the effort of concentrating on hearing. Relationships can be strained, with partners or family members feeling frustrated about repeating themselves. Some people experience increased irritability or anxiety in noisy situations.

If others have suggested that your hearing might not be what it used to be, take their observation seriously — family and friends are often the first to notice hearing changes. Similarly, if you find yourself nodding along in conversations without fully understanding what was said, or avoiding situations where hearing is difficult, these are strong indicators that a hearing test is worthwhile.

In the UK, hearing tests are readily accessible. Your GP can refer you to an NHS audiology department for a free assessment, and many high-street hearing aid providers offer complimentary hearing checks. Online hearing screening tools can also give a rough indication, though they are no substitute for a professional assessment. The sooner hearing loss is identified, the sooner it can be managed — and the better the long-term results.`,
    keyPoints: [
      "Difficulty hearing in noisy environments is often the first sign of hearing loss",
      "Feeling that others are mumbling rather than speaking clearly is a hallmark symptom",
      "Turning up the TV volume higher than others find comfortable is a common indicator",
      "Social withdrawal, fatigue after conversations, and avoiding noisy situations are warning signs",
      "Family and friends often notice hearing changes before the person affected does",
      "Hearing loss is typically gradual — people may not realise how much they are missing",
      "Early detection leads to better outcomes — book a free hearing test via your GP or a high-street audiologist",
      "Untreated hearing loss is linked to social isolation, depression, and increased dementia risk",
    ],
    icon: "ear",
    relatedGuides: ["how-often-hearing-test", "preparing-for-hearing-test", "understanding-audiogram"],
  },

  // -------------------------------------------------------------------------
  // 7. Guide to NHS Hearing Services
  // -------------------------------------------------------------------------
  {
    slug: "nhs-hearing-services",
    title: "Guide to NHS Hearing Services",
    shortDescription:
      "Everything you need to know about accessing free hearing tests, hearing aids, and ongoing hearing care through the NHS in the UK.",
    fullDescription: `The National Health Service provides comprehensive hearing services across the United Kingdom, from newborn screening to adult hearing aid provision and specialist care for complex ear conditions. Understanding what is available and how to access it can help you get the support you need without unnecessary delay.

The NHS hearing pathway typically begins with your GP. If you have concerns about your hearing, your GP will examine your ears, check for wax or infection, and if appropriate, refer you to an NHS audiology department for a hearing assessment. In some areas, direct referral pathways allow you to self-refer to audiology services without seeing a GP first — check with your local NHS trust. Waiting times for routine audiology appointments vary by region, typically ranging from a few weeks to several months.

The NHS Newborn Hearing Screening Programme (NHSP) screens all babies within the first few weeks of life using otoacoustic emissions (OAE) testing and, if needed, auditory brainstem response (ABR) testing. This programme identifies around 1,000 babies with permanent hearing loss in England each year, enabling early intervention that is critical for speech and language development.

For adults, NHS audiology services include diagnostic hearing tests (pure tone audiometry, tympanometry, speech audiometry), hearing aid fitting and programming, ear wax removal (availability varies), tinnitus assessment and management, balance assessment, and referral to ENT specialists for medical or surgical conditions. NHS hearing aids — typically digital behind-the-ear (BTE) models — are provided free of charge, including batteries (or rechargeable options in some areas), repairs, and replacement when needed.

NHS hearing aids have improved dramatically in recent years and offer features such as directional microphones, noise reduction, feedback cancellation, and, increasingly, Bluetooth connectivity. While the range of styles is narrower than the private market (most NHS departments provide BTE aids rather than in-ear styles), the technology is effective and reliable. You are entitled to hearing aids for both ears if your audiologist recommends bilateral fitting.

If your hearing condition requires specialist input, your audiologist or GP can refer you to an ENT (ear, nose, and throat) consultant. ENT departments manage conditions including chronic ear infections, cholesteatoma, otosclerosis, acoustic neuroma, sudden hearing loss, and complex cases of tinnitus or balance disorders. Cochlear implant assessment is available through specialised NHS centres for people with severe to profound hearing loss who do not benefit sufficiently from hearing aids.

You have the right to choose which NHS provider you are referred to for routine audiology and ENT services. If waiting times are long at your local hospital, ask your GP about alternative providers. The NHS also commissions some hearing services from qualified community providers, including certain high-street hearing aid chains that offer NHS-funded hearing aids — ask your local Clinical Commissioning Group (ICB) for details.`,
    keyPoints: [
      "NHS hearing tests and hearing aids are completely free — including batteries, repairs, and replacements",
      "Start by seeing your GP, who can refer you to NHS audiology — some areas allow self-referral",
      "The NHS Newborn Hearing Screening Programme tests all babies within their first few weeks",
      "NHS hearing aids are digital BTE models with modern features like noise reduction and directional microphones",
      "You are entitled to hearing aids for both ears if bilateral fitting is recommended",
      "ENT referral is available for conditions requiring specialist medical or surgical treatment",
      "Waiting times vary — you can choose your NHS provider and ask about alternative options",
      "Some high-street audiologists offer NHS-funded hearing aids through local commissioning arrangements",
    ],
    icon: "heart-pulse",
    relatedGuides: ["choosing-hearing-aids", "how-often-hearing-test", "hearing-aids-tips"],
  },

  // -------------------------------------------------------------------------
  // 8. Living with Hearing Aids: Tips & Advice
  // -------------------------------------------------------------------------
  {
    slug: "hearing-aids-tips",
    title: "Living with Hearing Aids: Tips & Advice",
    shortDescription:
      "Practical advice for getting the most from your hearing aids — from the adjustment period to daily care, troubleshooting, and making the most of modern features.",
    fullDescription: `Getting hearing aids is a significant step towards better hearing and quality of life, but like any new technology, there is an adjustment period. Most people take two to four weeks to adapt to wearing hearing aids, and some may take longer. Understanding what to expect and how to get the best from your aids will help ensure a positive experience.

During the first few days, sounds may seem loud, sharp, or unfamiliar. Your own voice may sound strange, and background noise may seem overwhelming. This is completely normal — your brain has been adapting to reduced hearing and now needs time to recalibrate. Start by wearing your hearing aids in quiet environments at home, gradually increasing the amount of time you wear them each day and progressively introducing noisier situations. Most audiologists recommend wearing aids for at least eight hours a day during the adjustment period, building up gradually if needed. If specific sounds are persistently uncomfortable, note them down and discuss them at your follow-up appointment — your audiologist can adjust the programming.

Daily care and maintenance are important for keeping your hearing aids working reliably. Remove your aids before showering, bathing, or swimming (unless they are specifically waterproof). Clean them daily with a soft, dry cloth, and use the cleaning tools provided with your aids to clear any wax from the tubing or receiver. Store them in a dry, cool place overnight — a dehumidifier box or electronic drying unit is ideal, particularly in the UK climate. If you use disposable batteries, keep spares with you and change them as soon as sound quality drops. For rechargeable aids, establish a nightly charging routine.

To get the most from your hearing aids in conversation, position yourself so you can see the speaker's face, reduce background noise where possible (turn off the television, choose quieter venues, sit away from kitchen areas in restaurants), and let people know you wear hearing aids so they can face you when speaking. Many modern hearing aids have programme settings for different environments — learn how to switch between them, either using buttons on the aids or a smartphone app.

Take advantage of modern hearing aid features. Bluetooth connectivity allows you to stream phone calls, music, podcasts, and television audio directly to your ears. Telecoil (T-loop) settings pick up sound from induction loop systems installed in many UK cinemas, theatres, churches, banks, and public buildings — look for the loop symbol. Smartphone apps allow remote adjustments, battery monitoring, and even "find my hearing aid" features.

Attend all follow-up appointments with your audiologist, particularly in the first year. Your hearing needs may change over time, and regular adjustments ensure your aids continue to perform optimally. If you experience any problems — feedback (whistling), discomfort, ear infections, or declining sound quality — contact your audiologist rather than struggling on or stopping wearing your aids.`,
    keyPoints: [
      "Allow 2-4 weeks to adjust — start in quiet environments and gradually introduce noisier settings",
      "Wear hearing aids for at least 8 hours daily during the adjustment period for the best results",
      "Clean aids daily with a dry cloth and store in a dehumidifier box overnight",
      "Use Bluetooth streaming for phone calls, music, and TV — and the telecoil setting for loop systems",
      "Position yourself to see speakers' faces and reduce background noise where possible",
      "Attend all follow-up appointments — programming adjustments can make a significant difference",
      "Contact your audiologist promptly if you experience feedback, discomfort, or reduced sound quality",
      "Keep spare batteries with you, or charge rechargeable aids every night",
    ],
    icon: "settings",
    relatedGuides: ["choosing-hearing-aids", "nhs-hearing-services", "protecting-your-hearing"],
  },

  // -------------------------------------------------------------------------
  // 9. Children's Hearing Development Milestones
  // -------------------------------------------------------------------------
  {
    slug: "childrens-hearing-development",
    title: "Children's Hearing Development Milestones",
    shortDescription:
      "Understanding the key hearing and speech development milestones from birth to school age helps parents identify potential hearing concerns early.",
    fullDescription: `A child's hearing is fundamental to their speech, language, social, and emotional development. Identifying hearing problems early is critical — the first three years of life are particularly important for language acquisition, and even mild hearing loss can significantly affect a child's ability to learn to speak clearly and develop communication skills. Understanding what to expect at each stage of development can help parents and carers recognise when something may not be right.

In the UK, all newborns are offered hearing screening through the NHS Newborn Hearing Screening Programme (NHSP), ideally within the first few weeks of life. This test uses otoacoustic emissions (OAE) or auditory brainstem response (ABR) to check whether the inner ear is responding to sound. If the screening suggests a possible hearing concern, further diagnostic tests are arranged promptly.

During the first three months, babies should startle or blink in response to sudden loud sounds, seem to recognise their parent's voice, and quieten or smile when spoken to. By three to six months, babies typically begin to turn their eyes or head towards sounds, respond to their name, and enjoy toys and rattles that make noise. They begin to babble with vowel sounds ("ooh", "aah") and experiment with pitch and volume.

Between six and twelve months, babies start to babble with consonant sounds ("ba-ba", "da-da", "ma-ma"), turn to locate sounds coming from different directions, respond to simple words like "no" and "bye-bye", and enjoy music and songs. They begin to understand simple familiar words and can follow basic instructions accompanied by gestures.

From twelve to eighteen months, toddlers typically have a vocabulary of several single words, can point to familiar objects when named, follow simple spoken instructions ("give me the cup"), and enjoy being read to. They should respond consistently to their name from across a room and be increasingly interested in speech and communication. By eighteen to twenty-four months, vocabulary expands rapidly, with most children having around 50 words and beginning to combine two words ("more milk", "daddy gone").

Between two and three years, children should be speaking in short sentences, following two-part instructions, and be understood by familiar adults most of the time. By three to four years, they can hold simple conversations, ask questions, tell stories, and be understood by people outside the family.

If your child is not meeting these milestones, it does not necessarily mean they have a hearing problem — children develop at different rates, and other factors can affect speech and language development. However, it is always worth having their hearing checked. Speak to your health visitor or GP, who can arrange a hearing test. Common causes of hearing difficulty in children include glue ear (the most common cause of temporary hearing loss in childhood), ear infections, and, less commonly, permanent sensorineural hearing loss.`,
    keyPoints: [
      "All UK newborns are screened for hearing through the NHS Newborn Hearing Screening Programme",
      "By 3 months, babies should startle at loud sounds and recognise their parent's voice",
      "By 6-12 months, babies should babble, turn towards sounds, and respond to their name",
      "By 18-24 months, toddlers should have around 50 words and start combining two words",
      "By 3-4 years, children should hold conversations and be understood by people outside the family",
      "Glue ear is the most common cause of temporary hearing loss in children",
      "If milestones are not being met, see your health visitor or GP for a hearing check",
      "Early identification of hearing loss is critical for speech, language, and social development",
    ],
    icon: "baby",
    relatedGuides: ["hearing-loss-signs", "nhs-hearing-services", "how-often-hearing-test"],
  },

  // -------------------------------------------------------------------------
  // 10. Workplace Hearing Safety Guide
  // -------------------------------------------------------------------------
  {
    slug: "workplace-hearing-safety",
    title: "Workplace Hearing Safety Guide",
    shortDescription:
      "A practical guide to UK workplace hearing safety regulations, employer responsibilities, employee rights, and how to protect your hearing at work.",
    fullDescription: `Noise-induced hearing loss is one of the most common occupational health conditions in the United Kingdom, yet it is entirely preventable. The Health and Safety Executive (HSE) reports that approximately 17,000 people in the UK suffer from hearing difficulties caused or made worse by noise at work. Industries with the highest risk include construction, manufacturing, agriculture, mining, the armed forces, and the entertainment and hospitality sector. Understanding your rights and responsibilities under UK law is essential for protecting your hearing at work.

The key legislation governing workplace noise in the UK is the Control of Noise at Work Regulations 2005 (often referred to as the "Noise Regulations"). These regulations set out clear duties for employers. At the lower exposure action value (daily or weekly average of 80 dB, or peak sound pressure of 135 dB), employers must assess the risks from noise and provide information and training to employees about the risks and how to protect themselves. At the upper exposure action value (85 dB daily/weekly average, or peak of 137 dB), employers must reduce noise exposure so far as is reasonably practicable, provide hearing protection and ensure it is worn, designate hearing protection zones, and provide health surveillance (regular hearing tests). The exposure limit value (87 dB, accounting for hearing protection) must not be exceeded under any circumstances.

Employers must follow a hierarchy of controls. The first priority is to eliminate or reduce noise at source — for example, by using quieter equipment, modifying work processes, installing acoustic enclosures, or using vibration-damping materials. Engineering controls and changes to work organisation (such as rotating employees to reduce individual exposure time) come next. Hearing protection (ear plugs, ear defenders, or both) is the last resort when other measures are not sufficient.

As an employee, you have the right to be informed about noise risks in your workplace, to be provided with suitable hearing protection free of charge, to receive training on how to use and maintain hearing protection, and to have regular hearing tests (health surveillance) if you are exposed above 85 dB. You also have a responsibility to use the hearing protection provided, to report any defects in protective equipment, and to inform your employer if you notice any changes in your hearing.

If you believe your employer is not meeting their obligations, you can raise concerns with your workplace health and safety representative, contact the HSE directly for advice, or report concerns anonymously. If you believe you have suffered hearing damage as a result of workplace noise exposure, you may be entitled to make a claim for industrial hearing loss — seek legal advice from a specialist solicitor. NHS services are available to assess and manage any hearing loss.

Whether you are an employer or employee, practical steps to improve hearing safety include regular noise risk assessments, proper selection and fitting of hearing protection (ear plugs should be individually fitted and employees trained in their use), clear signage in noisy areas, maintenance of equipment to minimise unnecessary noise, and fostering a workplace culture where hearing protection is used consistently and without stigma.`,
    keyPoints: [
      "The Control of Noise at Work Regulations 2005 set clear noise limits: action at 80 dB, mandatory protection at 85 dB",
      "Employers must assess noise risks, reduce exposure, and provide free hearing protection",
      "Health surveillance (regular hearing tests) is required for workers exposed above 85 dB",
      "The hierarchy of controls prioritises noise reduction at source before relying on hearing protection",
      "Employees have the right to hearing protection, training, and hearing surveillance at no cost",
      "Industries at highest risk include construction, manufacturing, agriculture, and entertainment",
      "Report concerns to your health and safety representative or the HSE",
      "Hearing protection must be individually fitted — generic plugs often provide inadequate protection",
    ],
    icon: "hard-hat",
    relatedGuides: ["protecting-your-hearing", "hearing-loss-signs", "how-often-hearing-test"],
  },

  // -------------------------------------------------------------------------
  // 11. Hearing Aid Batteries
  // -------------------------------------------------------------------------
  {
    slug: "hearing-aid-batteries",
    title: "Hearing Aid Batteries: A Complete Guide",
    shortDescription:
      "Everything you need to know about hearing aid batteries — from zinc-air sizes and colour codes to rechargeable options, battery life, and tips for extending performance.",
    fullDescription: `Hearing aid batteries are essential to keeping your hearing aids working reliably, yet many people find the range of sizes, types, and options confusing. Understanding the basics will help you choose the right batteries, get the longest life from them, and know when rechargeable alternatives might be a better fit for your lifestyle.

Most hearing aids use zinc-air disposable batteries, which are activated by exposure to air. They come in four standard sizes, universally identified by colour-coded tabs: size 10 (yellow tab) — the smallest, used in completely-in-canal (CIC) and invisible-in-canal (IIC) aids, typically lasting 3 to 7 days; size 312 (brown tab) — used in many receiver-in-canal (RIC) and in-the-canal (ITC) aids, lasting approximately 3 to 10 days; size 13 (orange tab) — used in behind-the-ear (BTE) and some in-the-ear (ITE) aids, lasting around 6 to 14 days; and size 675 (blue tab) — the largest, used in powerful BTE aids and cochlear implant processors, lasting 9 to 20 days. Actual battery life varies depending on the power requirements of the hearing aid, how many hours per day the aids are worn, streaming usage, and environmental conditions.

When using zinc-air batteries, a key tip is to peel off the coloured tab and wait 60 seconds before inserting the battery into the hearing aid. This allows air to fully activate the zinc-air cell, which can extend overall battery life by up to 10%. Once the tab is removed, the battery begins to discharge whether it is in a hearing aid or not, so never peel the tab until you are ready to use the battery. Store unused batteries at room temperature in a dry place — avoid refrigerating them, as condensation can damage the battery. Keep batteries away from coins, keys, and other metal objects, which can short-circuit them.

In the UK, NHS hearing aid users receive batteries free of charge from their audiology department. Many departments offer a postal battery service, delivering replacements directly to your home. Private hearing aid users can purchase batteries from audiologists, pharmacies, and online retailers — buying in bulk is typically more economical. Expect to pay approximately 30 to 50 pence per battery when purchasing privately.

Rechargeable hearing aids have become increasingly popular and are now available from most major manufacturers, including Phonak, Oticon, Signia, Starkey, and ReSound. These use built-in lithium-ion batteries that are charged overnight in a docking station, providing a full day of use (typically 18 to 24 hours, depending on streaming). Rechargeable options eliminate the need to handle and change tiny batteries, making them particularly convenient for people with dexterity issues, reduced vision, or an active lifestyle. Some NHS audiology departments now offer rechargeable hearing aids, though availability varies by region. The charging case also serves as a protective storage unit, keeping the aids safe and dry overnight.

To maximise battery life, open the battery door at night when not wearing your aids (this stops the battery from draining and allows moisture to escape), reduce unnecessary Bluetooth streaming, and keep the hearing aid contacts clean. If battery life drops noticeably, have your aids checked by your audiologist — reduced battery life can indicate a fault or the need for reprogramming.`,
    keyPoints: [
      "Zinc-air batteries come in four sizes: 10 (yellow), 312 (brown), 13 (orange), 675 (blue)",
      "Wait 60 seconds after removing the tab before inserting — this can extend battery life by up to 10%",
      "NHS hearing aid users receive free batteries from their audiology department, often by post",
      "Battery life ranges from 3 to 20 days depending on size, hearing aid power, and streaming usage",
      "Rechargeable lithium-ion hearing aids charge overnight and last 18-24 hours per charge",
      "Store unused batteries at room temperature in a dry place — never refrigerate them",
      "Open the battery door at night to conserve power and let moisture escape",
      "Rechargeable aids are ideal for people with dexterity issues or those who find battery changes fiddly",
    ],
    icon: "battery",
    relatedGuides: ["choosing-hearing-aids", "hearing-aids-tips", "hearing-aid-maintenance"],
  },

  // -------------------------------------------------------------------------
  // 12. Hearing Aids and Flying
  // -------------------------------------------------------------------------
  {
    slug: "hearing-aids-and-flying",
    title: "Flying with Hearing Aids",
    shortDescription:
      "A practical guide to wearing hearing aids during air travel — covering airport security, cabin pressure, in-flight communication, and tips for a comfortable journey.",
    fullDescription: `Flying with hearing aids is straightforward and safe, but a little preparation can make the journey much more comfortable. Modern hearing aids are designed to be worn throughout a flight, and understanding how they interact with airport security, cabin pressure changes, and the noisy aircraft environment will help you travel with confidence.

Hearing aids are permitted through airport security and do not need to be removed when passing through metal detectors or body scanners. The UK Civil Aviation Authority (CAA) and the Department for Transport confirm that hearing aids are exempt from restrictions on electronic devices. Inform the security officer that you are wearing hearing aids if asked, as they may set off the metal detector — this is normal and will not cause any delay. If you wear cochlear implants, you should carry a medical ID card (provided by your implant centre) and inform security staff, as cochlear implant magnets can occasionally trigger additional screening. Hearing aids and cochlear implants are not damaged by airport X-ray machines (used for hand luggage) or walk-through metal detectors.

During the flight, you can wear your hearing aids throughout, including during take-off and landing. Unlike mobile phones and tablets, hearing aids are not required to be switched off or placed in "flight mode" at any point during the flight. If your hearing aids have Bluetooth connectivity, some airlines may ask you to disable Bluetooth during take-off and landing — check with your airline, though in practice this is rarely enforced for hearing aids. Most modern aircraft have hearing loop systems (telecoil/T-loop) installed in the cabin or at the check-in desk — switch to your telecoil programme to take advantage of these where available.

Cabin pressure changes during ascent and descent can cause discomfort for any passenger, but particularly for those with Eustachian tube dysfunction or recent ear infections. While hearing aids themselves are unaffected by pressure changes, your ears may feel blocked or painful during descent as cabin pressure increases. Use the same techniques recommended for all passengers: swallow frequently, yawn, chew gum, or perform the Valsalva manoeuvre (gently blow with your nose pinched and mouth closed). If you are prone to ear pressure problems, consider using a nasal decongestant spray 30 to 60 minutes before descent. Keep your hearing aids in during descent — they will not worsen the pressure effect and will help you hear announcements.

The aircraft cabin is a noisy environment, typically around 80-85 dB during cruising. Your hearing aids' noise reduction and directional microphone programmes can help manage this background noise. If your aids have a specific "travel" or "noise" programme, switch to it during the flight. For conversations with cabin crew or fellow passengers, face the speaker directly and ask them to speak clearly rather than shouting. If you have Bluetooth-enabled hearing aids, you can stream in-flight entertainment audio directly to your ears — bring the appropriate adapter or cable if your aircraft uses wired entertainment systems.

Pack spare batteries (or your charging case) in your hand luggage, not in the hold. Zinc-air hearing aid batteries are permitted in cabin baggage without restriction. Carry a small maintenance kit including a cleaning cloth, wax pick, and a dehumidifier sachet or pot — the dry cabin air can cause wax to harden in tubing or receivers. If you are travelling to a humid destination, a portable electronic dehumidifier is a worthwhile investment.

For passengers with significant hearing loss, airlines are required to provide assistance under the UK Equality Act 2010 and EU Regulation 1107/2006. This includes visual boarding announcements, written safety information, and assistance with check-in and boarding. Inform the airline of your hearing needs when booking, and request any assistance you may need.`,
    keyPoints: [
      "Hearing aids can be worn throughout the flight — they do not need to be removed or switched off",
      "Airport security: hearing aids are exempt and safe through metal detectors and X-ray machines",
      "Cabin pressure changes do not affect hearing aids — use swallowing, yawning, or Valsalva for ear comfort",
      "Use noise reduction or travel programmes on your hearing aids to manage cabin noise (80-85 dB)",
      "Pack spare batteries or charger in hand luggage — zinc-air batteries are permitted in cabin baggage",
      "Airlines must provide assistance for hearing-impaired passengers under the Equality Act 2010",
      "Carry cochlear implant medical ID if applicable and inform security staff",
      "Stream in-flight audio via Bluetooth if your aids support it — bring appropriate adapters",
    ],
    icon: "plane",
    relatedGuides: ["hearing-aids-tips", "choosing-hearing-aids", "hearing-aid-maintenance"],
  },

  // -------------------------------------------------------------------------
  // 13. Hearing Aid Maintenance
  // -------------------------------------------------------------------------
  {
    slug: "hearing-aid-maintenance",
    title: "Hearing Aid Maintenance and Care",
    shortDescription:
      "A practical guide to daily hearing aid care, cleaning, moisture protection, servicing, and troubleshooting common problems to keep your aids performing at their best.",
    fullDescription: `Hearing aids are sophisticated electronic devices that spend most of their working life in a challenging environment — the warm, moist, waxy ear canal. Regular maintenance and proper care are essential to ensure your hearing aids perform reliably, last as long as possible, and provide consistent sound quality. Most hearing aid problems are caused by wax blockage, moisture damage, or simple maintenance issues that can be prevented with a daily routine.

Daily cleaning is the single most important maintenance habit. At the end of each day, wipe your hearing aids with a soft, dry cloth to remove moisture, oils, and debris. Use the cleaning tools provided with your aids — typically a small brush and a wax pick or wire loop — to carefully remove any wax from the sound outlet (receiver or tubing opening), microphone ports, and ventilation holes. For behind-the-ear (BTE) aids, detach the earmould and tubing and clean these separately with warm soapy water, rinsing thoroughly and allowing them to dry completely before reattaching (never submerge the hearing aid body itself in water). For receiver-in-canal (RIC) aids, change the wax guard (wax filter) regularly — most manufacturers recommend changing it every one to three months, or sooner if sound quality drops.

Moisture is the number one enemy of hearing aids. The UK climate, combined with perspiration and ear canal moisture, means that hearing aids are constantly exposed to dampness. Invest in a dehumidifier — either a simple drying pot with desiccant capsules (replaced monthly) or an electronic drying unit that uses gentle heat and air circulation to remove moisture overnight. Place your hearing aids in the dehumidifier every night without fail. Electronic drying units (such as those by Dry & Store or Phonak) are particularly effective and can also help with UV sanitisation. Remove your hearing aids before showering, bathing, swimming, or applying hair products — hairspray and styling products can clog microphone ports and damage the casing.

Weekly maintenance should include a more thorough inspection of your hearing aids. Check the tubing on BTE aids for discolouration, hardening, or moisture droplets — tubing should be replaced every three to six months, which your audiology department or hearing aid provider can do, or you can learn to do it yourself. Inspect the earmould or dome for cracks, discolouration, or poor fit. Check that the battery contacts are clean and free from corrosion — wipe them gently with a dry cotton bud if needed.

Professional servicing should be arranged at least once a year, or more frequently if you notice any deterioration in sound quality or fit. NHS audiology departments provide free maintenance, repairs, retubing, and replacement of NHS hearing aids. Private hearing aid users should check what aftercare is included in their purchase — many providers include servicing for the first two to three years. Common problems that should prompt a professional check include whistling or feedback, intermittent sound, distorted or weak sound despite fresh batteries, discomfort or poor fit, and skin irritation in the ear canal.

When not wearing your hearing aids, store them in their case or dehumidifier with the battery door open (for disposable battery aids) to prevent drainage and allow air circulation. Keep them away from extreme heat, direct sunlight, and pets — dogs are particularly attracted to hearing aids, possibly due to the owner's scent, and hearing aid ingestion by dogs is surprisingly common.`,
    keyPoints: [
      "Clean hearing aids daily with a soft, dry cloth and the provided brush and wax pick",
      "Use a dehumidifier every night — moisture is the leading cause of hearing aid failure",
      "Remove aids before showering, swimming, or applying hair products",
      "Replace wax guards every 1-3 months and BTE tubing every 3-6 months",
      "NHS audiology departments provide free repairs, retubing, and replacement of NHS aids",
      "Store aids in their case with the battery door open when not in use",
      "Book professional servicing at least once a year for cleaning and performance checks",
      "Keep aids away from extreme heat, direct sunlight, and pets (especially dogs)",
    ],
    icon: "wrench",
    relatedGuides: ["hearing-aids-tips", "hearing-aid-batteries", "choosing-hearing-aids"],
  },

  // -------------------------------------------------------------------------
  // 14. Telecoils and Hearing Loops
  // -------------------------------------------------------------------------
  {
    slug: "telecoils-and-hearing-loops",
    title: "Telecoils and Hearing Loops: Your Complete Guide",
    shortDescription:
      "How telecoils (T-coils) and hearing loop systems work, where they are installed across the UK, and how to use them to hear more clearly in public spaces.",
    fullDescription: `Telecoils and hearing loop systems are one of the most valuable yet underused accessibility features available to hearing aid users in the United Kingdom. A hearing loop (also called an induction loop or audio frequency induction loop — AFIL) is a system that transmits sound directly to hearing aids and cochlear implants equipped with a telecoil (T-coil), cutting out background noise and delivering clear audio straight to the listener's ears.

A telecoil is a small copper coil built into most hearing aids and all cochlear implants. When activated (usually by switching to the "T" or "MT" programme on the hearing aid), the telecoil picks up the electromagnetic signal generated by a hearing loop system and converts it back into sound. This means the listener hears the sound source — whether it is a speaker at a counter, a performance on stage, or a public announcement — directly in their hearing aids, at their personally programmed volume and settings, without the distortion and interference of background noise.

Under the Equality Act 2010, service providers in the UK have a legal duty to make "reasonable adjustments" for disabled people, which includes providing hearing loop systems where appropriate. As a result, hearing loops are widely installed across the UK in venues and facilities including banks, post offices, pharmacies, GP surgeries and hospital reception desks, cinemas, theatres, and concert halls, churches and places of worship, railway stations and airports, council offices and public buildings, supermarket checkout tills, and taxis. Look for the hearing loop symbol — a stylised ear with a "T" — which indicates that a loop system is available.

There are several types of hearing loop system. A room loop (perimeter loop) consists of cable installed around the perimeter of a room, creating an electromagnetic field across the entire space — common in churches, theatres, and meeting rooms. A counter loop (desk loop) covers a small area, typically used at reception desks, pharmacies, and bank counters. A portable loop is a smaller, battery-powered unit that can be placed on a table for one-to-one conversations. An overspill-limited loop (phased array) uses a more complex cable layout to contain the signal within specific seating areas without interference from adjacent loops.

To use a hearing loop, switch your hearing aid to the "T" programme (telecoil) or "MT" programme (telecoil plus microphone, which allows you to hear both the loop signal and nearby conversation). If you are unsure how to switch programmes, ask your audiologist — they can ensure the telecoil is activated in your hearing aids and optimise its settings. Not all hearing aids have telecoils as standard, particularly smaller in-ear models, so check with your audiologist when choosing aids if loop access is important to you.

The British Standards Institution standard BS EN 60118-4 specifies the performance requirements for hearing loop systems in the UK. The International Electrotechnical Commission standard IEC 60118-4 is the equivalent international standard. Well-installed and properly maintained loop systems should deliver a clear, consistent signal that meets these standards. Unfortunately, not all installed loops are regularly tested or maintained. If you find that a hearing loop is not working, inform the venue — they have a responsibility under the Equality Act to maintain the system in working order.

Newer alternatives to traditional hearing loops include Bluetooth-based streaming from smartphones and Auracast (a broadcast audio feature in Bluetooth LE Audio) which is expected to offer an additional wireless connectivity option in the coming years. However, traditional hearing loops remain the most widely available and universally compatible assistive listening technology in the UK.`,
    keyPoints: [
      "Telecoils (T-coils) receive sound directly from hearing loop systems, cutting out background noise",
      "Most hearing aids and all cochlear implants have telecoils — switch to the 'T' or 'MT' programme to use them",
      "The Equality Act 2010 requires service providers to install hearing loops as a reasonable adjustment",
      "Hearing loops are found in cinemas, theatres, banks, GP surgeries, stations, churches, and taxis",
      "Look for the hearing loop symbol (ear with 'T') to identify venues with loop systems",
      "If a loop is not working, inform the venue — they must maintain it under the Equality Act",
      "Ask your audiologist to activate and optimise the telecoil when your hearing aids are fitted",
      "Smaller in-ear hearing aids may not include a telecoil — check before purchasing if loop access matters",
    ],
    icon: "radio",
    relatedGuides: ["choosing-hearing-aids", "hearing-aids-tips", "nhs-hearing-services"],
  },

  // -------------------------------------------------------------------------
  // 15. Hearing Tests for Babies
  // -------------------------------------------------------------------------
  {
    slug: "hearing-tests-for-babies",
    title: "Hearing Tests for Babies: What Parents Need to Know",
    shortDescription:
      "A guide to newborn hearing screening in the UK, including AABR and OAE tests, what the results mean, and what happens if your baby is referred for further assessment.",
    fullDescription: `In the United Kingdom, every baby is offered a hearing screening test shortly after birth through the NHS Newborn Hearing Screening Programme (NHSP). This programme, established in 2006, aims to identify babies with permanent hearing loss as early as possible, because early detection and intervention are critical for speech, language, and social development. Approximately 1 to 2 babies in every 1,000 are born with permanent hearing loss in one or both ears, making it one of the most common congenital conditions.

The newborn hearing screening test is usually carried out within the first few weeks of life, ideally before the baby is 5 weeks old. For babies born in hospital, the test is often done before discharge or at a follow-up appointment. For home births, a hearing screener will arrange a visit or appointment. The test is quick (typically 5 to 15 minutes per ear), painless, and can be done while the baby is sleeping or lying quietly.

Two types of test are used in the NHSP. The automated otoacoustic emissions (AOAE) test is usually done first. A small, soft-tipped earpiece is placed in the baby's ear, and gentle clicking sounds are played. A healthy cochlea (inner ear) responds by producing faint sounds called otoacoustic emissions, which are picked up by the earpiece. If the cochlea is working normally, a clear response is detected and the result is recorded as a "clear response" — meaning the baby has passed the screening for that ear. If a clear response is not obtained, it does not necessarily mean the baby has hearing loss — it can be caused by fluid in the ear, background noise, or the baby being unsettled.

If the AOAE test does not produce a clear response, the automated auditory brainstem response (AABR) test is performed. This test involves placing three small sensors on the baby's head and a set of soft headphones over or in the ears. Clicking sounds are played, and the sensors measure the electrical activity in the baby's auditory nerve and brainstem in response to the sounds. The AABR test assesses the entire hearing pathway from the ear to the brainstem and is more definitive than the AOAE test.

Screening results are reported as "clear response" (passed), "no clear response" (requires further testing), or occasionally "incomplete" (the test could not be completed and needs to be reattempted). A "no clear response" result does not confirm hearing loss — many babies who are referred for further testing are found to have normal hearing. However, it is important to attend all follow-up appointments promptly. Babies who do not pass the screening are referred to a paediatric audiology department for comprehensive diagnostic assessment, which may include diagnostic ABR testing under natural sleep, visual reinforcement audiometry (VRA) from around 7 months, and tympanometry.

If permanent hearing loss is confirmed, the UK follows the NICE guideline pathway, which recommends that hearing aids should be fitted by 3 months of age and that the child should be enrolled in a support programme by 6 months. The National Deaf Children's Society (NDCS) provides extensive support for families, and specialist Teachers of the Deaf work with families from the point of diagnosis. For profound hearing loss, cochlear implant assessment may be offered from around 12 months of age.

Parents should remain alert to their child's hearing development beyond the newborn screening. Some types of hearing loss develop after birth (progressive or late-onset) and will not be detected by the newborn screen. If at any stage you have concerns about your child's hearing or speech development, speak to your health visitor or GP — further hearing tests can be arranged at any age.`,
    keyPoints: [
      "All UK babies are offered free hearing screening through the NHS Newborn Hearing Screening Programme",
      "Screening is done within the first few weeks of life using AOAE and/or AABR tests",
      "The tests are quick (5-15 minutes per ear), painless, and can be done while the baby sleeps",
      "A 'no clear response' result does not confirm hearing loss — many referred babies have normal hearing",
      "Babies who do not pass screening are referred to paediatric audiology for diagnostic assessment",
      "NICE guidelines recommend hearing aid fitting by 3 months if permanent loss is confirmed",
      "The National Deaf Children's Society (NDCS) provides free support and information for families",
      "Some hearing loss develops after birth — continue to monitor your child's hearing development",
    ],
    icon: "baby",
    relatedGuides: ["childrens-hearing-development", "nhs-hearing-services", "how-often-hearing-test"],
  },

  // -------------------------------------------------------------------------
  // 16. Communication Tips for Hearing Loss
  // -------------------------------------------------------------------------
  {
    slug: "communication-tips-hearing-loss",
    title: "Communication Tips for Living with Hearing Loss",
    shortDescription:
      "Practical strategies for people with hearing loss and their families — including lip reading, clear speech, reducing background noise, and making conversations easier.",
    fullDescription: `Living with hearing loss affects not just the individual but everyone around them. Good communication is a two-way process, and simple adjustments by both the person with hearing loss and their conversation partners can dramatically improve understanding and reduce the frustration, fatigue, and social withdrawal that often accompany hearing difficulty. These strategies are recommended by the Royal National Institute for Deaf People (RNID) and NHS audiology services across the UK.

For people speaking with someone who has hearing loss, the most important step is to get their attention before you start talking. Say their name, tap them gently on the shoulder, or make a visual signal — starting to speak before they are ready means they will miss the beginning of the sentence, making the rest harder to follow. Face the person directly and ensure your face is well lit and not in shadow — even people who have not formally learned lip-reading rely heavily on visual cues from lip movements, facial expressions, and gestures. Never speak from another room, from behind the person, or while covering your mouth with your hand.

Speak clearly and at a natural pace — do not shout or exaggerate your lip movements, as this distorts the natural patterns that lip-readers rely on. Shouting also raises the pitch of your voice, which can make it harder to hear for people with high-frequency hearing loss (the most common type). Instead, speak slightly more slowly, pause between sentences, and rephrase rather than simply repeating the same words if you are not understood. If the listener did not catch a specific word, try saying it in a different way rather than repeating the same phrase more loudly.

Reducing background noise is one of the single most effective things you can do. Turn off the television or radio when having a conversation. In restaurants, choose quieter tables away from the kitchen, bar, and entrance. At family gatherings, try to have important conversations in quieter rooms. Background noise is the biggest challenge for hearing aid users — even the most advanced hearing aids cannot fully separate speech from competing noise.

For people with hearing loss, being open about your hearing difficulty is one of the most powerful strategies available. Let people know what helps — for example, "I hear better when I can see your face" or "please get my attention before you speak." Position yourself strategically in group conversations — sitting where you can see all speakers' faces, with your better ear towards the group, and with light falling on the speakers rather than behind them.

Make use of technology and assistive devices. Hearing aids with Bluetooth connectivity allow you to stream phone calls directly to your ears. Caption telephones and video relay services are available for phone calls. Captioned media (subtitles on television, live captioning in meetings) significantly improves comprehension. Hearing loop systems in public venues — cinemas, theatres, churches, banks — deliver clear sound directly to your hearing aids via the telecoil programme.

In workplace settings, the UK Equality Act 2010 requires employers to make reasonable adjustments for employees with hearing loss. This may include providing communication support workers, installing hearing loops in meeting rooms, offering captioning for virtual meetings, allowing flexible seating arrangements, and providing written minutes or summaries of meetings. Access to Work, a government scheme, can fund hearing-related workplace adjustments.

Lip-reading classes are available in many areas of the UK through adult education services, the Association of Teachers of Lip-reading (ATLA), and hearing loss charities. Learning lip-reading can dramatically improve communication confidence, particularly in challenging listening environments. The RNID also offers free online resources and practical communication tips for both hearing aid users and their families.`,
    keyPoints: [
      "Get the listener's attention before speaking — say their name or make a visual signal",
      "Face the person directly with good lighting on your face — lip-reading and visual cues are essential",
      "Speak clearly at a natural pace — do not shout, as this distorts speech and raises pitch unhelpfully",
      "Reduce background noise: turn off the TV, choose quiet venues, have important conversations in quiet rooms",
      "Rephrase rather than repeat — different words may be easier to catch than the same phrase repeated louder",
      "Use technology: Bluetooth streaming, captioned calls, subtitles, and hearing loop systems",
      "The Equality Act 2010 requires employers to make reasonable adjustments for employees with hearing loss",
      "Lip-reading classes are widely available through adult education, ATLA, and hearing loss charities",
    ],
    icon: "message-circle",
    relatedGuides: ["hearing-aids-tips", "hearing-loss-signs", "telecoils-and-hearing-loops"],
  },

  // -------------------------------------------------------------------------
  // 17. Hearing Aid Bluetooth and Apps
  // -------------------------------------------------------------------------
  {
    slug: "hearing-aid-bluetooth-apps",
    title: "Hearing Aid Bluetooth Connectivity and Apps",
    shortDescription:
      "How to connect hearing aids to your phone, stream audio, and use manufacturer apps from Oticon, Phonak, Signia, Starkey, and others for a better listening experience.",
    fullDescription: `Modern hearing aids are far more than simple sound amplifiers — they are sophisticated wireless devices that connect to smartphones, tablets, televisions, and other audio sources via Bluetooth. Understanding how Bluetooth hearing aids work and how to use the accompanying manufacturer apps can transform your listening experience, giving you direct audio streaming, remote control, and personalised sound adjustments at your fingertips.

Bluetooth connectivity in hearing aids allows you to stream phone calls, music, podcasts, audiobooks, video calls, and navigation instructions directly to your hearing aids, just like wireless earbuds. The sound is delivered at your personalised hearing aid settings, meaning it is automatically adjusted for your hearing loss — something conventional earphones cannot do. This is particularly beneficial for phone calls, which many people with hearing loss find challenging, as the caller's voice is delivered directly to both ears at optimised levels.

There are two main Bluetooth technologies used in hearing aids. Made for iPhone (MFi) technology allows hearing aids to connect directly to Apple devices (iPhone, iPad, iPod touch, and Mac) without an intermediary device. Most major manufacturers including Oticon, Phonak, Signia, Starkey, ReSound, and Widex offer MFi-compatible hearing aids. Android connectivity has improved significantly with the introduction of Audio Streaming for Hearing Aids (ASHA), which is supported by Android devices running version 10 or later. Some manufacturers, notably Phonak and Unitron, use classic Bluetooth, which allows direct connection to both iOS and Android devices as well as laptops and other Bluetooth-enabled sources without requiring specific protocol support.

Each major hearing aid manufacturer offers a free smartphone app that serves as a remote control and personalisation tool. The Oticon ON app (and the newer Oticon Companion app) allows volume adjustment, programme switching, and access to features like speech-in-noise enhancement and tinnitus sound support. The Phonak myPhonak app includes Remote Support (allowing your audiologist to adjust your hearing aids via a video call), speech focus adjustment, and noise reduction control. The Signia app features an AI assistant called Signia Assistant that learns from your preferences and adapts settings based on your feedback. The Starkey My Starkey app includes health tracking features such as step counting, brain health monitoring, and fall detection. The ReSound Smart 3D app offers environmental presets, sound personalisation, and tinnitus management. These apps are available free from the Apple App Store and Google Play Store.

For television streaming, most manufacturers offer a companion TV streaming device (such as Phonak TV Connector, Oticon TV Adapter, or Signia StreamLine TV) that connects to the television's audio output and transmits the sound directly to your hearing aids. This allows you to hear the television at your preferred volume and clarity without disturbing others in the room. These accessories typically cost between 100 and 250 pounds and are straightforward to set up.

For NHS hearing aid users, Bluetooth connectivity and app control depend on the specific hearing aid model provided by your local audiology department. Some NHS services now offer hearing aids with basic Bluetooth and app functionality, though the range is more limited than the private market. If Bluetooth connectivity is a priority, discuss this with your audiologist — they can advise on what is available locally.

Troubleshooting connectivity issues is common. If your hearing aids lose their Bluetooth connection, try turning Bluetooth off and on again on your phone, restarting the hearing aids (open and close the battery doors or place them in the charging case for 10 seconds), or removing and re-pairing the devices in your phone's Bluetooth settings. Keep your hearing aid app and phone operating system updated to the latest version for best compatibility.`,
    keyPoints: [
      "Bluetooth hearing aids stream phone calls, music, and media directly to your ears at your personalised settings",
      "Made for iPhone (MFi) and Android ASHA protocols enable direct smartphone-to-hearing-aid streaming",
      "Free manufacturer apps (Oticon, Phonak, Signia, Starkey, ReSound) offer remote control and personalisation",
      "TV streaming accessories transmit television audio directly to hearing aids without disturbing others",
      "Phonak myPhonak app offers Remote Support — audiologist adjustments via video call",
      "Signia's AI assistant learns from your feedback and adapts settings automatically",
      "Some NHS audiology departments now offer hearing aids with Bluetooth and app connectivity",
      "Troubleshoot connection issues by restarting aids, toggling Bluetooth, and keeping apps updated",
    ],
    icon: "bluetooth",
    relatedGuides: ["choosing-hearing-aids", "hearing-aids-tips", "hearing-aid-maintenance"],
  },

  // -------------------------------------------------------------------------
  // 18. Getting Used to New Hearing Aids
  // -------------------------------------------------------------------------
  {
    slug: "getting-used-to-new-hearing-aids",
    title: "Getting Used to New Hearing Aids: What to Expect",
    shortDescription:
      "A realistic guide to the adjustment period when you start wearing hearing aids — what to expect in the first weeks, common challenges, and when to go back to your audiologist.",
    fullDescription: `Starting to wear hearing aids is a significant moment, and it is completely normal for the experience to feel unfamiliar, overwhelming, or even disappointing at first. Understanding the adaptation process, setting realistic expectations, and knowing when to seek help from your audiologist are key to a successful long-term experience. Research shows that people who persist through the adjustment period and wear their aids consistently report significantly higher satisfaction and quality of life.

In the first few days, the most common reaction is that everything sounds different — and not always in the way you expected. Your own voice may sound too loud, hollow, or echoey (an effect known as occlusion). Environmental sounds that your brain has been filtering out for years — the hum of the refrigerator, the ticking of a clock, footsteps on hard floors, the rustling of clothes — may seem startlingly loud and intrusive. Traffic noise, crockery sounds, and running water may feel overwhelming. This is not because your hearing aids are set incorrectly — it is because your brain has been deprived of these sounds and has lost the ability to filter and prioritise them. The brain needs time to re-learn which sounds are important and which can be safely ignored.

During the first one to two weeks, aim to wear your hearing aids for gradually increasing periods each day. Many audiologists recommend starting with four to six hours daily and building up to full-time use (waking hours) over two to three weeks. Begin in quiet environments — at home, during one-to-one conversations, and while watching television. Read aloud or talk to family members to help your brain adjust to the sound of your own amplified voice. Practice listening to familiar sounds — the kettle boiling, birds singing, music you know well — to help your auditory memory recalibrate.

By the second to fourth week, most people notice a significant improvement. Background sounds begin to feel less intrusive as the brain re-learns to filter them. Speech clarity improves, particularly in quieter settings. You may notice that you are catching words and phrases that you had been missing before. This is the point where consistent use is most important — wearing your aids all day, every day, gives your brain the best chance to adapt fully. If you only wear them occasionally, the adaptation process is repeatedly reset and satisfaction remains low.

Common adjustment issues and when to contact your audiologist include persistent discomfort or soreness in the ear canal (the earmould or dome may need resizing), ongoing feedback or whistling (the fit may need adjusting or wax may be blocking the canal), your own voice still sounding unnatural after two weeks (your audiologist can adjust the occlusion management settings), specific sounds being uncomfortably loud (certain frequencies may need to be reduced), and difficulty hearing in noisy environments (noise reduction and directional microphone settings may need optimising). Do not try to fix these issues by adjusting the aids yourself beyond the controls you have been shown — changes to the core programming should be made by your audiologist.

A realistic timeline for full adaptation is typically four to twelve weeks, though some people adjust faster and others may take longer, particularly if hearing loss was left untreated for many years before aids were fitted. The longer the period of untreated hearing loss, the longer the brain typically takes to readjust to amplified sound. People who are fitted with hearing aids within the first few years of noticing hearing difficulty generally adapt more quickly and report higher satisfaction.

The British Society of Hearing Aid Audiologists (BSHAA) and the British Academy of Audiology (BAA) both recommend a structured rehabilitation programme alongside hearing aid fitting, which may include counselling about expectations, communication strategy training, and optional lip-reading referral. NHS audiology departments and private audiologists should offer at least one follow-up appointment within the first few weeks, with further reviews as needed. If you feel your aids are not helping or you are struggling to adapt, go back to your audiologist — do not give up. Adjustments to the programming, the physical fit, or the type of hearing aid can make a transformative difference.`,
    keyPoints: [
      "Adjustment to hearing aids typically takes 4 to 12 weeks — expect sounds to seem unusual at first",
      "Your own voice may sound strange (occlusion effect) — this improves as the brain adapts",
      "Start wearing aids for 4-6 hours daily in quiet settings, building up to full-time use over 2-3 weeks",
      "Background sounds will feel intrusive initially — the brain re-learns to filter them over time",
      "Wear aids consistently every day for the best results — occasional use delays adaptation",
      "Contact your audiologist if you experience persistent discomfort, whistling, or specific sound problems",
      "People fitted earlier after hearing loss onset adapt faster and report higher satisfaction",
      "Never give up without seeing your audiologist — programming and fit adjustments can be transformative",
    ],
    icon: "trending-up",
    relatedGuides: ["hearing-aids-tips", "choosing-hearing-aids", "hearing-aid-maintenance"],
  },
];

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

export function getAllConditionSlugs(): string[] {
  return hearingConditions.map((condition) => condition.slug);
}

export function getConditionBySlug(slug: string): HearingCondition | undefined {
  return hearingConditions.find((condition) => condition.slug === slug);
}

export function getAllGuideSlugs(): string[] {
  return hearingGuides.map((guide) => guide.slug);
}

export function getGuideBySlug(slug: string): HearingGuide | undefined {
  return hearingGuides.find((guide) => guide.slug === slug);
}
