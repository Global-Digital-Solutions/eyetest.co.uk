// ---------------------------------------------------------------------------
// UK hearing tests data — every type of hearing test offered by UK audiologists
// ---------------------------------------------------------------------------

export type HearingTest = {
  slug: string;
  name: string;
  shortDescription: string;
  fullDescription: string;
  duration: string;
  cost: string;
  whoNeeds: string[];
  whatToExpect: string[];
  frequency: string;
  icon: string;
  relatedTests: string[];
  nhsCovered: boolean;
};

// ---------------------------------------------------------------------------
// Comprehensive UK hearing test types
// ---------------------------------------------------------------------------

export const hearingTests: HearingTest[] = [
  // ─── Standard Hearing Test ──────────────────────────────────────────
  {
    slug: "standard-hearing-test",
    name: "Standard Hearing Test",
    shortDescription:
      "A comprehensive pure tone audiometry test to assess your hearing ability across a range of frequencies and volumes.",
    fullDescription: `A standard hearing test — known clinically as pure tone audiometry — is the cornerstone of hearing health care in the UK. During this assessment, a qualified audiologist will measure your ability to hear sounds at different pitches (frequencies) and loudness levels (decibels). The results are plotted on an audiogram, which provides a clear visual picture of your hearing thresholds in each ear. This test can detect the type, degree, and configuration of any hearing loss, whether it is mild, moderate, severe, or profound.

The British Society of Audiology recommends that adults have their hearing checked regularly, particularly from the age of 55 onwards when age-related hearing loss (presbycusis) becomes increasingly common. Research from the RNID (Royal National Institute for Deaf People) estimates that around 12 million adults in the UK have some degree of hearing loss, yet many wait an average of ten years before seeking help. Early detection through routine testing can make a significant difference — the sooner hearing loss is identified, the more effectively it can be managed, whether through hearing aids, assistive listening devices, or other interventions.

In the UK, a standard hearing test is available free of charge through the NHS following a referral from your GP. Private hearing tests are also widely available on the high street and typically cost between £30 and £60, often with no referral needed. Many private audiologists and hearing aid dispensers offer free initial hearing assessments as part of their service, particularly if you are considering hearing aids. Whether you go through the NHS or privately, a standard hearing test is painless, non-invasive, and one of the most important health checks you can have — hearing connects you to the people and world around you, and looking after it starts with a simple appointment.`,
    duration: "30–45 minutes",
    cost: "Free on the NHS with GP referral; £30–£60 privately",
    whoNeeds: [
      "All adults as part of routine health care, especially from age 55 onwards",
      "Anyone noticing difficulty hearing conversations or asking people to repeat themselves",
      "People who frequently turn up the TV or radio volume",
      "Those experiencing muffled hearing or a sensation of blocked ears",
      "Workers exposed to loud noise in their occupation",
      "Anyone with a family history of hearing loss",
      "People who have not had a hearing test in over three years",
    ],
    whatToExpect: [
      "Your audiologist will ask about your general health, medications, noise exposure history, and any hearing concerns",
      "An otoscopic examination of your ear canals and eardrums to check for wax, infection, or abnormalities",
      "You will wear headphones in a soundproofed booth or quiet room and respond to a series of tones at different pitches and volumes",
      "Bone conduction testing may be included, using a small vibrating device placed behind your ear",
      "Speech recognition testing may assess how well you understand words at different volumes",
      "Your audiologist will explain your audiogram results and what they mean for your day-to-day hearing",
      "Recommendations for next steps — which may include monitoring, hearing aids, or onward referral — are discussed at the end",
    ],
    frequency: "Every 3 years from age 55; sooner if you notice changes or have risk factors",
    icon: "ear",
    relatedTests: [
      "nhs-hearing-test",
      "speech-in-noise-test",
      "bone-conduction-test",
    ],
    nhsCovered: true,
  },

  // ─── NHS Hearing Test ───────────────────────────────────────────────
  {
    slug: "nhs-hearing-test",
    name: "NHS Hearing Test",
    shortDescription:
      "A free hearing assessment available to everyone in the UK through the NHS, usually accessed via a GP referral to audiology services.",
    fullDescription: `The NHS provides free hearing tests to everyone in the UK, regardless of age. The pathway typically begins with a visit to your GP, who will examine your ears, rule out straightforward causes such as ear wax or infection, and refer you to the local NHS audiology department if a hearing assessment is needed. In some parts of England, direct referral pathways now allow you to book an audiology appointment without seeing your GP first — check with your local NHS trust for availability.

NHS audiology departments are staffed by fully qualified audiologists and hearing aid dispensers registered with the Health and Care Professions Council (HCPC). Your assessment will be thorough and clinically rigorous, typically including pure tone audiometry, speech testing, and otoscopy. If hearing loss is detected, the NHS provides hearing aids completely free of charge, along with ongoing batteries, repairs, and aftercare. The most commonly fitted NHS hearing aids are modern behind-the-ear (BTE) digital devices, and while the range of styles is more limited than the private market, they are clinically effective and well-maintained. In Scotland, Wales, and Northern Ireland, similar NHS audiology services are available through the devolved health services.

The main consideration with NHS hearing tests is waiting times. Depending on your area, the wait between GP referral and audiology appointment can range from a few weeks to several months. If speed is a priority, a private hearing test may be quicker to arrange, but the NHS route is an excellent option for comprehensive, no-cost hearing care. There is no age limit and no restriction on how often you can be referred — if you are concerned about your hearing, your GP is always the first port of call. The NHS hearing pathway is one of the most valuable free health services available in the UK, and taking advantage of it can transform your quality of life.`,
    duration: "45–60 minutes (including consultation)",
    cost: "Free — fully funded by the NHS",
    whoNeeds: [
      "Anyone concerned about their hearing who wants a no-cost assessment",
      "People who think they may benefit from hearing aids but cannot afford private options",
      "Adults over 55 who have never had their hearing checked",
      "Children or young people with suspected hearing difficulties",
      "Those with sudden or rapidly worsening hearing loss (urgent GP referral recommended)",
      "People already wearing NHS hearing aids who need a reassessment",
      "Anyone experiencing persistent tinnitus alongside hearing concerns",
    ],
    whatToExpect: [
      "Visit your GP, who will examine your ears and make a referral to NHS audiology if appropriate",
      "You will receive a letter or call with your audiology appointment details — waiting times vary by area",
      "At the appointment, an audiologist will take a full history and examine your ears with an otoscope",
      "Pure tone audiometry testing is performed in a soundproofed room using headphones",
      "If hearing loss is found, the audiologist will discuss options including NHS hearing aids",
      "Hearing aids, if needed, are fitted at a follow-up appointment at no cost",
      "Ongoing aftercare, batteries, and repairs are provided free by the NHS",
    ],
    frequency: "As needed — see your GP whenever you have concerns about your hearing",
    icon: "shield",
    relatedTests: [
      "standard-hearing-test",
      "hearing-aid-fitting",
      "hearing-aid-aftercare",
    ],
    nhsCovered: true,
  },

  // ─── Online Hearing Test ────────────────────────────────────────────
  {
    slug: "online-hearing-test",
    name: "Online Hearing Test",
    shortDescription:
      "A quick digital screening tool you can take from home to get an initial indication of your hearing ability — not a replacement for a clinical assessment.",
    fullDescription: `Online hearing tests have become increasingly popular as a convenient first step for anyone wondering whether their hearing has changed. These digital screening tools are offered by many reputable organisations, including the RNID, major hearing aid manufacturers, and high-street audiology providers. They typically take just a few minutes and can be completed on a computer, tablet, or smartphone using headphones. The tests usually involve listening to speech in background noise or identifying tones at various frequencies, and they provide an immediate indication of whether your hearing falls within the normal range or whether further investigation is advised.

It is important to understand the limitations of online hearing tests. They are screening tools, not diagnostic assessments. The accuracy depends heavily on factors such as the quality of your headphones, background noise in your environment, the volume settings on your device, and whether the test has been clinically validated. An online test cannot measure the full range of frequencies and decibel levels that a clinical audiogram covers, nor can it examine your ears for physical causes of hearing loss such as wax, infection, or eardrum perforation. For these reasons, no online hearing test should be used as a substitute for a proper assessment by a qualified audiologist.

That said, online hearing tests serve a genuinely valuable purpose as an accessible, low-barrier entry point into hearing care. Research suggests that many people delay seeking help for hearing loss for up to a decade, and an online screening that flags a potential issue can be the motivating nudge that leads to a professional appointment. If your online test suggests any degree of hearing difficulty, the recommended next step is to book a full hearing test — either through your GP for an NHS referral or directly with a private audiologist. Think of an online hearing test as a helpful signpost, not a destination.`,
    duration: "3–10 minutes",
    cost: "Free — most online hearing tests are offered at no charge",
    whoNeeds: [
      "Anyone curious about their hearing who wants a quick initial check",
      "People who are unsure whether their hearing has changed enough to warrant a clinical test",
      "Those who find it difficult to attend an in-person appointment due to mobility or schedule constraints",
      "Family members or partners of someone who may have unrecognised hearing loss",
      "Workers in noisy environments who want a regular informal screen between occupational tests",
      "Anyone looking for reassurance or motivation to book a full clinical hearing test",
    ],
    whatToExpect: [
      "Choose a reputable online hearing test from an established provider such as the RNID or a registered audiologist",
      "Find a quiet room and use good-quality headphones — not your phone speaker",
      "Follow on-screen instructions, which typically involve listening to speech in noise or identifying tones",
      "Answer questions about your listening situations and any difficulties you experience",
      "Receive an instant result indicating whether your hearing appears normal, borderline, or below normal",
      "If the result suggests hearing difficulty, you will be advised to book a full clinical hearing test",
    ],
    frequency: "Any time you have concerns — but always follow up with a clinical test if results suggest hearing loss",
    icon: "monitor",
    relatedTests: [
      "standard-hearing-test",
      "speech-in-noise-test",
      "nhs-hearing-test",
    ],
    nhsCovered: false,
  },

  // ─── Children's Hearing Test ────────────────────────────────────────
  {
    slug: "childrens-hearing-test",
    name: "Children's Hearing Test",
    shortDescription:
      "Specialised hearing assessments for babies, toddlers, and school-age children, including the NHS Newborn Hearing Screening Programme and school-entry screening.",
    fullDescription: `Hearing is fundamental to a child's speech, language, and social development, which is why the UK has a comprehensive programme of hearing checks from birth through to school age. The NHS Newborn Hearing Screening Programme (NHSP) offers a hearing screen to all babies within the first few weeks of life, usually before they leave hospital or during a home visit from a health visitor. This test, known as the Automated Otoacoustic Emissions (AOAE) test, is quick, painless, and highly effective at identifying hearing loss early — before it can delay development.

Beyond the newborn screen, children's hearing continues to be monitored at key developmental stages. The health visitor distraction test (typically around 8–9 months) checks a baby's response to sounds, while school-entry hearing screening — usually conducted by the school nursing team in Reception (age 4–5) — uses a simplified version of pure tone audiometry known as a sweep test. If a child does not pass any of these screens, they are referred to paediatric audiology for a full diagnostic assessment. Paediatric audiologists use age-appropriate techniques including visual reinforcement audiometry (VRA) for infants, play audiometry for toddlers, and standard pure tone audiometry for older children. Tympanometry and otoacoustic emissions testing may also be used to assess middle ear and cochlear function.

If you are concerned about your child's hearing at any age, you do not need to wait for a routine screen. Your GP, health visitor, or school nurse can arrange a referral to paediatric audiology at any time. Signs to watch for include delayed speech or language development, not responding when called, asking for things to be repeated, turning up the television volume, and difficulty concentrating at school. Early identification and intervention — whether through hearing aids, grommets, cochlear implants, or speech and language therapy — can make a profound difference to a child's outcomes. All NHS children's hearing services are free.`,
    duration: "20–45 minutes depending on the child's age and the tests required",
    cost: "Free — all children's hearing tests are fully funded by the NHS",
    whoNeeds: [
      "All newborn babies as part of the NHS Newborn Hearing Screening Programme",
      "Infants and toddlers showing delayed speech or language development",
      "Children who do not seem to respond to sounds or voices",
      "School-age children struggling to concentrate or follow instructions in class",
      "Children with recurrent ear infections or glue ear (otitis media with effusion)",
      "Any child with a family history of childhood hearing loss",
      "Children who have had meningitis or other illnesses associated with hearing damage",
      "Babies born prematurely or with conditions that increase hearing loss risk",
    ],
    whatToExpect: [
      "Newborn screening: a small soft-tipped earpiece is placed in the baby's ear to measure otoacoustic emissions — the test takes just a few minutes",
      "For infants: visual reinforcement audiometry uses animated toys and sounds to observe the baby's response to different frequencies",
      "For toddlers and young children: play audiometry turns the hearing test into a game — the child places a peg or toy in response to sounds",
      "For older children: standard pure tone audiometry is performed using headphones, similar to an adult hearing test",
      "Tympanometry may be used to check how well the eardrum and middle ear are working",
      "The audiologist will explain all results to parents or carers and discuss any next steps",
    ],
    frequency: "Newborn screening at birth; school-entry screening at age 4–5; otherwise as concerns arise",
    icon: "baby",
    relatedTests: [
      "newborn-hearing-screening",
      "tympanometry",
      "otoacoustic-emissions",
    ],
    nhsCovered: true,
  },

  // ─── Tinnitus Assessment ────────────────────────────────────────────
  {
    slug: "tinnitus-assessment",
    name: "Tinnitus Assessment",
    shortDescription:
      "A specialist evaluation for persistent ringing, buzzing, or other sounds in the ears, including hearing tests, questionnaires, and management options.",
    fullDescription: `Tinnitus — the perception of sound in the ears or head without an external source — affects an estimated 7.1 million people in the UK, according to the British Tinnitus Association. The experience varies widely: some people hear ringing, others a buzzing, hissing, humming, or pulsing sound, and it can range from mildly annoying to severely debilitating. A tinnitus assessment is a thorough, specialist-led evaluation designed to understand the nature of your tinnitus, identify any underlying causes, measure its impact on your daily life, and develop a personalised management plan.

A tinnitus assessment typically begins with a detailed case history, covering the onset, character, and pattern of your tinnitus, along with your general health, noise exposure, stress levels, and any medications that might contribute. A full hearing test (pure tone audiometry) is almost always included, as tinnitus is frequently associated with hearing loss — though it can occur in people with entirely normal hearing. Additional tests may include tinnitus pitch and loudness matching, which helps characterise the sound you are hearing, and minimum masking level testing, which determines the lowest level of external sound that can cover your tinnitus. Validated questionnaires such as the Tinnitus Handicap Inventory (THI) or Tinnitus Functional Index (TFI) are used to objectively measure the impact on your quality of life.

Tinnitus assessments are available free through the NHS, usually via referral from your GP to an audiology or ENT (ear, nose, and throat) department. Private tinnitus clinics also offer specialist assessments, typically costing between £100 and £250. Management options may include sound therapy, cognitive behavioural therapy (CBT) for tinnitus, hearing aids (which can reduce tinnitus perception by amplifying ambient sound), tinnitus retraining therapy (TRT), and counselling. While there is currently no cure for most forms of tinnitus, effective management can significantly reduce its impact. If your tinnitus is pulsatile (in time with your heartbeat) or one-sided, prompt medical assessment is particularly important, as these types may indicate an underlying condition requiring treatment.`,
    duration: "45–90 minutes",
    cost: "Free on the NHS with GP referral; £100–£250 privately",
    whoNeeds: [
      "Anyone experiencing persistent ringing, buzzing, hissing, or humming sounds in their ears",
      "People whose tinnitus is affecting their sleep, concentration, or mental health",
      "Those with tinnitus alongside noticeable hearing loss",
      "Workers who have been exposed to loud noise and are now experiencing tinnitus",
      "Anyone with sudden-onset or pulsatile tinnitus (seek prompt medical advice)",
      "People who have tried to manage tinnitus alone and need professional support",
      "Musicians, DJs, or live event workers with noise-induced tinnitus",
    ],
    whatToExpect: [
      "A detailed discussion about the onset, character, and pattern of your tinnitus, along with your medical and noise exposure history",
      "An otoscopic examination of your ears to rule out physical causes such as wax or infection",
      "A full pure tone audiometry hearing test to assess your hearing thresholds",
      "Tinnitus pitch and loudness matching to characterise the sound you perceive",
      "Validated questionnaires to measure the impact of tinnitus on your daily life and wellbeing",
      "Discussion of management options including sound therapy, CBT, hearing aids, and tinnitus retraining therapy",
      "A personalised management plan and, if needed, onward referral to ENT or psychological support",
    ],
    frequency: "As needed — seek assessment when tinnitus is first noticed or if it worsens",
    icon: "waves",
    relatedTests: [
      "standard-hearing-test",
      "speech-in-noise-test",
      "hearing-aid-fitting",
      "musicians-hearing-test",
    ],
    nhsCovered: true,
  },

  // ─── Balance Assessment ─────────────────────────────────────────────
  {
    slug: "balance-assessment",
    name: "Balance Assessment",
    shortDescription:
      "A specialist vestibular assessment to investigate dizziness, vertigo, and balance disorders using a series of clinical and electronystagmography tests.",
    fullDescription: `The vestibular system — located in the inner ear — plays a central role in balance, spatial orientation, and coordination. When it malfunctions, the results can be profoundly disruptive: dizziness, vertigo (a spinning sensation), unsteadiness, nausea, and an increased risk of falls. Balance disorders are surprisingly common in the UK, with Meniere's Society estimates suggesting that around one in four adults will experience significant dizziness at some point in their lives. A balance assessment is a specialist evaluation carried out by an audiologist or audiovestibular physician to identify the cause and severity of vestibular dysfunction.

A comprehensive balance assessment typically includes a detailed case history, examination of eye movements, positional testing (such as the Dix-Hallpike manoeuvre for benign paroxysmal positional vertigo, or BPPV), and electronystagmography (ENG) or videonystagmography (VNG), which records eye movements in response to visual and thermal stimulation. Caloric testing — where warm and cool water or air is gently introduced into the ear canal — is one of the most informative vestibular tests, as it stimulates each inner ear independently and can reveal asymmetries in vestibular function. Some clinics also offer rotary chair testing, vestibular evoked myogenic potentials (VEMPs), and computerised dynamic posturography (CDP), which measures how well you maintain balance under different conditions.

Balance assessments are available on the NHS, usually through referral from your GP or an ENT consultant to an audiovestibular clinic. Waiting times can vary, and private balance assessments are available from specialist vestibular clinics, typically costing between £150 and £350. Once the cause is identified, treatment options range from simple repositioning manoeuvres for BPPV (often curative in a single session) to vestibular rehabilitation therapy (VRT), medication, or, in rare cases, surgical intervention. If you are experiencing recurrent dizziness or vertigo, a balance assessment is an essential step towards diagnosis and effective management — and towards reducing the risk of falls, which is particularly important for older adults.`,
    duration: "60–90 minutes",
    cost: "Free on the NHS with referral; £150–£350 privately",
    whoNeeds: [
      "Anyone experiencing recurrent dizziness, vertigo, or a spinning sensation",
      "People who feel unsteady on their feet or have had unexplained falls",
      "Those with Meniere's disease or suspected vestibular disorder",
      "People with dizziness accompanied by hearing loss or tinnitus",
      "Older adults at increased risk of falls due to balance problems",
      "Anyone whose dizziness is affecting their ability to work, drive, or carry out daily activities",
      "People with persistent motion sickness or visual vertigo",
    ],
    whatToExpect: [
      "A detailed history of your dizziness, including triggers, duration, and associated symptoms such as nausea or hearing changes",
      "Examination of your eye movements, including tracking tests and observation for nystagmus (involuntary eye movements)",
      "Positional testing such as the Dix-Hallpike manoeuvre to check for BPPV",
      "Caloric testing, where warm and cool air or water is introduced into the ear canal to stimulate the vestibular system",
      "You may wear special goggles (Frenzel or infrared) to allow the audiologist to observe your eye movements in detail",
      "Additional tests such as VNG, VEMPs, or posturography may be included depending on your symptoms",
      "The audiologist or vestibular physician will explain the findings and recommend treatment, which may include repositioning manoeuvres, vestibular rehabilitation, or onward referral",
    ],
    frequency: "As needed — seek assessment when dizziness or balance problems persist or recur",
    icon: "compass",
    relatedTests: [
      "standard-hearing-test",
      "tympanometry",
      "auditory-brainstem-response",
    ],
    nhsCovered: true,
  },

  // ─── Ear Wax Removal ───────────────────────────────────────────────
  {
    slug: "ear-wax-removal",
    name: "Ear Wax Removal",
    shortDescription:
      "Professional removal of excess or impacted ear wax using safe, modern methods including microsuction, irrigation, and manual instrument removal.",
    fullDescription: `Ear wax (cerumen) is a natural substance produced by glands in the ear canal to protect, lubricate, and clean the ears. For most people, ear wax migrates out of the ear naturally and causes no problems. However, for some individuals, wax can build up, become impacted, and cause symptoms including hearing loss, earache, a sensation of fullness, tinnitus, dizziness, and even coughing. When this happens, professional ear wax removal is the safest and most effective solution. It is important to note that cotton buds should never be inserted into the ear canal — they push wax deeper and can damage the delicate eardrum.

The gold standard for ear wax removal in the UK is microsuction, a technique where a qualified practitioner uses a fine suction device and a microscope or loupe to gently remove wax under direct vision. Microsuction is widely regarded as the safest method because the clinician can see exactly what they are doing throughout the procedure. It is quick, usually painless, and does not require pre-treatment with olive oil drops (though softening the wax beforehand can make the procedure easier). Ear irrigation (formerly known as syringing) is another common method, using a controlled flow of warm water to flush out wax; this method is effective but is not suitable for everyone, particularly those with a perforated eardrum, grommets, or a history of ear surgery. Manual instrument removal using curettes or forceps is a third option, typically used for smaller amounts of wax.

NHS ear wax removal services have become increasingly limited in recent years. While some GP practices still offer irrigation, many have stopped providing this service, and NHS microsuction is typically only available through audiology or ENT departments with a referral. As a result, private ear wax removal has become the most accessible option for many people in the UK, with prices typically ranging from £40 to £90 for one or both ears. Private clinics are widely available on the high street and often offer same-day or next-day appointments. Whether you choose NHS or private care, professional wax removal is a quick and effective procedure that can produce an immediate and often dramatic improvement in hearing.`,
    duration: "15–30 minutes",
    cost: "Limited NHS availability (free where offered); £40–£90 privately for one or both ears",
    whoNeeds: [
      "Anyone experiencing blocked ears, muffled hearing, or a sensation of fullness in the ear",
      "People with impacted ear wax confirmed by a GP, pharmacist, or audiologist",
      "Those who need clear ear canals before a hearing test or hearing aid fitting",
      "Hearing aid users who are prone to wax build-up around their devices",
      "People who produce excessive ear wax naturally",
      "Anyone who has used cotton buds and suspects they have pushed wax deeper",
      "Those experiencing earache, tinnitus, or dizziness potentially related to wax",
    ],
    whatToExpect: [
      "The clinician will examine your ear canals with an otoscope to confirm the presence and location of wax",
      "For microsuction: a fine suction device is used under magnification to gently remove wax — you will hear a suction noise but the procedure is usually painless",
      "For irrigation: warm water is gently flushed into the ear canal using a controlled electronic irrigator (not the old-style metal syringe)",
      "For manual removal: small instruments such as curettes are used to carefully lift out the wax",
      "The clinician will check your ears again after removal to ensure the canal is clear",
      "You may be advised to use olive oil drops regularly to help prevent future build-up",
      "The procedure is usually quick, and many people notice an immediate improvement in their hearing",
    ],
    frequency: "As needed — some people require removal every 6–12 months; others rarely need it",
    icon: "droplet",
    relatedTests: [
      "standard-hearing-test",
      "hearing-aid-fitting",
      "tympanometry",
    ],
    nhsCovered: false,
  },

  // ─── Hearing Aid Fitting ────────────────────────────────────────────
  {
    slug: "hearing-aid-fitting",
    name: "Hearing Aid Fitting",
    shortDescription:
      "A professional appointment to select, fit, and programme hearing aids tailored to your specific hearing loss, lifestyle, and preferences.",
    fullDescription: `A hearing aid fitting is the appointment where your audiologist selects the most appropriate hearing aid for your hearing loss, takes any necessary ear impressions, programmes the device to match your audiogram, and ensures it fits comfortably and functions correctly. This is a pivotal moment in the hearing care journey — a well-fitted hearing aid can transform your ability to communicate, socialise, and engage with the world. In the UK, hearing aids are available free through the NHS and privately from registered hearing aid dispensers and audiologists.

During the fitting, your audiologist will consider your audiogram results, the type and degree of your hearing loss, your lifestyle and listening needs, your dexterity and manual ability, and your cosmetic preferences. Modern hearing aids come in a range of styles — behind-the-ear (BTE), receiver-in-canal (RIC), in-the-ear (ITE), and completely-in-canal (CIC) — and feature digital processing, directional microphones, noise reduction, Bluetooth connectivity, and rechargeable batteries. NHS hearing aids are typically BTE or RIC models and, while the range is more limited than private options, they are modern, effective digital devices. Private hearing aids offer a wider choice of styles, features, and brands, with prices typically ranging from £500 to £3,500 per ear depending on the technology level.

The fitting itself involves placing the hearing aid in your ear, connecting it to the audiologist's software, and programming it to your prescription using real-ear measurement (REM) wherever possible. REM involves placing a thin probe microphone in your ear canal alongside the hearing aid to verify that the amplification matches your hearing loss targets — this is considered best practice by the British Society of Audiology and significantly improves outcomes. Your audiologist will then walk you through how to insert and remove the device, change programmes, adjust volume, clean and maintain it, and change or charge the battery. You will usually be given a short trial period to adjust, with follow-up appointments to fine-tune the settings based on your real-world experience.`,
    duration: "45–90 minutes",
    cost: "Free on the NHS; £500–£3,500 per ear privately depending on technology level",
    whoNeeds: [
      "Anyone diagnosed with hearing loss who would benefit from amplification",
      "People whose hearing loss is affecting their communication, work, or social life",
      "Those who have been fitted with hearing aids before and need updated devices",
      "NHS patients referred to audiology following a hearing test",
      "People who want to explore private hearing aid options and technology",
      "Workers who need hearing support in occupational settings",
      "Anyone with hearing loss and associated tinnitus (hearing aids can help manage both)",
    ],
    whatToExpect: [
      "Your audiologist will discuss your audiogram results, lifestyle, and hearing needs to recommend the most suitable hearing aid",
      "Ear impressions may be taken if a custom-moulded eartip or shell is required",
      "The hearing aid is physically fitted in your ear and checked for comfort",
      "The device is connected to programming software and adjusted to match your hearing prescription",
      "Real-ear measurement (REM) is used to verify the hearing aid is delivering the correct amplification",
      "You will be shown how to insert, remove, clean, and maintain the hearing aid, and how to change or charge the battery",
      "Follow-up appointments are scheduled to fine-tune settings based on your experience in everyday listening situations",
    ],
    frequency: "Initial fitting, then review every 1–2 years; NHS hearing aids are typically replaced every 5 years",
    icon: "headphones",
    relatedTests: [
      "standard-hearing-test",
      "hearing-aid-aftercare",
      "ear-wax-removal",
      "speech-in-noise-test",
    ],
    nhsCovered: true,
  },

  // ─── Hearing Aid Aftercare ──────────────────────────────────────────
  {
    slug: "hearing-aid-aftercare",
    name: "Hearing Aid Aftercare",
    shortDescription:
      "Ongoing support, maintenance, adjustment, and repair services to keep your hearing aids working at their best.",
    fullDescription: `Hearing aid aftercare encompasses all the ongoing support, adjustments, maintenance, and repair services that ensure your hearing aids continue to perform optimally over their lifespan. A hearing aid is not a fit-and-forget device — your hearing can change over time, your lifestyle needs may evolve, and the devices themselves require regular cleaning, servicing, and occasional repair. Good aftercare is one of the most important factors in successful long-term hearing aid use, and it is the reason why the relationship with your audiologist extends far beyond the initial fitting.

NHS aftercare is provided free of charge through audiology departments across the UK. Services typically include re-tubing and re-programming, battery supply (usually collected from a local audiology clinic, GP surgery, or posted by request), repairs and replacements, and periodic reassessment of your hearing to ensure your aids remain appropriately prescribed. Some NHS audiology services now offer "walk-in" repair clinics where minor issues can be resolved without a booked appointment. Private aftercare is usually included as part of the hearing aid purchase package, with many providers offering aftercare plans lasting 2–5 years. These plans typically cover all adjustments, professional cleaning, annual hearing retests, and in-warranty repairs, with prices either bundled into the hearing aid cost or offered as standalone packages ranging from £100 to £300 per year.

Common reasons for aftercare visits include changes in hearing, discomfort or poor fit, feedback (whistling), difficulty hearing in specific environments, broken or blocked tubing, battery issues, and moisture damage. Your audiologist can reprogramme your hearing aids to better suit your current needs, carry out physical adjustments, deep-clean the devices, and arrange manufacturer repairs for faults. It is generally recommended to have your hearing aids professionally serviced at least once a year and to have your hearing retested annually to check whether your prescription needs updating. Looking after your hearing aids is looking after your hearing — and regular aftercare appointments are the key to getting the best possible benefit from your devices.`,
    duration: "15–30 minutes for routine appointments; longer for complex adjustments",
    cost: "Free on the NHS; private aftercare is often included with purchase or £100–£300 per year",
    whoNeeds: [
      "All current hearing aid users, whether NHS or privately fitted",
      "People whose hearing aids are whistling, cutting out, or sounding different",
      "Those who feel their hearing has changed since their aids were last programmed",
      "Hearing aid users experiencing discomfort, soreness, or poor fit",
      "People who need new tubing, domes, batteries, or other consumables",
      "Anyone whose hearing aid has been damaged by moisture, wax, or accidental impact",
      "Users who want their hearing retested to check their prescription is still accurate",
    ],
    whatToExpect: [
      "Your audiologist will ask how you have been getting on with your hearing aids and whether you have any concerns",
      "The hearing aids will be visually inspected and professionally cleaned using specialist tools",
      "Tubing, domes, wax guards, and other components will be replaced if worn or blocked",
      "If your hearing has changed, a hearing retest will be performed and the aids reprogrammed accordingly",
      "Adjustments can be made to volume, programme settings, noise reduction, and feedback management",
      "Minor repairs such as replacing a battery door or microphone cover can often be done on the spot",
      "For faults that cannot be fixed in clinic, the hearing aid may be sent to the manufacturer for repair under warranty",
    ],
    frequency: "At least annually; sooner if you notice changes in performance, comfort, or hearing",
    icon: "wrench",
    relatedTests: [
      "hearing-aid-fitting",
      "standard-hearing-test",
      "ear-wax-removal",
    ],
    nhsCovered: true,
  },

  // ─── Speech-in-Noise Test ───────────────────────────────────────────
  {
    slug: "speech-in-noise-test",
    name: "Speech-in-Noise Test",
    shortDescription:
      "A specialised test that measures your ability to understand speech in background noise — one of the most common real-world hearing complaints.",
    fullDescription: `Difficulty hearing speech in noisy environments — such as busy restaurants, pubs, family gatherings, or open-plan offices — is one of the most frequently reported hearing complaints in the UK, and it is often one of the earliest signs of hearing loss. A speech-in-noise test (sometimes called a SIN test or QuickSIN) specifically measures your ability to understand speech when background noise is present. This is a different skill from hearing tones in a quiet booth, and some people with a seemingly normal audiogram still struggle significantly in noisy settings — a phenomenon sometimes referred to as "hidden hearing loss" or auditory processing difficulty.

During a speech-in-noise test, you are presented with sentences or words through headphones or speakers while background noise (typically a multi-talker babble) is played at varying levels. The test measures the signal-to-noise ratio (SNR) at which you can correctly understand 50% of the speech — known as your SNR loss or SRT-in-noise. A higher SNR loss means you need speech to be significantly louder than the noise to understand it, which correlates with real-world difficulty in noisy situations. Popular validated tests used in the UK include the QuickSIN (Quick Speech-in-Noise), the BKB-SIN (Bamford-Kowal-Bench), the HINT (Hearing in Noise Test), and the Matrix Sentence Test.

Speech-in-noise testing is increasingly recognised as an essential component of a comprehensive hearing assessment, and it is particularly valuable for hearing aid fitting — the results help audiologists select appropriate technology features such as directional microphones and noise reduction algorithms, and they set realistic expectations about hearing aid benefit in challenging listening environments. The test is available at many NHS audiology departments and private clinics, usually as part of a broader hearing assessment at no additional cost. If your main complaint is struggling to hear in pubs, restaurants, or group conversations — even if a standard hearing test says your hearing is "normal" — asking for a speech-in-noise test can provide crucial insights that a standard audiogram misses.`,
    duration: "10–20 minutes (usually part of a broader hearing assessment)",
    cost: "Usually included as part of a standard hearing test at no additional cost",
    whoNeeds: [
      "Anyone who struggles to follow conversations in noisy environments such as restaurants, pubs, or offices",
      "People with normal audiograms who still report difficulty hearing in background noise",
      "Hearing aid users who want their devices optimised for noisy environments",
      "Older adults experiencing increasing difficulty in group conversations",
      "Those being assessed for hearing aids to help guide technology selection",
      "People with suspected auditory processing difficulties",
      "Musicians and live event workers whose hearing demands are complex",
    ],
    whatToExpect: [
      "The test is typically conducted as part of a broader hearing assessment in a soundproofed room",
      "You will listen to sentences or words played through headphones or speakers",
      "Background noise (usually multi-talker babble) is played simultaneously at varying levels",
      "You are asked to repeat back the words or sentences you hear",
      "The audiologist calculates your signal-to-noise ratio (SNR) loss — the amount by which speech needs to be louder than noise for you to understand it",
      "Results help determine the degree of difficulty you experience in real-world noisy situations and guide hearing aid selection",
    ],
    frequency: "As part of routine hearing assessments, or whenever difficulty in noise is a concern",
    icon: "volume",
    relatedTests: [
      "standard-hearing-test",
      "hearing-aid-fitting",
      "musicians-hearing-test",
      "online-hearing-test",
    ],
    nhsCovered: true,
  },

  // ─── Occupational Hearing Test ──────────────────────────────────────
  {
    slug: "occupational-hearing-test",
    name: "Occupational Hearing Test",
    shortDescription:
      "Workplace hearing screening required by UK health and safety law for employees exposed to high noise levels, including baseline and periodic audiometry.",
    fullDescription: `Under the Control of Noise at Work Regulations 2005, UK employers have a legal duty to protect their employees from hearing damage caused by excessive workplace noise. When daily or weekly noise exposure reaches or exceeds the upper exposure action value of 85 decibels (dB(A)), employers must provide health surveillance in the form of regular occupational hearing tests (audiometric testing). These tests are a legal requirement in many industries, including construction, manufacturing, mining, music and entertainment, aviation, the military, farming, and any workplace where power tools, heavy machinery, or amplified sound are regularly used.

Occupational hearing tests are typically carried out by an occupational health technician or audiometrician, either on-site at the workplace (using a mobile audiometric testing unit) or at an occupational health clinic. A baseline audiogram is recorded when an employee first joins a noisy role, and subsequent tests are compared against this baseline to detect any shift in hearing thresholds that may indicate noise-induced hearing loss (NIHL). The Health and Safety Executive (HSE) recommends annual testing for those at the highest risk and testing at least every three years for those at lower risk. Results are categorised using standardised classification systems, and employees whose hearing shows a significant shift are referred for further assessment and management.

For employers, occupational hearing testing is not only a legal obligation but also a practical one — hearing loss claims cost UK businesses millions of pounds each year, and demonstrating a robust hearing conservation programme (including regular audiometry, noise assessments, provision of hearing protection, and employee education) is essential for compliance and liability management. For employees, these tests provide early warning of noise damage that might otherwise go unnoticed until it becomes severe and irreversible. Noise-induced hearing loss is entirely preventable, and regular occupational hearing tests are a critical part of that prevention. If you work in a noisy environment and have not been offered a hearing test, your employer may be failing in their legal duty — speak to your manager, occupational health department, or trade union representative.`,
    duration: "15–30 minutes per employee",
    cost: "Employer-funded (legally required); typically £25–£50 per employee",
    whoNeeds: [
      "Employees exposed to noise levels at or above 85 dB(A) as a daily or weekly average",
      "Workers in construction, manufacturing, mining, farming, or engineering",
      "Musicians, DJs, sound engineers, and live event crew",
      "Military and emergency services personnel exposed to weapons fire, sirens, or heavy machinery",
      "Airport and aviation workers",
      "Factory and warehouse workers operating power tools or heavy equipment",
      "Any employee whose employer is required to provide health surveillance under the Control of Noise at Work Regulations 2005",
    ],
    whatToExpect: [
      "You will complete a short questionnaire about your noise exposure history, hearing protection use, and any hearing symptoms",
      "An otoscopic examination of your ears will check for wax or other conditions that might affect the test",
      "Pure tone audiometry is performed in a soundproofed booth or mobile audiometric unit, testing your hearing at key frequencies",
      "A baseline audiogram is recorded on your first test, and subsequent results are compared to detect any changes",
      "Results are categorised and recorded in your occupational health file",
      "If a significant shift in hearing is detected, you will be referred for further assessment and your employer will be advised on additional protective measures",
      "You will receive advice on hearing protection and noise exposure management",
    ],
    frequency: "Annually for high-risk workers; every 3 years for those at lower risk; baseline test on joining a noisy role",
    icon: "briefcase",
    relatedTests: [
      "standard-hearing-test",
      "tinnitus-assessment",
      "musicians-hearing-test",
    ],
    nhsCovered: false,
  },

  // ─── Newborn Hearing Screening ──────────────────────────────────────
  {
    slug: "newborn-hearing-screening",
    name: "Newborn Hearing Screening",
    shortDescription:
      "The NHS Newborn Hearing Screening Programme (NHSP) — a quick, painless test offered to all babies within the first few weeks of life to detect hearing loss early.",
    fullDescription: `The NHS Newborn Hearing Screening Programme (NHSP) is one of the UK's most successful public health initiatives, offering a hearing screen to every baby born in England. Equivalent programmes operate in Scotland, Wales, and Northern Ireland. The programme was rolled out nationally in 2006 and screens over 98% of eligible babies each year. Its purpose is to identify permanent hearing loss as early as possible — ideally within the first few weeks of life — so that support, intervention, and treatment can begin before the critical window for speech and language development closes. Research consistently shows that children whose hearing loss is identified and managed early achieve significantly better outcomes in speech, language, education, and social development.

The screening test used is the Automated Otoacoustic Emissions (AOAE) test, which works by placing a small soft-tipped earpiece in the baby's ear. The device plays gentle clicking sounds and measures the faint sounds (otoacoustic emissions) produced by a healthy cochlea in response. The test takes just a few minutes per ear and is completely painless — most babies sleep through it. If a clear response is not obtained (which can happen for many reasons, including fluid in the ear, background noise, or a restless baby), the test is repeated. If the repeat test also does not produce a clear result, the baby is referred for an Automated Auditory Brainstem Response (AABR) test, which measures the auditory nerve's response to sound using small sensors placed on the baby's head. This is also painless and typically performed while the baby sleeps.

Approximately 1–2 babies in every 1,000 are born with permanent hearing loss in one or both ears. The NHSP ensures that these children are identified early and referred to specialist paediatric audiology services, where they receive comprehensive assessment, hearing aids (if appropriate), and ongoing support. For babies with severe or profound hearing loss, cochlear implantation may be considered. Parents of babies who do not pass the screening should be reassured that a referral does not necessarily mean their baby has a permanent hearing loss — many babies are referred for further testing and are subsequently found to have normal hearing. The screening is offered for free, usually performed at the hospital before discharge or by a health visitor at home within the first few weeks of life.`,
    duration: "5–15 minutes per ear",
    cost: "Free — fully funded by the NHS",
    whoNeeds: [
      "All newborn babies in the UK as part of the NHS Newborn Hearing Screening Programme",
      "Babies born in hospital who missed their screening before discharge",
      "Babies born at home or in a birthing centre who need their screening arranged by the health visitor",
      "Babies with risk factors for hearing loss, including family history, prematurity, low birth weight, or neonatal intensive care admission",
      "Babies whose parents have any concerns about their hearing or responsiveness to sound",
      "Babies who did not pass the initial AOAE screen and need a follow-up AABR test",
    ],
    whatToExpect: [
      "The screening is usually offered before you leave hospital or within the first few weeks at home",
      "A trained screener places a small, soft earpiece in your baby's ear",
      "Gentle clicking sounds are played and the device measures the response from the cochlea (AOAE test)",
      "The test is painless and takes just a few minutes — most babies sleep through it",
      "Results are given immediately: a clear response means the baby passed the screening",
      "If a clear response is not obtained, the test is repeated or the baby is referred for an AABR (auditory brainstem response) test",
      "Babies who do not pass the screening are referred to paediatric audiology for further diagnostic assessment",
    ],
    frequency: "Once — within the first few weeks of life; further testing only if the screen is not passed",
    icon: "baby",
    relatedTests: [
      "childrens-hearing-test",
      "otoacoustic-emissions",
      "auditory-brainstem-response",
    ],
    nhsCovered: true,
  },

  // ─── Bone Conduction Test ───────────────────────────────────────────
  {
    slug: "bone-conduction-test",
    name: "Bone Conduction Test",
    shortDescription:
      "A diagnostic hearing test that bypasses the outer and middle ear by sending sound vibrations directly through the skull bone to the inner ear, helping to identify the type of hearing loss.",
    fullDescription: `A bone conduction test is a key component of a comprehensive diagnostic hearing assessment, used to determine whether hearing loss is sensorineural (caused by damage to the inner ear or auditory nerve), conductive (caused by a problem in the outer or middle ear), or mixed (a combination of both). While standard pure tone audiometry tests hearing through headphones (air conduction), bone conduction testing uses a small vibrating device — called a bone oscillator or bone conductor — placed on the mastoid bone behind the ear (or sometimes on the forehead). This device sends sound vibrations directly through the skull bone to the cochlea (inner ear), completely bypassing the outer ear canal, eardrum, and middle ear structures.

By comparing the results of air conduction and bone conduction testing, the audiologist can pinpoint where in the auditory system the problem lies. If air conduction thresholds are reduced but bone conduction thresholds are normal, the hearing loss is conductive — meaning the inner ear is functioning normally, but sound is being blocked or reduced before it reaches the cochlea. Common causes of conductive hearing loss include ear wax, fluid in the middle ear (glue ear), eardrum perforation, otosclerosis, and middle ear infection. If both air and bone conduction thresholds are equally reduced, the hearing loss is sensorineural — typically caused by age-related changes, noise exposure, or genetic factors affecting the cochlea or auditory nerve. If there is a gap between air and bone conduction results, a mixed hearing loss may be present.

Bone conduction testing is a standard part of any full diagnostic audiogram at both NHS and private audiology clinics. It is not offered as a standalone test but is integrated into the hearing assessment at no additional cost. The test is completely painless and non-invasive — you will simply feel a slight vibration against the bone behind your ear and be asked to respond (usually by pressing a button) when you hear a tone. The results are plotted on the audiogram alongside your air conduction thresholds, giving your audiologist a complete picture of your hearing and allowing them to make accurate recommendations for treatment — whether that is hearing aids, medical referral, surgical intervention, or simply monitoring.`,
    duration: "10–15 minutes (part of a full hearing assessment)",
    cost: "Included as part of a standard diagnostic hearing test at no extra cost",
    whoNeeds: [
      "Anyone undergoing a comprehensive diagnostic hearing assessment",
      "People with suspected conductive hearing loss (e.g., glue ear, otosclerosis, eardrum perforation)",
      "Patients being assessed before ear surgery or grommets insertion",
      "Those whose air conduction audiometry shows hearing loss and the cause needs to be determined",
      "People with hearing loss in one ear only, where the type of loss needs clarification",
      "Anyone with a history of recurrent ear infections or middle ear problems",
    ],
    whatToExpect: [
      "The bone conduction test is performed as part of a full hearing assessment — it is not a separate appointment",
      "A small vibrating device (bone oscillator) is placed on the mastoid bone behind your ear using a headband",
      "You will hear a series of tones at different pitches transmitted through the bone to your inner ear",
      "You respond by pressing a button each time you hear a tone, just as in standard audiometry",
      "The audiologist records your bone conduction thresholds and compares them to your air conduction results",
      "The pattern of results determines whether your hearing loss is conductive, sensorineural, or mixed",
      "Your audiologist will explain the findings and discuss the implications for treatment or referral",
    ],
    frequency: "As part of any diagnostic hearing assessment; repeated if hearing changes or before treatment decisions",
    icon: "bone",
    relatedTests: [
      "standard-hearing-test",
      "tympanometry",
      "otoacoustic-emissions",
      "auditory-brainstem-response",
    ],
    nhsCovered: true,
  },

  // ─── Tympanometry ──────────────────────────────────────────────────
  {
    slug: "tympanometry",
    name: "Tympanometry",
    shortDescription:
      "A quick, objective test that measures the movement of the eardrum and the pressure in the middle ear to detect conditions such as glue ear, eardrum perforation, and Eustachian tube dysfunction.",
    fullDescription: `Tympanometry is an objective diagnostic test that assesses the function of the middle ear by measuring the movement (compliance) of the eardrum (tympanic membrane) in response to controlled changes in air pressure in the ear canal. Unlike pure tone audiometry, which requires the patient to actively respond to sounds, tympanometry is an objective measurement — it does not depend on the patient's cooperation, making it particularly useful for testing young children, people with learning difficulties, and anyone who cannot reliably perform a standard hearing test.

The test works by sealing a small probe tip in the ear canal and varying the air pressure while presenting a low-frequency tone. The instrument measures how much sound is reflected back from the eardrum at each pressure level. A healthy eardrum moves most freely when the pressure in the ear canal matches the pressure in the middle ear, producing a characteristic peaked graph called a tympanogram. The shape and position of the tympanogram peak provides valuable clinical information. A Type A tympanogram (normal peak) indicates normal middle ear function. A Type B (flat, no peak) suggests fluid in the middle ear (glue ear/otitis media with effusion), eardrum perforation, or a blocked probe. A Type C (peak shifted to negative pressure) indicates Eustachian tube dysfunction, where the tube connecting the middle ear to the back of the throat is not ventilating properly.

Tympanometry is a routine part of many audiological assessments, particularly in paediatric clinics where glue ear is extremely common — the National Deaf Children's Society estimates that 8 out of 10 children will have at least one episode of glue ear by the age of 10. It is also invaluable in adult audiology for investigating conductive hearing loss, monitoring middle ear conditions, checking eardrum integrity before ear wax removal by irrigation, and assessing Eustachian tube function. The test takes less than a minute per ear, is painless (you feel only a slight pressure change, similar to the sensation during take-off in an aircraft), and is available at both NHS and private audiology clinics, usually at no additional cost as part of a broader hearing assessment.`,
    duration: "Less than 5 minutes for both ears",
    cost: "Usually included as part of a hearing assessment at no extra cost",
    whoNeeds: [
      "Children with suspected glue ear (otitis media with effusion) or recurrent ear infections",
      "Anyone with suspected conductive hearing loss where middle ear pathology is being investigated",
      "Patients being assessed before or after grommet surgery",
      "People experiencing a persistent sensation of fullness or blocked ears",
      "Those with Eustachian tube dysfunction symptoms, such as difficulty equalising ear pressure",
      "Anyone being assessed before ear wax removal by irrigation, to rule out eardrum perforation",
      "Adults and children who cannot reliably perform standard pure tone audiometry",
    ],
    whatToExpect: [
      "A soft rubber probe tip is placed in the opening of the ear canal, creating a seal",
      "The instrument gently changes the air pressure in the ear canal while playing a low tone",
      "You will feel a slight pressure change in your ear — similar to the feeling during take-off in an aircraft — but it is not painful",
      "The test is completely automatic and takes less than a minute per ear",
      "The result is displayed as a tympanogram graph, which the audiologist interprets immediately",
      "Abnormal results may indicate glue ear, Eustachian tube dysfunction, or eardrum perforation, and further investigation may be recommended",
    ],
    frequency: "As part of routine hearing assessments or whenever middle ear problems are suspected",
    icon: "gauge",
    relatedTests: [
      "childrens-hearing-test",
      "bone-conduction-test",
      "standard-hearing-test",
      "otoacoustic-emissions",
    ],
    nhsCovered: true,
  },

  // ─── Otoacoustic Emissions Test ─────────────────────────────────────
  {
    slug: "otoacoustic-emissions",
    name: "Otoacoustic Emissions Test",
    shortDescription:
      "A quick, objective test that measures sounds produced by the healthy inner ear (cochlea) to assess cochlear function — widely used in newborn screening and diagnostic audiology.",
    fullDescription: `Otoacoustic emissions (OAEs) are faint sounds generated by the outer hair cells of the cochlea (inner ear) in response to sound stimulation. These tiny cells actively amplify incoming sounds as part of normal hearing, and the by-product of this process — otoacoustic emissions — can be detected by a sensitive microphone placed in the ear canal. The presence of robust OAEs indicates that the outer hair cells are functioning normally, while absent or reduced emissions suggest cochlear damage. OAE testing is a quick, painless, and entirely objective assessment — it requires no behavioural response from the patient, making it invaluable for testing newborns, infants, and individuals who cannot participate in conventional audiometry.

There are two main types of OAE test used in clinical practice. Transient evoked otoacoustic emissions (TEOAEs) are elicited by brief click sounds and provide a broad-frequency assessment of cochlear function — this is the method used in the NHS Newborn Hearing Screening Programme. Distortion product otoacoustic emissions (DPOAEs) use two simultaneous tones at specific frequencies to generate emissions at precise points along the cochlea, providing frequency-specific information about cochlear health. DPOAEs are particularly useful for monitoring cochlear function in patients taking ototoxic medications (drugs that can damage hearing, such as certain chemotherapy agents and aminoglycoside antibiotics), and for detecting early noise-induced cochlear damage before it shows up on a standard audiogram.

OAE testing is available at NHS audiology departments and private audiology clinics throughout the UK. In newborn screening, the test is performed as standard at no cost to parents. In diagnostic audiology, OAE testing is used alongside pure tone audiometry, bone conduction testing, and tympanometry to build a comprehensive picture of auditory function. It is particularly valuable for differentiating between sensory hearing loss (cochlear damage, where OAEs are typically absent) and neural hearing loss (auditory nerve problems, where OAEs may be present but the brain does not process the signal properly — a pattern seen in auditory neuropathy spectrum disorder). The test takes just a few minutes, involves no discomfort, and provides immediate, objective results that complement the broader hearing assessment.`,
    duration: "5–10 minutes",
    cost: "Usually included as part of a hearing assessment or newborn screening at no extra cost",
    whoNeeds: [
      "All newborn babies as part of the NHS Newborn Hearing Screening Programme",
      "Infants and young children who cannot perform standard hearing tests",
      "Patients receiving ototoxic medications (e.g., certain chemotherapy drugs or antibiotics) who need cochlear function monitoring",
      "Workers in noisy environments being screened for early noise-induced cochlear damage",
      "Anyone undergoing comprehensive diagnostic audiology assessment",
      "Patients with suspected auditory neuropathy spectrum disorder",
      "People with hearing loss where the site of the problem needs to be identified (cochlear vs. neural)",
    ],
    whatToExpect: [
      "A small soft-tipped probe is placed in the opening of the ear canal",
      "The probe plays brief sounds (clicks or tone pairs) into the ear",
      "A sensitive microphone in the probe detects the faint sounds produced by the cochlea in response",
      "The test is completely painless and takes just a few minutes per ear",
      "No active participation is required — you simply sit still (or, for babies, ideally sleep)",
      "Results are displayed immediately and indicate whether cochlear outer hair cells are functioning normally",
      "Absent or reduced emissions may prompt further diagnostic testing to determine the type and cause of hearing loss",
    ],
    frequency: "Once at birth (NHS screening); otherwise as clinically indicated during diagnostic assessment",
    icon: "activity",
    relatedTests: [
      "newborn-hearing-screening",
      "auditory-brainstem-response",
      "bone-conduction-test",
      "standard-hearing-test",
    ],
    nhsCovered: true,
  },

  // ─── Auditory Brainstem Response ────────────────────────────────────
  {
    slug: "auditory-brainstem-response",
    name: "Auditory Brainstem Response",
    shortDescription:
      "An electrophysiological hearing test that measures the auditory nerve and brainstem's response to sound, used to estimate hearing thresholds without requiring patient cooperation.",
    fullDescription: `The Auditory Brainstem Response (ABR) test — also known as Brainstem Evoked Response Audiometry (BERA) — is a sophisticated electrophysiological assessment that measures electrical activity in the auditory nerve and brainstem in response to sound stimulation. Small sensor electrodes are placed on the scalp (typically on the forehead and behind each ear), and clicking sounds or tone bursts are delivered through earphones. The ABR equipment averages thousands of neural responses to extract a characteristic waveform, the peaks and timing of which reveal how effectively the auditory pathway is transmitting signals from the ear to the brain.

ABR testing is the gold standard for objectively estimating hearing thresholds in patients who cannot perform standard behavioural audiometry — most notably newborns, infants, and young children, as well as adults with cognitive impairments, neurological conditions, or those undergoing medico-legal hearing assessment where objective evidence is required. In the NHS Newborn Hearing Screening Programme, the Automated ABR (AABR) is used as a second-tier screen for babies who do not pass the initial otoacoustic emissions test. Diagnostic ABR testing in paediatric audiology can estimate frequency-specific hearing thresholds to within 10–15 decibels, providing the information needed to fit hearing aids accurately in babies who are only weeks old — enabling the vital early intervention that evidence shows makes such a profound difference to outcomes.

ABR testing is also used to investigate suspected retrocochlear pathology, most notably acoustic neuroma (vestibular schwannoma), a benign tumour on the auditory nerve. Abnormal ABR waveforms — particularly prolonged inter-peak latencies or absent later waves — can indicate neural conduction problems that warrant MRI investigation. In the UK, ABR testing is available at NHS audiology departments (particularly paediatric audiology centres and neuro-otology clinics) by referral, and at some private audiology clinics. The test is painless and non-invasive, though it requires the patient to be very still and ideally asleep or relaxed — for babies, it is typically performed during natural sleep, and for adults, in a reclined chair in a quiet room. Diagnostic ABR testing usually takes 45–90 minutes, and the results, interpreted by a specialist audiologist, provide invaluable objective information about hearing sensitivity and auditory neural function.`,
    duration: "45–90 minutes",
    cost: "Free on the NHS with referral; £200–£400 privately",
    whoNeeds: [
      "Newborn babies who do not pass the initial otoacoustic emissions hearing screen",
      "Infants and young children who need objective hearing threshold estimation for hearing aid fitting",
      "Adults with suspected acoustic neuroma or other retrocochlear pathology",
      "Patients undergoing medico-legal hearing assessment where objective evidence is required",
      "People with auditory neuropathy spectrum disorder or suspected auditory nerve dysfunction",
      "Adults who cannot reliably perform standard behavioural audiometry due to cognitive or neurological conditions",
      "Patients with asymmetric hearing loss where an acoustic neuroma needs to be ruled out",
    ],
    whatToExpect: [
      "Small sensor electrodes are placed on your forehead and behind each ear using adhesive pads — this is painless",
      "Earphones or insert earphones deliver a series of clicking sounds or tone bursts at various volumes",
      "The ABR equipment records electrical responses from the auditory nerve and brainstem — you do not need to actively respond",
      "You will need to lie still and relax; for babies, the test is ideally performed during natural sleep",
      "The test takes 45–90 minutes depending on how many frequencies and levels need to be assessed",
      "The audiologist analyses the recorded waveforms to estimate hearing thresholds and assess neural conduction",
      "Results are discussed with you (or the child's parents) and used to guide treatment decisions such as hearing aid fitting or further investigation",
    ],
    frequency: "As clinically indicated — typically once for diagnostic purposes, with follow-up testing if needed",
    icon: "brain",
    relatedTests: [
      "newborn-hearing-screening",
      "otoacoustic-emissions",
      "bone-conduction-test",
      "balance-assessment",
    ],
    nhsCovered: true,
  },

  // ─── Home Visit Hearing Test ────────────────────────────────────────
  {
    slug: "home-visit-hearing-test",
    name: "Home Visit Hearing Test",
    shortDescription:
      "A full hearing assessment carried out in your own home by a qualified audiologist, designed for people who find it difficult to travel to a clinic.",
    fullDescription: `Home visit hearing tests — also known as domiciliary hearing services — bring professional audiology care directly to your front door. They are designed for people who find it difficult or impossible to attend a high-street clinic or hospital audiology department, whether due to mobility issues, chronic illness, disability, anxiety, lack of transport, or caring responsibilities. A qualified audiologist or hearing aid dispenser visits your home with portable testing equipment and provides the same standard of assessment you would receive in a clinic, including otoscopy, pure tone audiometry, and, where appropriate, hearing aid fitting and aftercare.

The availability of NHS domiciliary hearing services varies significantly across the UK. Some NHS audiology departments offer home visits for housebound patients, but capacity is often limited and waiting times can be long. Private home visit services are more widely available and are offered by many national hearing aid providers as well as independent audiologists. Private home visits are typically free if the patient goes on to purchase hearing aids, or charged at around £50–£100 for a standalone assessment. It is important to choose a provider whose audiologists are registered with the Health and Care Professions Council (HCPC) or whose hearing aid dispensers are registered with the Health and Care Professions Council as hearing aid dispensers, ensuring they meet professional standards and are accountable to a regulatory body.

Home visit hearing care plays a vital role in reaching the most vulnerable members of the population — older adults in care homes, people with dementia, individuals with complex physical disabilities, and those living in rural or isolated areas. Research shows that untreated hearing loss in older adults is associated with social isolation, depression, cognitive decline, and increased risk of falls, making accessible hearing care not just a convenience but a matter of public health. If you or a family member would benefit from a hearing test but cannot easily get to a clinic, a home visit service can provide the assessment, fitting, and ongoing support needed to stay connected to the world — all from the comfort of home.`,
    duration: "45–75 minutes",
    cost: "Free from some NHS departments for housebound patients; private: £50–£100 for assessment, or free if hearing aids are purchased",
    whoNeeds: [
      "Older adults with mobility difficulties who cannot easily travel to a clinic",
      "Residents of care homes or nursing homes",
      "People with chronic illness or disability that makes clinic attendance difficult",
      "Those without access to transport, particularly in rural or isolated areas",
      "Individuals with severe anxiety or agoraphobia who find clinical settings distressing",
      "Carers who cannot leave the person they care for to attend their own appointments",
      "Anyone who prefers the convenience and comfort of a hearing test at home",
    ],
    whatToExpect: [
      "A qualified audiologist or hearing aid dispenser will visit your home at a pre-arranged time, bringing portable testing equipment",
      "They will take a full history of your hearing, health, and lifestyle",
      "An otoscopic examination of your ears will check for wax, infection, or other conditions",
      "Pure tone audiometry is performed using portable equipment and headphones in the quietest room available",
      "If hearing aids are recommended, the audiologist will discuss options, take ear impressions if needed, and arrange a fitting appointment (also at home)",
      "Aftercare, adjustments, and servicing are typically available through ongoing home visits",
      "The entire process is designed to be as comfortable and convenient as possible",
    ],
    frequency: "As needed — follow-up home visits can be arranged for aftercare and hearing aid adjustments",
    icon: "home",
    relatedTests: [
      "standard-hearing-test",
      "hearing-aid-fitting",
      "hearing-aid-aftercare",
      "ear-wax-removal",
    ],
    nhsCovered: false,
  },

  // ─── Musician's Hearing Test ────────────────────────────────────────
  {
    slug: "musicians-hearing-test",
    name: "Musician's Hearing Test",
    shortDescription:
      "A specialist hearing assessment tailored for musicians, including extended high-frequency audiometry, tinnitus evaluation, and custom hearing protection advice.",
    fullDescription: `Musicians face unique hearing challenges that standard audiological assessments do not always capture. Prolonged exposure to amplified sound — whether from performing, rehearsing, or mixing — places musicians at significantly higher risk of noise-induced hearing loss and tinnitus. Yet musicians also depend on hearing with exceptional fidelity across the full frequency range, including subtle pitch discrimination, dynamic range, and spatial awareness. A musician's hearing test goes beyond standard pure tone audiometry to assess these specialised auditory demands, using extended high-frequency testing, tinnitus evaluation, loudness discomfort levels, and speech-in-noise assessment, and it includes expert advice on custom hearing protection.

Extended high-frequency audiometry tests hearing at frequencies above the standard clinical range (typically up to 8 kHz), reaching frequencies of 10, 12, 14, and even 16 kHz. Noise damage often affects these ultra-high frequencies first, long before standard audiometry shows any loss. By detecting these early changes, a musician's hearing test can provide an early warning system — prompting protective action before significant hearing damage accumulates. The assessment may also include DPOAEs (distortion product otoacoustic emissions) to objectively measure cochlear function, a tinnitus assessment if the musician reports ringing or buzzing, and loudness discomfort level testing to assess sensitivity to sound (hyperacusis), which is common among musicians.

A critical component of the musician's hearing test is advice on hearing protection. Generic foam earplugs attenuate high frequencies more than low frequencies, distorting the sound quality and making them impractical for performers. Custom-moulded musicians' earplugs with flat-attenuation filters (such as those made by ACS, Elacin, or Etymotic) reduce volume evenly across all frequencies, preserving the quality of the music while providing protection at levels typically between 9 and 25 dB attenuation. Your audiologist can take ear impressions for custom moulds during the appointment. In-ear monitors (IEMs) for live performance are another area of specialist advice. In the UK, musician's hearing tests are offered by specialist private audiologists and hearing protection clinics, typically costing £80–£200 for the assessment alone, with custom earplugs an additional £100–£200 per pair. Some organisations, such as Help Musicians and the Musicians' Hearing Health Scheme, offer subsidised hearing checks for professional musicians.`,
    duration: "45–60 minutes",
    cost: "£80–£200 privately; custom earplugs additional £100–£200; some subsidised schemes available for professional musicians",
    whoNeeds: [
      "Professional musicians, singers, and vocalists across all genres",
      "Amateur musicians and band members who rehearse or perform regularly",
      "DJs, sound engineers, and live event crew",
      "Music teachers, conductors, and orchestral musicians",
      "Club and venue staff exposed to amplified music",
      "Musicians experiencing tinnitus, sound sensitivity, or a change in hearing",
      "Anyone who wants custom musicians' earplugs or in-ear monitors",
      "Producers and studio engineers who work with headphones at elevated levels",
    ],
    whatToExpect: [
      "A detailed discussion about your music exposure history, practice habits, performance environments, and any hearing symptoms",
      "Standard pure tone audiometry followed by extended high-frequency testing up to 16 kHz",
      "Otoacoustic emissions (OAE) testing to objectively assess cochlear health",
      "A tinnitus assessment if you report ringing, buzzing, or other phantom sounds",
      "Loudness discomfort level testing to check for hyperacusis (sound sensitivity)",
      "Expert advice on custom musicians' earplugs with flat-attenuation filters, and in-ear monitors for live performance",
      "Ear impressions can be taken for custom-moulded earplugs or in-ear monitors during the appointment",
    ],
    frequency: "Annually for professional musicians; at least every 2 years for regular performers",
    icon: "music",
    relatedTests: [
      "standard-hearing-test",
      "tinnitus-assessment",
      "occupational-hearing-test",
      "speech-in-noise-test",
    ],
    nhsCovered: false,
  },
];

// ---------------------------------------------------------------------------
// Helper functions
// ---------------------------------------------------------------------------

/**
 * Find a single hearing test by its URL-friendly slug.
 * Returns `undefined` if no match is found.
 */
export function getTestBySlug(slug: string): HearingTest | undefined {
  return hearingTests.find((test) => test.slug === slug);
}

/**
 * Return an array of all available hearing test slugs.
 * Useful for generating static paths and sitemap entries.
 */
export function getAllSlugs(): string[] {
  return hearingTests.map((test) => test.slug);
}
