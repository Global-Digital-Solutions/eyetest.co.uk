import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";

// ---------------------------------------------------------------------------
// SEO metadata
// ---------------------------------------------------------------------------

export const metadata: Metadata = {
  title: "At-Home Hearing Tests UK — Home Visits, NHS Referrals & How to Book",
  description:
    "Everything you need to know about at-home hearing tests in the UK. Find out who offers domiciliary hearing assessments, who benefits from home visits, what to expect, and how to arrange one through the NHS or privately.",
  keywords: [
    "at home hearing test",
    "home hearing test",
    "domiciliary hearing test",
    "hearing test at home",
    "home visit hearing test",
    "hearing test for elderly at home",
    "mobile audiologist",
    "hidden hearing home visit",
    "boots hearingcare home visit",
    "NHS hearing test at home",
    "domiciliary audiology",
    "hearing test at home UK",
  ],
  openGraph: {
    title: "At-Home Hearing Tests UK — Home Visits, NHS Referrals & How to Book",
    description:
      "Complete guide to at-home hearing tests in the UK. Learn who offers home visits, who benefits, what to expect, and how to book a domiciliary hearing assessment.",
    url: "https://www.hearingtest.co.uk/at-home-hearing-tests",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/at-home-hearing-tests",
  },
};

// ---------------------------------------------------------------------------
// FAQ data
// ---------------------------------------------------------------------------

const faqs = [
  {
    q: "Do I need a GP referral for a home hearing test?",
    a: "It depends on the route you choose. For NHS audiology, you will usually need a referral from your GP. For private providers such as Hidden Hearing or Boots Hearingcare, no referral is needed — you or a family member can book directly by phone or online.",
  },
  {
    q: "How long does a home hearing test take?",
    a: "A home hearing assessment typically takes between 60 and 90 minutes. This is longer than a clinic appointment because the audiologist allows time to set up portable equipment, carry out the full assessment, discuss results in detail, and demonstrate hearing aids if appropriate.",
  },
  {
    q: "Is a home hearing test as accurate as a clinic test?",
    a: "Yes. A home hearing test carried out by a qualified audiologist or hearing aid dispenser uses professional, calibrated portable equipment. The assessment includes pure-tone audiometry, speech-in-noise testing, and otoscopy — the same tests you would receive in a clinic. The clinical standard is identical.",
  },
  {
    q: "Can someone else arrange a home hearing test for me?",
    a: "Absolutely. A family member, friend, carer, or care home manager can arrange a home hearing test on your behalf. This is very common — many home visits are booked by relatives who are concerned about a loved one's hearing.",
  },
  {
    q: "What if I need hearing aids after my home test?",
    a: "If the audiologist recommends hearing aids, they can discuss the available options during your visit. Private providers typically offer a range of hearing aids at different price points, and many include a free trial period. If you choose to go through the NHS, you will be referred to your local audiology department for fitting.",
  },
  {
    q: "Are home hearing tests available at weekends?",
    a: "Many private providers offer Saturday and some Sunday appointments. Hidden Hearing and Boots Hearingcare both offer weekend slots in many areas. NHS community audiology services are generally weekday-only. It is best to ask about weekend availability when you book.",
  },
  {
    q: "How much does a private home hearing test cost?",
    a: "Most private providers offer free home hearing assessments as part of their hearing aid consultation service. If you need a standalone diagnostic audiogram without a hearing aid consultation, some providers may charge between 40 and 60 pounds. Always confirm pricing when you book.",
  },
  {
    q: "Can I have a home hearing test in a care home?",
    a: "Yes. Private hearing care providers regularly visit residential care homes and nursing homes across the UK. Care home managers can arrange visits for multiple residents. Each resident receives an individual assessment, and results can be shared with the care team and GP with consent.",
  },
];

// ---------------------------------------------------------------------------
// Provider data
// ---------------------------------------------------------------------------

const providers = [
  {
    name: "Hidden Hearing",
    type: "Specialist hearing care",
    homeVisits: true,
    freeAssessment: true,
    coverage: "Nationwide UK",
    careHomes: true,
    notes:
      "One of the UK's largest hearing care providers. Offers free home hearing assessments with no obligation. HCPC-registered audiologists with full portable equipment.",
  },
  {
    name: "Boots Hearingcare",
    type: "High-street chain",
    homeVisits: true,
    freeAssessment: true,
    coverage: "Wide UK coverage",
    careHomes: true,
    notes:
      "Boots Hearingcare offers home visit hearing assessments in many areas. Free hearing health check available. Backed by Boots pharmacy network.",
  },
  {
    name: "NHS Community Audiology",
    type: "NHS service",
    homeVisits: true,
    freeAssessment: true,
    coverage: "Varies by NHS trust",
    careHomes: true,
    notes:
      "Some NHS trusts offer domiciliary audiology for housebound patients. Requires GP referral. Availability and waiting times vary significantly by region.",
  },
  {
    name: "Specsavers Audiology",
    type: "High-street chain",
    homeVisits: false,
    freeAssessment: true,
    coverage: "In-store nationwide",
    careHomes: false,
    notes:
      "Free hearing tests available in-store at Specsavers locations across the UK. Home visits are not currently offered, but stores are widely accessible.",
  },
  {
    name: "Independent audiologists",
    type: "Local / regional",
    homeVisits: true,
    freeAssessment: false,
    coverage: "Regional",
    careHomes: true,
    notes:
      "Many independent audiologists offer home visits in their local area. Fees and availability vary. Ask your nearest audiologist if they provide domiciliary services.",
  },
];

// ---------------------------------------------------------------------------
// Steps data
// ---------------------------------------------------------------------------

const steps = [
  {
    step: 1,
    title: "Booking your appointment",
    description:
      "Contact a hearing care provider by phone or through their website. For private providers like Hidden Hearing, no GP referral is needed. For NHS audiology, ask your GP for a referral to your local community audiology service. A family member or carer can book on your behalf.",
  },
  {
    step: 2,
    title: "Pre-visit confirmation",
    description:
      "The audiologist or their team will confirm your appointment date and time. They may ask about your hearing history, any existing conditions such as tinnitus, and whether you currently wear hearing aids. This helps them prepare the right equipment for your visit.",
  },
  {
    step: 3,
    title: "The hearing assessment (60-90 minutes)",
    description:
      "The audiologist will carry out a full hearing assessment in a quiet room in your home. This typically includes otoscopy (examining your ear canals), pure-tone audiometry (testing your hearing at different frequencies), and speech-in-noise testing. They may also check for ear wax build-up.",
  },
  {
    step: 4,
    title: "Discussion of results",
    description:
      "After the assessment, the audiologist will explain your audiogram and results in plain language. They will tell you about the type and degree of any hearing loss, discuss whether hearing aids could help, and answer any questions you or your family may have.",
  },
  {
    step: 5,
    title: "Hearing aid options (if appropriate)",
    description:
      "If hearing aids are recommended, the audiologist will explain the different types and technology levels available. Private providers often allow you to try hearing aids during the visit. They will discuss costs, payment plans, trial periods, and aftercare arrangements.",
  },
  {
    step: 6,
    title: "Follow-up and aftercare",
    description:
      "If you are fitted with hearing aids, the provider will arrange follow-up visits to fine-tune the settings and ensure you are comfortable. Many providers offer ongoing home visits for adjustments, battery replacements, and annual hearing reviews.",
  },
];

// ---------------------------------------------------------------------------
// Who benefits data
// ---------------------------------------------------------------------------

const whoBenefits = [
  {
    icon: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z",
    title: "Elderly patients",
    description:
      "Older adults who find it difficult to travel to a high-street clinic, particularly those with mobility issues, frailty, or multiple health conditions.",
  },
  {
    icon: "M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12",
    title: "People with mobility issues",
    description:
      "Anyone who uses a wheelchair, has difficulty walking, or cannot easily use public transport to reach a hearing clinic.",
  },
  {
    icon: "M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008z",
    title: "Care home residents",
    description:
      "Residents in care homes, nursing homes, and supported living facilities who benefit from regular hearing assessments without the disruption of travel.",
  },
  {
    icon: "M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25",
    title: "Housebound patients",
    description:
      "People who are unable to leave their home due to illness, recovery from surgery, severe anxiety, agoraphobia, or other conditions that make going out difficult.",
  },
];

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default function AtHomeHearingTestsPage() {
  /* ---- Structured data ---- */

  const webPageJsonLd = {
    "@context": "https://schema.org",
    "@type": "MedicalWebPage",
    name: "At-Home Hearing Tests UK — Home Visits, NHS Referrals & How to Book",
    description:
      "A comprehensive guide to at-home hearing tests in the UK, covering who offers domiciliary hearing assessments, who benefits from home visits, what to expect, provider comparisons, and how to arrange one.",
    url: "https://www.hearingtest.co.uk/at-home-hearing-tests",
    about: {
      "@type": "MedicalCondition",
      name: "Hearing loss assessment",
      alternateName: ["At-home hearing test", "Domiciliary hearing test", "Home visit hearing assessment"],
    },
    author: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
    lastReviewed: "2026-06-18",
    dateModified: "2026-06-18",
    inLanguage: "en-GB",
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "At-Home Hearing Tests",
        item: "https://www.hearingtest.co.uk/at-home-hearing-tests",
      },
    ],
  };

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.a,
      },
    })),
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />

        {/* ================================================================ */}
        {/* 1. HERO                                                         */}
        {/* ================================================================ */}
        <PageHero
          variant="health"
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "At-Home Hearing Tests" },
          ]}
        >
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 text-white/90 text-xs sm:text-sm font-medium px-4 py-1.5 rounded-full mb-6">
            <svg
              className="w-4 h-4 text-[var(--color-primary-light)]"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
              />
            </svg>
            <span>Professional hearing care at your door</span>
          </div>

          <h1
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            At-Home{" "}
            <span className="text-[var(--color-primary-light)]">Hearing Tests</span>
          </h1>
          <p className="text-base sm:text-lg text-white/70 mb-8 max-w-xl mx-auto">
            If you or a loved one finds it difficult to visit a hearing clinic, a
            qualified audiologist can carry out a full hearing assessment in the
            comfort of your own home.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#how-to-arrange"
              className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold px-8 py-3.5 rounded-full transition-all hover:shadow-lg text-sm sm:text-base"
            >
              How to arrange a home visit
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3" />
              </svg>
            </a>
            <a
              href="#compare-providers"
              className="inline-flex items-center gap-2 text-white/80 hover:text-white font-medium text-sm transition-colors"
            >
              Compare providers
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3" />
              </svg>
            </a>
          </div>
        </PageHero>

        {/* ================================================================ */}
        {/* 2. TRUST BAR                                                    */}
        {/* ================================================================ */}
        <section className="py-8 sm:py-10 bg-white border-b border-gray-100">
          <div className="max-w-5xl mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              {[
                { icon: "M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z", text: "Free assessments from major providers" },
                { icon: "M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25", text: "Tested in the comfort of your home" },
                { icon: "M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z", text: "Same clinical quality as in-clinic" },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-3 justify-center sm:justify-start">
                  <svg className="w-5 h-5 text-[var(--color-success)] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
                  </svg>
                  <span className="text-sm font-medium text-gray-700">{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 3. WHAT IS A DOMICILIARY HEARING TEST?                          */}
        {/* ================================================================ */}
        <section className="py-16 sm:py-20">
          <div className="max-w-4xl mx-auto px-4">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-6"
              style={{ fontFamily: "var(--font-display)" }}
            >
              What is a domiciliary hearing test?
            </h2>

            <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
              <p>
                A domiciliary hearing test &mdash; also known as an{" "}
                <strong>at-home hearing test</strong> or{" "}
                <strong>home visit hearing assessment</strong> &mdash; is a
                professional hearing evaluation carried out in your own home by a
                qualified audiologist or HCPC-registered hearing aid dispenser.
              </p>

              <p>
                The assessment uses the same calibrated, portable equipment found
                in hearing clinics, including a portable audiometer for pure-tone
                audiometry, an otoscope for examining the ear canal and eardrum,
                and speech-in-noise testing to assess how well you hear in
                everyday situations. The clinical standard is identical to what
                you would receive at a high-street hearing centre.
              </p>

              <p>
                Home hearing tests are designed for people who cannot easily
                travel to a clinic &mdash; whether due to mobility difficulties,
                illness, caring responsibilities, or simply the convenience of
                having a professional come to them. Major providers such as
                Hidden Hearing and Boots Hearingcare offer free home assessments
                across the UK, and NHS community audiology services provide
                domiciliary visits for eligible patients in some areas.
              </p>
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 4. WHO BENEFITS FROM HOME HEARING TESTS?                        */}
        {/* ================================================================ */}
        <section className="py-16 sm:py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Who benefits from home hearing tests?
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Home hearing assessments are particularly valuable for people who
                find it difficult to visit a clinic. Here are the groups who
                benefit most.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {whoBenefits.map((item) => (
                <div
                  key={item.title}
                  className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm"
                >
                  <div className="w-10 h-10 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center mb-4">
                    <svg
                      className="w-5 h-5 text-[var(--color-primary)]"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d={item.icon}
                      />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-[var(--color-navy)] mb-2">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 5. COMPARE HOME HEARING TEST PROVIDERS                          */}
        {/* ================================================================ */}
        <section id="compare-providers" className="py-16 sm:py-20 scroll-mt-24">
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Compare home hearing test providers
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Several organisations offer domiciliary hearing care across the
                UK. We&rsquo;ve compared the main providers to help you choose
                the right one for your needs.
              </p>
            </div>

            {/* Provider comparison table */}
            <div className="overflow-x-auto rounded-2xl border border-gray-100 shadow-sm">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="px-5 py-3.5 font-semibold text-[var(--color-navy)]">Provider</th>
                    <th className="px-5 py-3.5 font-semibold text-[var(--color-navy)]">Home visits</th>
                    <th className="px-5 py-3.5 font-semibold text-[var(--color-navy)]">Free assessment</th>
                    <th className="px-5 py-3.5 font-semibold text-[var(--color-navy)]">Coverage</th>
                    <th className="px-5 py-3.5 font-semibold text-[var(--color-navy)] hidden sm:table-cell">Care homes</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {providers.map((p) => (
                    <tr key={p.name} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-4 whitespace-nowrap">
                        <span className="font-medium text-[var(--color-navy)]">{p.name}</span>
                        <div className="text-xs text-gray-400 mt-0.5">{p.type}</div>
                      </td>
                      <td className="px-5 py-4">
                        {p.homeVisits ? (
                          <svg className="w-4 h-4 text-[var(--color-success)]" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <span className="text-xs text-gray-400">&mdash;</span>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        {p.freeAssessment ? (
                          <span className="inline-flex items-center gap-1 text-xs bg-[var(--color-success)]/10 text-[var(--color-success)] px-2.5 py-1 rounded-full font-medium">
                            <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                            Free
                          </span>
                        ) : (
                          <span className="text-xs text-gray-600">Varies</span>
                        )}
                      </td>
                      <td className="px-5 py-4 text-gray-600 text-xs">{p.coverage}</td>
                      <td className="px-5 py-4 hidden sm:table-cell">
                        {p.careHomes ? (
                          <svg className="w-4 h-4 text-[var(--color-success)]" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <span className="text-xs text-gray-400">&mdash;</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Provider detail cards */}
            <div className="mt-8 space-y-4">
              {providers.map((p) => (
                <div
                  key={p.name}
                  className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-[var(--color-navy)]">
                      {p.name}
                    </h3>
                    {p.homeVisits && (
                      <span className="text-xs bg-[var(--color-primary)]/10 text-[var(--color-primary)] px-2.5 py-0.5 rounded-full font-medium">
                        Home visits
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {p.notes}
                  </p>
                </div>
              ))}
            </div>

            <p className="mt-6 text-sm text-gray-500 text-center">
              hearingtest.co.uk is an independent comparison site. Provider
              information is based on editorial research. Last updated June 2026.
            </p>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 6. WHAT TO EXPECT DURING A HOME HEARING TEST                    */}
        {/* ================================================================ */}
        <section className="py-16 sm:py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                What to expect during a home hearing test
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                A home hearing assessment follows a straightforward process. Here
                is what happens at each stage.
              </p>
            </div>

            <div className="space-y-6">
              {steps.map((s) => (
                <div
                  key={s.step}
                  className="flex gap-5 bg-white border border-gray-100 rounded-2xl p-6 shadow-sm"
                >
                  <div className="w-12 h-12 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center text-lg font-bold text-[var(--color-primary)] shrink-0">
                    {s.step}
                  </div>
                  <div>
                    <h3 className="font-semibold text-[var(--color-navy)] mb-2">
                      {s.title}
                    </h3>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      {s.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 7. HOW TO ARRANGE A HOME HEARING TEST                           */}
        {/* ================================================================ */}
        <section id="how-to-arrange" className="py-16 sm:py-20 scroll-mt-24">
          <div className="max-w-4xl mx-auto px-4">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-6"
              style={{ fontFamily: "var(--font-display)" }}
            >
              How to arrange a home hearing test
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* NHS route */}
              <div className="bg-white border-l-4 border-[var(--color-nhs-blue)] rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-nhs-blue)]/10 flex items-center justify-center">
                    <span className="text-[var(--color-nhs-blue)] text-xs font-bold">NHS</span>
                  </div>
                  <h3
                    className="text-lg font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    NHS route (GP referral)
                  </h3>
                </div>
                <ul className="space-y-3 text-sm text-gray-700">
                  {[
                    "Visit your GP and explain your hearing concerns",
                    "Ask for a referral to your local NHS audiology service",
                    "The audiology department will contact you to arrange an appointment",
                    "If you are housebound, request a domiciliary (home) visit",
                    "The hearing test and any NHS hearing aids are free of charge",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <svg className="w-4 h-4 text-[var(--color-nhs-blue)] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 p-3 bg-[var(--color-nhs-blue)]/5 rounded-xl">
                  <p className="text-xs text-gray-600">
                    <strong>Note:</strong> NHS waiting times for audiology
                    referrals vary by area, typically ranging from 4 to 18 weeks.
                    Not all NHS trusts offer domiciliary visits.
                  </p>
                </div>
              </div>

              {/* Private route */}
              <div className="bg-white border-l-4 border-[var(--color-primary)] rounded-2xl p-6 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center">
                    <svg className="w-5 h-5 text-[var(--color-primary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                    </svg>
                  </div>
                  <h3
                    className="text-lg font-bold text-[var(--color-navy)]"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Private booking (no referral)
                  </h3>
                </div>
                <ul className="space-y-3 text-sm text-gray-700">
                  {[
                    "Contact a private provider directly (e.g. Hidden Hearing, Boots Hearingcare)",
                    "No GP referral needed — book by phone or online",
                    "Appointments often available within 1-2 weeks",
                    "Most offer free home hearing assessments",
                    "Hearing aid costs vary; trial periods and payment plans available",
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <svg className="w-4 h-4 text-[var(--color-primary)] shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 p-3 bg-[var(--color-primary)]/5 rounded-xl">
                  <p className="text-xs text-gray-600">
                    <strong>Tip:</strong> Private providers often offer free
                    assessments as part of their hearing aid consultation. There
                    is no obligation to purchase.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 8. FAQ                                                          */}
        {/* ================================================================ */}
        <section className="py-16 sm:py-20 bg-gray-50">
          <div className="max-w-3xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Frequently asked questions about home hearing tests
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We have answered the most common questions people ask about
                at-home hearing assessments. If you cannot find what you are
                looking for, please get in touch.
              </p>
            </div>

            <div className="space-y-4">
              {faqs.map((faq) => (
                <details
                  key={faq.q}
                  className="group bg-white border border-gray-100 rounded-2xl shadow-sm"
                >
                  <summary className="flex items-center justify-between gap-4 p-6 cursor-pointer list-none font-semibold text-[var(--color-navy)] hover:text-[var(--color-primary)] transition-colors">
                    <span>{faq.q}</span>
                    <svg
                      className="w-5 h-5 shrink-0 text-gray-400 group-open:rotate-180 transition-transform"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </summary>
                  <div className="px-6 pb-6 text-sm text-gray-600 leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* ================================================================ */}
        {/* 9. BOTTOM CTA                                                   */}
        {/* ================================================================ */}
        <section className="py-16 sm:py-20 bg-[var(--color-navy)]">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <h2
              className="text-2xl sm:text-3xl font-bold text-white mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to arrange a hearing test?
            </h2>
            <p className="text-white/70 mb-8 max-w-lg mx-auto">
              Whether you need a home visit or prefer to visit a local
              audiologist, we can help you find the right provider. Search by
              postcode to see what&rsquo;s available near you.
            </p>

            <Link
              href="/"
              className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold px-8 py-3.5 rounded-full transition-all hover:shadow-lg text-sm sm:text-base"
            >
              Search for local audiologists
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </Link>

            <p className="text-white/40 text-sm mt-6">
              Or call us on{" "}
              <a
                href="tel:02081230993"
                className="text-[var(--color-primary-light)] hover:underline"
              >
                0208 1230993
              </a>{" "}
              for help finding a provider
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
