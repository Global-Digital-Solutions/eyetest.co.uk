import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import {
  audiologists,
  getAudiologistBySlug,
  getAvailableAudiologists,
  type AudiologistBrand,
  type DetailedService,
} from "@/data/audiologists";
import {
  locations,
  getLocationBySlug,
  getAllLocationSlugs,
  nameWithCounty,
  countyArea,
  type UKLocation,
} from "@/data/locations";
import { hearingTests } from "@/data/hearing-tests";
import { articles } from "@/data/articles";

// ---------------------------------------------------------------------------
// Static generation -- every brand x location combination
// ---------------------------------------------------------------------------

export function generateStaticParams(): { brand: string; location: string }[] {
  return audiologists.flatMap((audiologist) =>
    audiologist.storeLocations.map((citySlug) => ({
      brand: audiologist.slug,
      location: citySlug,
    }))
  );
}

// ---------------------------------------------------------------------------
// Dynamic SEO metadata
// ---------------------------------------------------------------------------

export async function generateMetadata({
  params,
}: {
  params: Promise<{ brand: string; location: string }>;
}): Promise<Metadata> {
  const { brand, location } = await params;
  const audiologist = getAudiologistBySlug(brand);
  const loc = getLocationBySlug(location);

  if (!audiologist || !loc) {
    return { title: "Not Found | hearingtest.co.uk" };
  }

  // Guard: brand must serve this location
  if (!audiologist.storeLocations.includes(loc.slug)) {
    return { title: "Not Found | hearingtest.co.uk" };
  }

  const title = audiologist.available
    ? `${audiologist.name} in ${loc.name} -- Hearing Tests & Appointments | hearingtest.co.uk`
    : `${audiologist.name} in ${loc.name} -- Alternatives & Availability | hearingtest.co.uk`;

  const description = audiologist.available
    ? `Book a ${audiologist.shortName} hearing test in ${loc.name}. ${audiologist.priceRange}. NHS hearing aids available. Compare availability and book online through hearingtest.co.uk.`
    : `${audiologist.shortName} hearing tests in ${loc.name} are not available online. Compare ${getAvailableAudiologists().length} alternative audiologists in ${loc.name} with instant online booking.`;

  return {
    title,
    description,
    keywords: [
      `${audiologist.shortName} hearing test ${loc.name}`,
      `${audiologist.shortName} ${loc.name}`,
      `${audiologist.name} ${loc.name}`,
      `hearing test ${loc.name}`,
      `audiologist ${loc.name}`,
      `${audiologist.shortName} hearing test near me`,
      `book hearing test ${loc.name}`,
      `NHS hearing test ${loc.name}`,
      `${audiologist.shortName} audiologist ${loc.name}`,
      `hearing test cost ${loc.name}`,
      `free hearing test ${loc.name}`,
      `${audiologist.shortName} hearing test cost`,
      `${loc.name} audiologists`,
      `${loc.name} hearing care`,
      `${audiologist.shortName} ${loc.county}`,
    ],
    openGraph: {
      title,
      description,
      url: `https://www.hearingtest.co.uk/audiologists/${audiologist.slug}/${loc.slug}`,
      siteName: "hearingtest.co.uk",
      type: "website",
    },
    alternates: {
      canonical: `https://www.hearingtest.co.uk/audiologists/${audiologist.slug}/${loc.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

export default async function BrandLocationPage({
  params,
}: {
  params: Promise<{ brand: string; location: string }>;
}) {
  const { brand, location } = await params;
  const audiologist = getAudiologistBySlug(brand);
  const loc = getLocationBySlug(location);

  if (!audiologist || !loc) {
    notFound();
  }

  // Guard: brand must serve this location
  if (!audiologist.storeLocations.includes(loc.slug)) {
    notFound();
  }

  const availableAudiologists = getAvailableAudiologists().filter(
    (a) => a.slug !== audiologist.slug
  );

  // Nearby locations that this brand also serves
  const nearbyLocations = loc.nearbyAreas
    .map((slug) => getLocationBySlug(slug))
    .filter(
      (nearby): nearby is UKLocation =>
        nearby !== undefined && audiologist.storeLocations.includes(nearby.slug)
    );

  // Other brands that also serve this location
  const otherBrands = audiologists.filter(
    (a) =>
      a.slug !== audiologist.slug && a.storeLocations.includes(loc.slug)
  );

  // Hearing test slugs for internal linking
  const hearingTestLinks = hearingTests.slice(0, 6);
  // Article slugs for internal linking
  const articleLinks = articles.slice(0, 4);

  // ---------------------------------------------------------------------------
  // JSON-LD structured data
  // ---------------------------------------------------------------------------

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: "https://www.hearingtest.co.uk",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Audiologists",
        item: "https://www.hearingtest.co.uk/audiologists",
      },
      {
        "@type": "ListItem",
        position: 3,
        name: audiologist.name,
        item: `https://www.hearingtest.co.uk/audiologists/${audiologist.slug}`,
      },
      {
        "@type": "ListItem",
        position: 4,
        name: loc.name,
        item: `https://www.hearingtest.co.uk/audiologists/${audiologist.slug}/${loc.slug}`,
      },
    ],
  };

  const localBusinessJsonLd = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: `${audiologist.name} ${loc.name}`,
    description: audiologist.description,
    url: `https://www.hearingtest.co.uk/audiologists/${audiologist.slug}/${loc.slug}`,
    address: {
      "@type": "PostalAddress",
      addressLocality: loc.name,
      addressRegion: loc.county,
      addressCountry: "GB",
      postalCode: loc.postcode,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: loc.lat,
      longitude: loc.lng,
    },
    parentOrganization: {
      "@type": "Organization",
      name: audiologist.name,
      url: audiologist.website,
    },
    priceRange: audiologist.priceRange,
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        opens: "09:00",
        closes: "17:30",
      },
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: "Saturday",
        opens: "09:00",
        closes: "17:00",
      },
    ],
    areaServed: {
      "@type": "City",
      name: loc.name,
    },
  };

  const faqItems = audiologist.available
    ? [
        {
          q: `How much does a hearing test cost at ${audiologist.shortName} in ${loc.name}?`,
          a: `${audiologist.shortName} hearing tests in ${loc.name} are priced at ${audiologist.priceRange}. Many patients qualify for free NHS-funded hearing tests and hearing aids. You can compare prices and book online through hearingtest.co.uk.`,
        },
        {
          q: `Can I get free NHS hearing aids at ${audiologist.shortName} in ${loc.name}?`,
          a: audiologist.nhsAvailable
            ? `Yes, ${audiologist.shortName} in ${loc.name} offers NHS hearing aids for eligible patients. You will typically need a referral from your GP, although some providers offer direct access. NHS hearing aids are provided free of charge, including batteries and aftercare.`
            : `${audiologist.shortName} in ${loc.name} primarily offers private hearing care. Check hearingtest.co.uk for NHS-registered audiologists near ${loc.postcode}.`,
        },
        {
          q: `How do I book a hearing test at ${audiologist.shortName} ${loc.name}?`,
          a: `You can book a ${audiologist.shortName} hearing test in ${loc.name} by entering the postcode ${loc.postcode} on hearingtest.co.uk. You will see available appointment slots, compare prices, and book online instantly. You can also call your local ${audiologist.shortName} branch directly.`,
        },
        {
          q: `How long does a hearing test take at ${audiologist.shortName}?`,
          a: `A standard hearing test at ${audiologist.shortName} typically takes between 30 and 60 minutes. This includes a discussion of your hearing history, an ear examination, pure tone audiometry, and a detailed explanation of the results. If hearing aids are recommended, the appointment may take up to 90 minutes to include a demonstration.`,
        },
        {
          q: `Do I need a GP referral for a hearing test at ${audiologist.shortName}?`,
          a: `For private hearing tests at ${audiologist.shortName} in ${loc.name}, no GP referral is needed. For NHS hearing services, a GP referral is typically required, although some areas offer direct referral pathways. Book online through hearingtest.co.uk to check private availability near ${loc.postcode}.`,
        },
        {
          q: `What happens if I need hearing aids after my ${audiologist.shortName} test?`,
          a: `After your hearing test at ${audiologist.shortName} in ${loc.name}, your audiologist will explain your results and discuss options. If hearing aids are recommended, you can choose from ${audiologist.shortName}'s range of private hearing aids, or if eligible, receive NHS hearing aids free of charge. A trial period is usually offered with private hearing aids.`,
        },
        {
          q: `Can children have hearing tests at ${audiologist.shortName} in ${loc.name}?`,
          a: `Yes, ${audiologist.shortName} in ${loc.name} can assess children's hearing. Paediatric hearing services are available through the NHS, and some private providers also offer children's hearing tests. For newborn hearing concerns, speak to your health visitor or GP for an NHS referral.`,
        },
        {
          q: `How often should I have a hearing test?`,
          a: `The RNID recommends hearing tests every two to three years for adults, or annually if you are over 55, work in a noisy environment, or have noticed changes in your hearing. If you wear hearing aids, annual check-ups are recommended. Book your next hearing test at ${audiologist.shortName} in ${loc.name} through hearingtest.co.uk.`,
        },
        {
          q: `What services does ${audiologist.shortName} offer in ${loc.name}?`,
          a: `${audiologist.shortName} in ${loc.name} offers: ${audiologist.services.join(", ")}. Book your appointment through hearingtest.co.uk to check real-time availability.`,
        },
        {
          q: `Are there other audiologists near ${audiologist.shortName} in ${loc.name}?`,
          a: `Yes, there are ${otherBrands.length} other audiologists available in ${loc.name}, including ${otherBrands.slice(0, 3).map((a) => a.name).join(", ")}${otherBrands.length > 3 ? " and more" : ""}. Compare them all on hearingtest.co.uk.`,
        },
      ]
    : [
        {
          q: `Why can't I book a ${audiologist.shortName} hearing test through hearingtest.co.uk?`,
          a: `${audiologist.shortName} is not currently available for online booking through hearingtest.co.uk. However, there are ${availableAudiologists.length} excellent alternative audiologists in ${loc.name} that you can book with instantly, including ${availableAudiologists.slice(0, 3).map((a) => a.name).join(", ")}.`,
        },
        {
          q: `Are there alternatives to ${audiologist.shortName} in ${loc.name}?`,
          a: `Yes! ${loc.name} has ${otherBrands.filter((a) => a.available).length} audiologists available to book online right now. These include both well-known high-street brands and trusted independent practices. Many offer the same services as ${audiologist.shortName}, often with shorter waiting times.`,
        },
        {
          q: `How do I book a hearing test in ${loc.name}?`,
          a: `Enter the postcode ${loc.postcode} on hearingtest.co.uk to see all available audiologists in the ${loc.name} area. You can compare prices, services, and appointment availability, then book online in seconds. Both NHS and private hearing tests are available.`,
        },
        {
          q: `How long does a hearing test take?`,
          a: `A standard hearing test typically takes between 30 and 60 minutes at most audiologists in ${loc.name}. Comprehensive assessments including tinnitus evaluation or hearing aid fitting may take up to 90 minutes. Allow extra time if you would like to discuss hearing aid options afterwards.`,
        },
        {
          q: `Can I get free NHS hearing aids in ${loc.name}?`,
          a: `Yes, many audiologists in ${loc.name} offer free NHS hearing aids for eligible patients. You will typically need a referral from your GP. NHS hearing aids are provided free of charge, including batteries, maintenance, and aftercare for the life of the aid.`,
        },
        {
          q: `Do I need a GP referral for a hearing test?`,
          a: `For NHS hearing services, a GP referral is usually required. For private hearing tests, no referral is needed at most audiologists in ${loc.name}. You can book a private hearing test directly through hearingtest.co.uk and be seen much sooner than the typical NHS waiting time.`,
        },
        {
          q: `Do independent audiologists offer the same quality as ${audiologist.shortName}?`,
          a: `Yes. All audiologists in the UK are regulated by the Health and Care Professions Council (HCPC) to the same professional standards, regardless of where they practise. Many independent audiologists invest in the latest diagnostic equipment and offer a more personalised, unhurried service.`,
        },
        {
          q: `How much do hearing tests cost at alternatives to ${audiologist.shortName} in ${loc.name}?`,
          a: `Hearing test prices at alternative audiologists in ${loc.name} typically range from free (many offer complimentary assessments) to around ${loc.name === "London" ? "£75" : "£60"} for a comprehensive private examination. Compare prices across all available audiologists on hearingtest.co.uk.`,
        },
        {
          q: `Can children have hearing tests in ${loc.name}?`,
          a: `Yes, all audiologists in ${loc.name} can arrange children's hearing tests. Paediatric audiology is available through the NHS, and many private providers also offer children's assessments. Newborn hearing screening is conducted shortly after birth, and school-age children should have their hearing checked if there are any concerns.`,
        },
        {
          q: `Is ${audiologist.shortName} in ${loc.name} permanently closed?`,
          a: `${audiologist.shortName} in ${loc.name} may still be open for walk-in or telephone appointments. However, online booking through hearingtest.co.uk is not currently available for ${audiologist.shortName}. We recommend trying one of the ${otherBrands.filter((a) => a.available).length} alternative audiologists in ${loc.name} that offer instant online booking.`,
        },
      ];

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqItems.map((faq) => ({
      "@type": "Question",
      name: faq.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.a,
      },
    })),
  };

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <>
      <Header />
      <main className="flex-1">
        {/* JSON-LD structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(localBusinessJsonLd),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />

        {/* -- Hero ---------------------------------------------------- */}
        <PageHero
          variant="audiologists"
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Audiologists", href: "/audiologists" },
            {
              label: audiologist.name,
              href: `/audiologists/${audiologist.slug}`,
            },
            { label: loc.name },
          ]}
          compact
        >
          {/* Brand accent pill */}
          <div className="inline-flex items-center gap-2 mb-5">
            <span
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: audiologist.brandColor }}
            />
            <span className="text-sm font-medium text-white/60">
              {audiologist.shortName} &middot; {loc.name}, {loc.county}
            </span>
          </div>

          <h1 className="font-[family-name:var(--font-display)] text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {audiologist.name}{" "}
            <span className="text-[var(--color-primary-light)]">
              {loc.name}
            </span>
          </h1>

          {/* Status notice */}
          {audiologist.available ? (
            <div className="inline-flex items-center gap-2 bg-[var(--color-success)]/15 border border-[var(--color-success)]/30 text-[var(--color-success)] text-sm font-medium px-5 py-2.5 rounded-full mb-6">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[var(--color-success)] opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[var(--color-success)]" />
              </span>
              Available to book online
            </div>
          ) : (
            <div className="inline-flex items-center gap-2 bg-amber-500/15 border border-amber-500/30 text-amber-300 text-sm font-medium px-5 py-2.5 rounded-full mb-6">
              <svg
                className="w-4 h-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"
                />
              </svg>
              No online availability
            </div>
          )}

          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            {audiologist.available
              ? `Compare prices and book your ${audiologist.shortName} hearing test in ${loc.name}. NHS and private appointments available.`
              : `${audiologist.shortName} hearing tests in ${loc.name} are not currently available for online booking. See ${otherBrands.filter((a) => a.available).length} alternative audiologists below.`}
          </p>
        </PageHero>

        {/* -- Conditional content based on availability --------------- */}
        {audiologist.available ? (
          <AvailableBrandContent
            audiologist={audiologist}
            location={loc}
            alternatives={availableAudiologists}
            faqItems={faqItems}
            hearingTestLinks={hearingTestLinks}
            articleLinks={articleLinks}
            nearbyLocations={nearbyLocations}
            otherBrands={otherBrands}
          />
        ) : (
          <UnavailableBrandContent
            audiologist={audiologist}
            location={loc}
            alternatives={availableAudiologists.filter((a) =>
              a.storeLocations.includes(loc.slug)
            )}
            faqItems={faqItems}
            hearingTestLinks={hearingTestLinks}
            articleLinks={articleLinks}
            nearbyLocations={nearbyLocations}
            otherBrands={otherBrands}
          />
        )}

        {/* -- Related links ------------------------------------------- */}
        <section className="py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4">
            {/* Same brand in nearby locations */}
            {nearbyLocations.length > 0 && (
              <div className="mb-12">
                <h2
                  className="text-2xl font-bold text-[var(--color-navy)] mb-6"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {audiologist.shortName} in nearby areas
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                  {nearbyLocations.map((nearby) => (
                    <Link
                      key={nearby.slug}
                      href={`/audiologists/${audiologist.slug}/${nearby.slug}`}
                      className="group flex items-center gap-3 bg-white border border-gray-100 rounded-xl p-4 shadow-sm hover:shadow-md hover:border-[var(--color-primary)]/20 transition-all"
                    >
                      <svg
                        className="w-5 h-5 text-[var(--color-primary)] shrink-0"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                      <span className="text-sm font-medium text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors">
                        {nearby.name}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Other brands in same location */}
            {otherBrands.length > 0 && (
              <div className="mb-12">
                <h2
                  className="text-2xl font-bold text-[var(--color-navy)] mb-6"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Other audiologists in {loc.name}
                </h2>
                <div className="flex flex-wrap gap-3">
                  {otherBrands.map((other) => (
                    <Link
                      key={other.slug}
                      href={`/audiologists/${other.slug}/${loc.slug}`}
                      className="text-sm text-gray-600 hover:text-[var(--color-primary)] bg-gray-50 hover:bg-[var(--color-primary)]/5 px-4 py-2 rounded-full border border-gray-100 hover:border-[var(--color-primary)]/20 transition-all flex items-center gap-2"
                    >
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: other.brandColor }}
                      />
                      {other.shortName}
                      {other.available && (
                        <span className="w-1.5 h-1.5 bg-[var(--color-success)] rounded-full" />
                      )}
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Back links */}
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm">
              <Link
                href={`/audiologists/${audiologist.slug}`}
                className="inline-flex items-center gap-2 font-medium text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] transition-colors"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
                All {audiologist.shortName} locations
              </Link>
              <Link
                href={`/locations/${loc.slug}`}
                className="inline-flex items-center gap-2 font-medium text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] transition-colors"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
                Hearing tests in {loc.name}
              </Link>
              <Link
                href="/audiologists"
                className="inline-flex items-center gap-2 font-medium text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] transition-colors"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
                All audiologists
              </Link>
            </div>
          </div>
        </section>

        {/* -- Subtle external website reference ----------------------- */}
        <div className="max-w-7xl mx-auto px-4 py-4 text-center">
          <p className="text-xs text-gray-400">
            Visit {audiologist.name} directly:{" "}
            <a
              href={audiologist.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-gray-500 underline"
            >
              {audiologist.website.replace(/^https?:\/\//, "")}
            </a>
          </p>
        </div>
      </main>
      <Footer />
    </>
  );
}

// =============================================================================
// AVAILABLE BRAND CONTENT
// =============================================================================

function AvailableBrandContent({
  audiologist,
  location,
  alternatives,
  faqItems,
  hearingTestLinks,
  articleLinks,
  nearbyLocations,
  otherBrands,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
  alternatives: AudiologistBrand[];
  faqItems: { q: string; a: string }[];
  hearingTestLinks: { slug: string; name: string }[];
  articleLinks: { slug: string; title: string }[];
  nearbyLocations: UKLocation[];
  otherBrands: AudiologistBrand[];
}) {
  return (
    <>
      {/* -- Brand info card ----------------------------------------- */}
      <section className="max-w-7xl mx-auto px-4 py-16 sm:py-20">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Description */}
          <div className="lg:col-span-2">
            <h2 className="font-[family-name:var(--font-display)] text-2xl font-bold text-[var(--color-navy)] mb-4">
              About {audiologist.name} in {location.name}
            </h2>
            <p className="text-gray-600 leading-relaxed text-base mb-4">
              {audiologist.description}
            </p>
            <p className="text-gray-600 leading-relaxed text-base mb-4">
              {audiologist.name} in {nameWithCounty(location)} is one of{" "}
              {audiologist.storeCount.toLocaleString()}{" "}
              {audiologist.shortName} locations across the United Kingdom.
              Whether you need a routine hearing assessment, a tinnitus
              consultation, ear wax removal, or a hearing aid fitting,{" "}
              {audiologist.shortName} in {location.name} can help you
              maintain and improve your hearing health. The {location.name}{" "}
              area, covered by the postcode {location.postcode}, is well
              served by {audiologist.shortName} and other leading hearing
              care providers, giving local patients a wide choice of
              audiology services.
            </p>
            <p className="text-gray-600 leading-relaxed text-base mb-4">
              Finding the right audiologist in {location.name} can be
              straightforward when you compare services, prices, and
              availability on hearingtest.co.uk. {audiologist.shortName} is
              known for offering{" "}
              {audiologist.services
                .slice(0, 4)
                .join(", ")
                .toLowerCase()}
              , and more. Patients visiting {audiologist.shortName} in{" "}
              {location.name} benefit from{" "}
              {audiologist.nhsAvailable
                ? "both NHS and private hearing services"
                : "private hearing care"}
              , qualified audiologists registered with the Health and Care
              Professions Council, and a convenient location within the{" "}
              {location.name} area.
            </p>
            <p className="text-gray-600 leading-relaxed text-base mb-6">
              {audiologist.shortName} was founded in {audiologist.founded}{" "}
              and has grown to become one of the most recognised names in UK
              hearing care. Patients in {location.name} choose{" "}
              {audiologist.shortName} for a variety of reasons, including{" "}
              {audiologist.highlights[0]?.toLowerCase() ??
                "quality service"}{" "}
              and{" "}
              {audiologist.highlights[1]?.toLowerCase() ??
                "professional care"}
              . If you are looking for a hearing test near{" "}
              {location.postcode}, {audiologist.shortName} in{" "}
              {location.name} is an excellent choice for comprehensive
              hearing care.
            </p>

            {/* Services */}
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              Services available at {audiologist.shortName} in{" "}
              {location.name}
            </h3>
            <div className="grid gap-3 sm:grid-cols-2">
              {audiologist.services.map((service) => (
                <div
                  key={service}
                  className="flex items-center gap-3 bg-gray-50 rounded-xl p-3 border border-gray-100"
                >
                  <svg
                    className="w-4 h-4 text-[var(--color-success)] shrink-0"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <span className="text-sm font-medium text-[var(--color-navy)]">
                    {service}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick facts card */}
          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200 h-fit">
            <div
              className="h-1.5 w-full rounded-full mb-5"
              style={{ backgroundColor: audiologist.brandColor }}
            />
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              {audiologist.shortName} {location.name}
            </h3>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-gray-500">Price Range</dt>
                <dd className="font-medium text-[var(--color-navy)]">
                  {audiologist.priceRange}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">NHS Hearing Aids</dt>
                <dd className="font-medium text-[var(--color-navy)]">
                  {audiologist.nhsAvailable ? "Yes" : "No"}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">UK Locations</dt>
                <dd className="font-medium text-[var(--color-navy)]">
                  {audiologist.storeCount.toLocaleString()}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Founded</dt>
                <dd className="font-medium text-[var(--color-navy)]">
                  {audiologist.founded}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Area Postcode</dt>
                <dd className="font-medium text-[var(--color-navy)]">
                  {location.postcode}
                </dd>
              </div>
            </dl>

            {/* Postcode search form */}
            <div className="mt-5 pt-4 border-t border-gray-200">
              <h4 className="font-[family-name:var(--font-display)] text-sm font-semibold text-[var(--color-navy)] mb-2">
                Book a hearing test
              </h4>
              <form action="/search" method="GET">
                <input
                  type="text"
                  name="postcode"
                  defaultValue={location.postcode}
                  placeholder="Enter postcode"
                  aria-label="Enter your postcode"
                  className="w-full px-3 py-2 text-sm text-[var(--color-navy)] bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/30 focus:border-[var(--color-primary)] placeholder:text-gray-400 mb-2"
                />
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 text-sm font-semibold text-white py-2 px-4 rounded-lg transition-colors cursor-pointer"
                  style={{ backgroundColor: "var(--color-primary)" }}
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                  Search
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* -- Detailed Services Section -------------------------------- */}
      <DetailedServicesSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Hearing Test Cost & Pricing Section ---------------------- */}
      <HearingTestPricingSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- What to Expect at Your Appointment ----------------------- */}
      <WhatToExpectSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- NHS Hearing Services Section ----------------------------- */}
      <NHSHearingSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Book now CTA --------------------------------------------- */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-primary)] to-[#0b8a86]" />
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-white rounded-full opacity-5 blur-3xl" />

        <div className="relative max-w-3xl mx-auto px-4 py-16 sm:py-20 text-center">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-white mb-4">
            Book your {audiologist.shortName} hearing test in{" "}
            {location.name}
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Enter your postcode to check appointment availability and book
            online.
          </p>
          <form
            action="/search"
            method="GET"
            className="max-w-xl mx-auto"
          >
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-0 sm:bg-white sm:rounded-full sm:p-1.5 sm:shadow-xl sm:shadow-black/10">
              <div className="relative flex-1">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <input
                  type="text"
                  name="postcode"
                  defaultValue={location.postcode}
                  placeholder="Enter your postcode"
                  className="w-full pl-12 pr-4 py-4 sm:py-3 text-base sm:text-lg text-[var(--color-navy)] bg-white sm:bg-transparent rounded-xl sm:rounded-full border border-gray-200 sm:border-none focus:outline-none placeholder:text-gray-400"
                  aria-label="Enter your postcode"
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold text-base px-8 py-4 sm:py-3 rounded-xl sm:rounded-full transition-all hover:shadow-lg cursor-pointer sm:bg-[var(--color-navy)] sm:hover:bg-[var(--color-navy-light)]"
              >
                <svg
                  className="w-5 h-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                Search
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* -- Hearing Health Tips --------------------------------------- */}
      <HearingHealthTipsSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Getting There --------------------------------------------- */}
      <GettingThereSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Other available audiologists ------------------------------ */}
      {alternatives.filter((a) => a.storeLocations.includes(location.slug))
        .length > 0 && (
        <section className="py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Other audiologists in {location.name}
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Compare other hearing care providers available in the{" "}
                {location.name} area and find the best fit for your needs.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {alternatives
                .filter((a) => a.storeLocations.includes(location.slug))
                .slice(0, 6)
                .map((alt) => (
                  <AudiologistCard
                    key={alt.slug}
                    audiologist={alt}
                    location={location}
                  />
                ))}
            </div>
          </div>
        </section>
      )}

      {/* -- FAQ ------------------------------------------------------- */}
      <FAQSection
        title={`${audiologist.shortName} ${location.name} FAQs`}
        items={faqItems}
      />

      {/* -- Explore More (Internal Linking Block) --------------------- */}
      <ExploreMoreSection
        audiologist={audiologist}
        location={location}
        hearingTestLinks={hearingTestLinks}
        articleLinks={articleLinks}
        nearbyLocations={nearbyLocations}
        otherBrands={otherBrands}
      />
    </>
  );
}

// =============================================================================
// UNAVAILABLE BRAND CONTENT
// =============================================================================

function UnavailableBrandContent({
  audiologist,
  location,
  alternatives,
  faqItems,
  hearingTestLinks,
  articleLinks,
  nearbyLocations,
  otherBrands,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
  alternatives: AudiologistBrand[];
  faqItems: { q: string; a: string }[];
  hearingTestLinks: { slug: string; name: string }[];
  articleLinks: { slug: string; title: string }[];
  nearbyLocations: UKLocation[];
  otherBrands: AudiologistBrand[];
}) {
  return (
    <>
      {/* -- No availability notice + brand description --------------- */}
      <section className="max-w-7xl mx-auto px-4 py-12 sm:py-16">
        <div className="max-w-3xl mx-auto">
          {/* Unavailability notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 sm:p-8 mb-10">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <svg
                  className="w-6 h-6 text-amber-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"
                  />
                </svg>
              </div>
              <div>
                <h2 className="font-[family-name:var(--font-display)] text-lg font-bold text-amber-900 mb-2">
                  {audiologist.shortName} hearing tests in {location.name}{" "}
                  &mdash; No online availability
                </h2>
                <p className="text-sm text-amber-800 leading-relaxed">
                  {audiologist.name} is not currently available for online
                  booking through hearingtest.co.uk. This may be because
                  they manage appointments through their own website, or
                  because their {location.name} location has limited online
                  availability. Don&apos;t worry &mdash; there are{" "}
                  <strong>
                    {alternatives.length} excellent alternatives
                  </strong>{" "}
                  in {location.name} ready to book right now.
                </p>
              </div>
            </div>
          </div>

          {/* Expanded brand description */}
          <div className="mb-4">
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-3">
              About {audiologist.name} in {location.name}
            </h3>
            <p className="text-gray-600 text-sm leading-relaxed mb-3">
              {audiologist.description}
            </p>
            <p className="text-gray-600 text-sm leading-relaxed mb-3">
              {audiologist.name} has{" "}
              {audiologist.storeCount.toLocaleString()} locations across
              the UK and has been providing hearing care services since{" "}
              {audiologist.founded}. While {audiologist.shortName} hearing
              tests in {nameWithCounty(location)} are not currently
              available for online booking through hearingtest.co.uk,
              patients in the {location.postcode} area have access to{" "}
              {alternatives.length} other audiologists that offer instant
              online booking. These alternative audiologists in{" "}
              {location.name} provide the same professional standard of
              care, with services including hearing tests, hearing aid
              fittings, tinnitus consultations, and ear wax removal.
            </p>
            <p className="text-gray-600 text-sm leading-relaxed">
              If you specifically need a {audiologist.shortName} appointment
              in {location.name}, you may wish to visit their website
              directly or call your local branch. Otherwise, explore the
              excellent alternative audiologists available in{" "}
              {location.name} below, many of which offer same-week
              appointments with shorter waiting times.
            </p>
          </div>
        </div>
      </section>

      {/* -- Alternative audiologists (the main attraction) ------------ */}
      {alternatives.length > 0 && (
        <section className="py-16 sm:py-20 bg-gradient-to-b from-white to-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 bg-[var(--color-success)]/10 text-[var(--color-success)] text-sm font-medium px-4 py-2 rounded-full mb-4">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[var(--color-success)] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[var(--color-success)]" />
                </span>
                {alternatives.length} audiologists available to book
              </div>
              <h2
                className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Alternative audiologists in {location.name}
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                These hearing care providers in the {location.name} area
                are available for instant online booking. Same professional
                service, often with shorter waiting times.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {alternatives.map((alt) => (
                <AudiologistCard
                  key={alt.slug}
                  audiologist={alt}
                  location={location}
                  featured
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* -- Hearing Test Cost & Pricing Section ---------------------- */}
      <HearingTestPricingSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- What to Expect at Your Appointment ----------------------- */}
      <WhatToExpectSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- NHS Hearing Services Section ----------------------------- */}
      <NHSHearingSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Why choose an independent audiologist? -------------------- */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2
              className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Why choose an independent audiologist?
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Independent and smaller-chain audiologists in {location.name}{" "}
              often offer advantages over the major chains.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: (
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
                    />
                  </svg>
                ),
                title: "Personal service",
                desc: "See the same audiologist each visit. Independent practices build genuine relationships with their patients, learning your hearing health history and preferences.",
              },
              {
                icon: (
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                ),
                title: "Shorter waits",
                desc: "Independent audiologists typically offer quicker appointments, more time per consultation, and more flexible scheduling than the busier chain providers.",
              },
              {
                icon: (
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5"
                    />
                  </svg>
                ),
                title: "Wider hearing aid choice",
                desc: "Independent audiologists are not tied to a single manufacturer. They can offer hearing aids from all leading brands and select the best match for your specific hearing loss and lifestyle.",
              },
              {
                icon: (
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"
                    />
                  </svg>
                ),
                title: "Local knowledge",
                desc: `Independent audiologists in ${location.name} know the local community. They can recommend specialist services, ENT departments, and complementary healthcare professionals nearby.`,
              },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm"
              >
                <div className="w-12 h-12 rounded-xl bg-[var(--color-primary)]/10 flex items-center justify-center text-[var(--color-primary)] mb-4">
                  {item.icon}
                </div>
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)] mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* -- Hearing Health Tips --------------------------------------- */}
      <HearingHealthTipsSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- Getting There --------------------------------------------- */}
      <GettingThereSection
        audiologist={audiologist}
        location={location}
      />

      {/* -- FAQ ------------------------------------------------------- */}
      <FAQSection
        title={`${audiologist.shortName} ${location.name} FAQs`}
        items={faqItems}
      />

      {/* -- Explore More (Internal Linking Block) --------------------- */}
      <ExploreMoreSection
        audiologist={audiologist}
        location={location}
        hearingTestLinks={hearingTestLinks}
        articleLinks={articleLinks}
        nearbyLocations={nearbyLocations}
        otherBrands={otherBrands}
      />

      {/* -- CTA with postcode search --------------------------------- */}
      <section className="py-16 sm:py-20 bg-[var(--color-navy)]">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2
            className="text-2xl sm:text-3xl font-bold text-white mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Find available audiologists in {location.name}
          </h2>
          <p className="text-white/70 mb-8 max-w-lg mx-auto">
            Don&apos;t wait for {audiologist.shortName}. Compare{" "}
            {alternatives.length} audiologists with instant online booking
            in the {location.name} area.
          </p>
          <form
            action="/search"
            method="GET"
            className="max-w-xl mx-auto"
          >
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-0 sm:bg-white/10 sm:backdrop-blur-sm sm:rounded-full sm:p-1.5 sm:border sm:border-white/10">
              <div className="relative flex-1">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none">
                  <svg
                    className="w-5 h-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <input
                  type="text"
                  name="postcode"
                  defaultValue={location.postcode}
                  placeholder="Enter your postcode"
                  className="w-full pl-12 pr-4 py-4 sm:py-3 text-base text-white bg-white/10 sm:bg-transparent rounded-xl sm:rounded-full border border-white/20 sm:border-none focus:outline-none placeholder:text-white/40"
                  aria-label="Enter your postcode"
                />
              </div>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold text-base px-8 py-4 sm:py-3 rounded-xl sm:rounded-full transition-all hover:shadow-lg cursor-pointer"
              >
                <svg
                  className="w-5 h-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                Search alternatives
              </button>
            </div>
          </form>

          {/* Trust indicators */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-white/50">
            <span className="flex items-center gap-1.5">
              <svg
                className="w-4 h-4 text-[var(--color-success)]"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                />
              </svg>
              100% free to compare
            </span>
            <span className="flex items-center gap-1.5">
              <svg
                className="w-4 h-4 text-[var(--color-success)]"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                />
              </svg>
              NHS &amp; private
            </span>
            <span className="flex items-center gap-1.5">
              <svg
                className="w-4 h-4 text-[var(--color-success)]"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                />
              </svg>
              HCPC-registered audiologists
            </span>
          </div>
        </div>
      </section>
    </>
  );
}

// =============================================================================
// SHARED CONTENT SECTIONS
// =============================================================================

/** Detailed services breakdown with pricing */
function DetailedServicesSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  if (audiologist.detailedServices.length === 0) return null;

  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            Services &amp; Pricing at {audiologist.shortName} in{" "}
            {location.name}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-8">
            {audiologist.shortName} in {location.name} offers a
            comprehensive range of hearing care services. Below is a
            detailed breakdown of what is available, including pricing
            and appointment durations.
          </p>

          <div className="space-y-4">
            {audiologist.detailedServices.map((service) => (
              <div
                key={service.name}
                className="bg-white rounded-xl border border-gray-200 p-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                  <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)]">
                    {service.name}
                  </h3>
                  <div className="flex items-center gap-3">
                    {service.nhsCovered && (
                      <span className="inline-flex items-center text-xs bg-[var(--color-nhs-blue)]/10 text-[var(--color-nhs-blue)] px-2.5 py-1 rounded-full font-medium">
                        NHS
                      </span>
                    )}
                    <span className="text-sm font-bold text-[var(--color-primary)]">
                      {service.price}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed mb-2">
                  {service.description}
                </p>
                <p className="text-xs text-gray-500">
                  Duration: {service.duration}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/** Hearing Test Cost & Pricing breakdown */
function HearingTestPricingSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  // Extract key service types for pricing cards
  const freeTest = audiologist.detailedServices.find(
    (s) =>
      s.price.toLowerCase().includes("free") &&
      s.name.toLowerCase().includes("hearing")
  );
  const privateTest = audiologist.detailedServices.find(
    (s) =>
      !s.price.toLowerCase().includes("free") &&
      s.name.toLowerCase().includes("hearing") &&
      s.name.toLowerCase().includes("test")
  );
  const hearingAid = audiologist.detailedServices.find(
    (s) =>
      s.name.toLowerCase().includes("hearing aid") ||
      s.name.toLowerCase().includes("fitting")
  );
  const tinnitusService = audiologist.detailedServices.find(
    (s) => s.name.toLowerCase().includes("tinnitus")
  );

  return (
    <section className="py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            Hearing Test Cost at {audiologist.shortName} in{" "}
            {location.name}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-8">
            Understanding the cost of your hearing test at{" "}
            {audiologist.shortName} in {location.name} helps you plan
            your visit. {audiologist.shortName} offers a range of hearing
            care services at different price points. Here is a summary of
            what you can expect to pay.
          </p>

          {/* Pricing cards */}
          <div className="grid gap-4 sm:grid-cols-2 mb-8">
            {/* Free / NHS Hearing Test */}
            {freeTest && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center text-xs bg-[var(--color-nhs-blue)]/10 text-[var(--color-nhs-blue)] px-2.5 py-1 rounded-full font-medium">
                    NHS
                  </span>
                  <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)]">
                    {freeTest.name}
                  </h3>
                </div>
                <p className="text-2xl font-bold text-[var(--color-success)] mb-2">
                  {freeTest.price}
                </p>
                <p className="text-sm text-gray-600">
                  Duration: {freeTest.duration}. {freeTest.description}
                </p>
              </div>
            )}

            {/* Private Hearing Test */}
            {privateTest && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)] mb-3">
                  {privateTest.name}
                </h3>
                <p className="text-2xl font-bold text-[var(--color-navy)] mb-2">
                  {privateTest.price}
                </p>
                <p className="text-sm text-gray-600">
                  Duration: {privateTest.duration}. {privateTest.description}
                </p>
              </div>
            )}

            {/* Hearing Aid Fitting */}
            {hearingAid && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <span className="inline-flex items-center text-xs bg-[var(--color-primary)]/10 text-[var(--color-primary)] px-2.5 py-1 rounded-full font-medium">
                    Fitting
                  </span>
                  <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)]">
                    {hearingAid.name}
                  </h3>
                </div>
                <p className="text-2xl font-bold text-[var(--color-navy)] mb-2">
                  {hearingAid.price}
                </p>
                <p className="text-sm text-gray-600">
                  Duration: {hearingAid.duration}. {hearingAid.description}
                </p>
              </div>
            )}

            {/* Tinnitus Consultation */}
            {tinnitusService && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)] mb-3">
                  {tinnitusService.name}
                </h3>
                <p className="text-2xl font-bold text-[var(--color-navy)] mb-2">
                  {tinnitusService.price}
                </p>
                <p className="text-sm text-gray-600">
                  Duration: {tinnitusService.duration}.{" "}
                  {tinnitusService.description}
                </p>
              </div>
            )}
          </div>

          <p className="text-gray-600 leading-relaxed mb-4">
            Prices at {audiologist.shortName} in {location.name} are
            competitive with other audiologists in the area. All
            audiologists in the UK are regulated by the Health and Care
            Professions Council to the same professional standards,
            so the clinical quality of a hearing test is consistent
            regardless of which provider you visit.
          </p>
          <p className="text-gray-600 leading-relaxed">
            Many hearing tests are available free of charge, either
            through the NHS or as complimentary assessments offered by
            private providers. Use hearingtest.co.uk to compare prices
            across all audiologists near {location.postcode} and find
            the best option for your needs.
          </p>
        </div>
      </div>
    </section>
  );
}

/** What to Expect at Your Appointment */
function WhatToExpectSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            What to Expect at Your {audiologist.shortName} Hearing Test in{" "}
            {location.name}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-8">
            If you are visiting {audiologist.shortName} in {location.name}{" "}
            for a hearing test, knowing what to expect can help you feel
            prepared and get the most from your appointment.
          </p>

          {/* Booking process steps */}
          {audiologist.bookingProcess.length > 0 && (
            <>
              <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold text-[var(--color-navy)] mb-4">
                The booking process
              </h3>
              <div className="space-y-4 mb-8">
                {audiologist.bookingProcess.map((step, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center mt-0.5">
                      <span className="text-sm font-bold text-[var(--color-primary)]">
                        {index + 1}
                      </span>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm pt-1">
                      {step}
                    </p>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* During the test */}
          <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold text-[var(--color-navy)] mb-3">
            During your hearing test
          </h3>
          <p className="text-gray-600 leading-relaxed mb-4">
            A standard hearing test at {audiologist.shortName} in{" "}
            {location.name} typically lasts between 30 and 60 minutes.
            Your audiologist will carry out a series of checks to assess
            your hearing:
          </p>
          <div className="space-y-4 mb-6">
            {[
              {
                step: "Case history discussion",
                desc: `Your audiologist will start by asking about your general health, medications, noise exposure history, family history of hearing loss, and any specific concerns. This helps tailor the assessment to your individual needs.`,
              },
              {
                step: "Ear examination (otoscopy)",
                desc: `Using an otoscope, your audiologist will visually examine your ear canals and eardrums to check for wax build-up, infection, perforations, or other abnormalities that may affect your hearing or require treatment before further testing.`,
              },
              {
                step: "Pure tone audiometry",
                desc: `You will wear headphones and respond to a series of tones played at different pitches (frequencies) and volumes (decibels). The results are plotted on an audiogram, which shows your hearing thresholds in each ear. This is the core of the hearing test and determines the type, degree, and pattern of any hearing loss.`,
              },
              {
                step: "Speech audiometry",
                desc: `Your audiologist may test your ability to understand speech at different volume levels, both in quiet and in background noise. This gives a real-world picture of how hearing loss affects your daily communication and helps determine the most appropriate type of hearing aid if needed.`,
              },
              {
                step: "Tympanometry",
                desc: `A small probe is placed in your ear canal to measure how your eardrum responds to changes in air pressure. This test assesses the middle ear function and can detect fluid behind the eardrum, Eustachian tube dysfunction, or ossicular chain problems.`,
              },
            ].map((item) => (
              <div key={item.step} className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center mt-0.5">
                  <svg
                    className="w-4 h-4 text-[var(--color-primary)]"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div>
                  <h4 className="font-semibold text-[var(--color-navy)] mb-1">
                    {item.step}
                  </h4>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* After the test */}
          <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold text-[var(--color-navy)] mb-3">
            After your hearing test
          </h3>
          <p className="text-gray-600 leading-relaxed mb-2">
            At the end of your {audiologist.shortName} hearing test in{" "}
            {location.name}, your audiologist will:
          </p>
          <ul className="list-disc list-inside text-gray-600 leading-relaxed mb-4 space-y-1">
            <li>
              Explain your audiogram results in plain, easy-to-understand
              language
            </li>
            <li>
              Discuss whether hearing aids or other interventions are
              recommended based on your degree of hearing loss
            </li>
            <li>
              If hearing aids are appropriate, demonstrate different options
              and explain the differences between NHS and private hearing
              aids
            </li>
            <li>
              Recommend when you should return for your next hearing
              assessment
            </li>
            <li>
              If any concerns are identified, refer you to an ENT
              specialist or the hospital audiology department for further
              investigation
            </li>
          </ul>
          <p className="text-gray-600 leading-relaxed">
            Remember that you are not obliged to purchase hearing aids at{" "}
            {audiologist.shortName} in {location.name}. You are entitled to
            take your audiogram to any other provider for a second opinion
            or to explore different options. If you are eligible for NHS
            hearing aids, you can request a referral to the NHS audiology
            department through your GP.
          </p>
        </div>
      </div>
    </section>
  );
}

/** NHS Hearing Services Section */
function NHSHearingSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  return (
    <section className="py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            NHS Hearing Services in {location.name}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            {audiologist.nhsAvailable
              ? `${audiologist.shortName} in ${location.name} is registered to provide NHS hearing services, including free hearing tests and NHS hearing aids for eligible patients. Understanding the NHS hearing pathway can help you access free hearing care.`
              : `While ${audiologist.shortName} primarily offers private hearing care, NHS hearing services are available in ${location.name} through your GP and the hospital audiology department. Here is a guide to accessing free NHS hearing care in ${nameWithCounty(location)}.`}
          </p>

          <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold text-[var(--color-navy)] mb-3">
            How to access NHS hearing services
          </h3>
          <div className="space-y-4 mb-6">
            {[
              {
                step: "Visit your GP",
                detail:
                  "The first step for NHS hearing care is a visit to your GP. They will examine your ears, rule out treatable causes such as ear wax or infection, and refer you to the audiology department if a hearing test is needed.",
              },
              {
                step: "Hospital audiology referral",
                detail:
                  "Your GP will refer you to the NHS audiology department at your local hospital. Waiting times vary by area, but in most parts of the UK the wait is between 4 and 18 weeks.",
              },
              {
                step: "Hearing assessment",
                detail:
                  "At the audiology department, you will receive a comprehensive hearing test conducted by an NHS audiologist. This is free of charge and includes pure tone audiometry, speech testing, and tympanometry.",
              },
              {
                step: "Hearing aid fitting",
                detail:
                  "If hearing aids are recommended, the NHS will provide them free of charge. NHS hearing aids are digital, behind-the-ear models from reputable manufacturers. Fitting, batteries, repairs, and aftercare are all provided free of charge for the life of the hearing aids.",
              },
            ].map((item) => (
              <div
                key={item.step}
                className="bg-gray-50 rounded-xl border border-gray-200 p-4"
              >
                <h4 className="font-semibold text-[var(--color-navy)] text-sm mb-1">
                  {item.step}
                </h4>
                <p className="text-xs text-gray-600 leading-relaxed">
                  {item.detail}
                </p>
              </div>
            ))}
          </div>

          <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold text-[var(--color-navy)] mb-3">
            NHS vs private hearing care
          </h3>
          <p className="text-gray-600 leading-relaxed mb-4">
            Both NHS and private hearing services in {location.name} are
            delivered by qualified, HCPC-registered audiologists. The main
            differences are:
          </p>
          <div className="grid gap-3 sm:grid-cols-2 mb-6">
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <h4 className="font-semibold text-[var(--color-navy)] text-sm mb-2">
                NHS hearing care
              </h4>
              <ul className="text-xs text-gray-600 leading-relaxed space-y-1">
                <li>Free hearing tests and hearing aids</li>
                <li>GP referral required</li>
                <li>Waiting times of 4 to 18 weeks</li>
                <li>Behind-the-ear hearing aids only</li>
                <li>Free batteries and repairs for life</li>
                <li>Follow-up appointments available</li>
              </ul>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <h4 className="font-semibold text-[var(--color-navy)] text-sm mb-2">
                Private hearing care
              </h4>
              <ul className="text-xs text-gray-600 leading-relaxed space-y-1">
                <li>Self-referral &mdash; no GP needed</li>
                <li>Appointments within days, not weeks</li>
                <li>
                  Wider range of hearing aid styles including in-ear and
                  invisible
                </li>
                <li>
                  Latest technology with Bluetooth and rechargeable options
                </li>
                <li>Extended trial periods (30 to 90 days)</li>
                <li>Ongoing aftercare included in most packages</li>
              </ul>
            </div>
          </div>

          {/* Scotland note */}
          {location.region === "Scotland" && (
            <div className="bg-[var(--color-nhs-blue)]/5 border border-[var(--color-nhs-blue)]/15 rounded-xl p-5 mb-4">
              <h4 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)] mb-2">
                NHS hearing care in Scotland
              </h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                In Scotland, NHS hearing services include direct referral
                to audiology without needing to see a GP first in some
                areas. NHS Scotland also offers a wider range of hearing
                aid styles, including in-the-ear models in certain health
                boards. Contact your local audiology department in{" "}
                {location.name} for details.
              </p>
            </div>
          )}

          {location.region === "Wales" && (
            <div className="bg-[var(--color-nhs-blue)]/5 border border-[var(--color-nhs-blue)]/15 rounded-xl p-5 mb-4">
              <h4 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)] mb-2">
                NHS hearing care in Wales
              </h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                NHS Wales provides free hearing tests and hearing aids
                through hospital audiology departments. Some areas in
                Wales also offer Any Qualified Provider (AQP) pathways,
                allowing you to access NHS hearing aids through selected
                high-street providers. Contact your GP in {location.name}{" "}
                for a referral.
              </p>
            </div>
          )}

          <p className="text-gray-600 leading-relaxed">
            Whether you choose NHS or private hearing care in{" "}
            {location.name}, the most important step is getting your
            hearing tested. Use hearingtest.co.uk to find and compare
            audiologists near {location.postcode}, or speak to your GP
            about an NHS referral.
          </p>
        </div>
      </div>
    </section>
  );
}

/** Hearing Health Tips Section */
function HearingHealthTipsSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            Hearing Health Tips for {location.name} Residents
          </h2>
          <p className="text-gray-600 leading-relaxed mb-6">
            Maintaining good hearing health goes beyond having regular
            hearing tests at {audiologist.shortName} in {location.name}.
            Here are practical steps you can take to protect your hearing
            and support long-term ear health.
          </p>

          <div className="space-y-6">
            <div>
              <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-2">
                Why regular hearing tests matter
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Hearing loss typically develops gradually, and many people
                do not realise how much their hearing has changed until it
                significantly affects their daily life. Research from the
                RNID shows that people in the UK wait an average of ten
                years before seeking help for hearing loss. Regular hearing
                tests at {audiologist.shortName} in {location.name} can
                detect changes early, when intervention is most effective.
                Untreated hearing loss has been linked to increased risk of
                cognitive decline, social isolation, depression, and falls.
              </p>
            </div>

            <div>
              <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-2">
                Warning signs to watch for
              </h3>
              <p className="text-gray-600 leading-relaxed mb-2">
                Between your regular hearing tests, be alert to these signs
                that your hearing may be changing:
              </p>
              <ul className="list-disc list-inside text-gray-600 leading-relaxed space-y-1">
                <li>
                  Asking people to repeat themselves more often than before
                </li>
                <li>
                  Turning up the TV or radio louder than others find
                  comfortable
                </li>
                <li>
                  Difficulty following conversations in noisy environments
                  such as restaurants or pubs
                </li>
                <li>
                  Feeling that people are mumbling or not speaking clearly
                </li>
                <li>
                  Tinnitus (ringing, buzzing, or hissing sounds in your
                  ears)
                </li>
                <li>
                  Withdrawing from social situations because of difficulty
                  hearing
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-2">
                Protecting your hearing
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Noise-induced hearing loss is entirely preventable. If you
                work in a noisy environment, attend live music events, or
                use power tools, always wear appropriate hearing
                protection. Keep headphone and earbud volume below 60% of
                maximum, and follow the 60/60 rule: listen at no more than
                60% volume for no more than 60 minutes at a time.{" "}
                {audiologist.shortName} in {location.name} can advise on
                custom hearing protection moulded to your ears for maximum
                comfort and effectiveness.
              </p>
            </div>

            <p className="text-gray-600 leading-relaxed">
              For more detailed information about protecting your hearing,
              visit our{" "}
              <Link
                href="/hearing-health"
                className="text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium underline"
              >
                hearing health hub
              </Link>{" "}
              or browse our{" "}
              <Link
                href="/hearing-health/conditions"
                className="text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium underline"
              >
                hearing conditions guide
              </Link>
              .
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

/** Getting to [Brand] in [Location] */
function GettingThereSection({
  audiologist,
  location,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
}) {
  return (
    <section className="py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-4">
            Getting to {audiologist.shortName} in {location.name}
          </h2>
          <p className="text-gray-600 leading-relaxed mb-4">
            {audiologist.shortName} in {nameWithCounty(location)} is
            located in the {location.postcode} postcode area, making it
            accessible to patients across {location.name} and the
            surrounding area. Whether you are travelling by car, public
            transport, or on foot, getting to your{" "}
            {audiologist.shortName} hearing test appointment in{" "}
            {location.name} should be straightforward.
          </p>
          <p className="text-gray-600 leading-relaxed mb-4">
            {location.name} is generally well served by public transport,
            with bus and rail connections to the town centre where many
            audiologists, including {audiologist.shortName}, are typically
            located. If you are driving, there are usually a variety of
            parking options in the {location.name} area. It is worth
            checking the specific parking arrangements for your chosen{" "}
            {audiologist.shortName} branch before your visit.
          </p>
          <p className="text-gray-600 leading-relaxed">
            If you have mobility requirements or accessibility needs,
            contact the {audiologist.shortName} branch in {location.name}{" "}
            before your appointment to ensure they can accommodate you
            comfortably. Many {audiologist.shortName} locations offer
            step-free access, and staff are trained to assist patients
            with disabilities. For patients who cannot travel to a branch,
            some audiologists in the {location.name} area offer{" "}
            <Link
              href="/hearing-tests"
              className="text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium underline"
            >
              home visit hearing tests
            </Link>{" "}
            for housebound or elderly patients.
          </p>
        </div>
      </div>
    </section>
  );
}

/** Explore More (Internal Linking Block) */
function ExploreMoreSection({
  audiologist,
  location,
  hearingTestLinks,
  articleLinks,
  nearbyLocations,
  otherBrands,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
  hearingTestLinks: { slug: string; name: string }[];
  articleLinks: { slug: string; title: string }[];
  nearbyLocations: UKLocation[];
  otherBrands: AudiologistBrand[];
}) {
  const availableBrands = otherBrands.filter((b) => b.available);
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h2
          className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-8 text-center"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Explore More
        </h2>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {/* Compare with other brands in same location */}
          {availableBrands.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6">
              <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
                Compare audiologists in {location.name}
              </h3>
              <ul className="space-y-2">
                {availableBrands.slice(0, 5).map((brand) => (
                  <li key={brand.slug}>
                    <Link
                      href={`/audiologists/${brand.slug}/${location.slug}`}
                      className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                    >
                      <span
                        className="w-2 h-2 rounded-full flex-shrink-0"
                        style={{ backgroundColor: brand.brandColor }}
                      />
                      {brand.shortName} in {location.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Same brand in nearby locations */}
          {nearbyLocations.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6">
              <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
                {audiologist.shortName} nearby
              </h3>
              <ul className="space-y-2">
                {nearbyLocations.slice(0, 5).map((nearby) => (
                  <li key={nearby.slug}>
                    <Link
                      href={`/audiologists/${audiologist.slug}/${nearby.slug}`}
                      className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                    >
                      <svg
                        className="w-4 h-4 flex-shrink-0"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                        />
                      </svg>
                      {audiologist.shortName} in {nearby.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Hearing test types */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              Types of hearing tests
            </h3>
            <ul className="space-y-2">
              {hearingTestLinks.map((test) => (
                <li key={test.slug}>
                  <Link
                    href={`/hearing-tests/${test.slug}`}
                    className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                  >
                    <svg
                      className="w-4 h-4 flex-shrink-0"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                    {test.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Hearing health conditions */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              Hearing health conditions
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/hearing-health/conditions"
                  className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                  Browse all hearing conditions
                </Link>
              </li>
              <li>
                <Link
                  href="/hearing-health"
                  className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                  Hearing health hub
                </Link>
              </li>
            </ul>
          </div>

          {/* Articles */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              Helpful articles
            </h3>
            <ul className="space-y-2">
              {articleLinks.map((article) => (
                <li key={article.slug}>
                  <Link
                    href={`/articles/${article.slug}`}
                    className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                  >
                    <svg
                      className="w-4 h-4 flex-shrink-0"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                    {article.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Location page link */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[var(--color-navy)] mb-4">
              {location.name} hearing care
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href={`/locations/${location.slug}`}
                  className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                  All audiologists in {location.name}
                </Link>
              </li>
              <li>
                <Link
                  href={`/audiologists/${audiologist.slug}`}
                  className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                  All {audiologist.shortName} locations
                </Link>
              </li>
              <li>
                <Link
                  href="/audiologists"
                  className="text-sm text-[var(--color-primary)] hover:text-[var(--color-primary-dark)] font-medium flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4 flex-shrink-0"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                  Compare all UK audiologists
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

// =============================================================================
// SHARED COMPONENTS
// =============================================================================

/** Audiologist card used in both available and unavailable brand pages */
function AudiologistCard({
  audiologist,
  location,
  featured = false,
}: {
  audiologist: AudiologistBrand;
  location: UKLocation;
  featured?: boolean;
}) {
  return (
    <div
      className={`bg-white border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all ${
        featured
          ? "border-[var(--color-primary)]/20 hover:border-[var(--color-primary)]/40"
          : "border-gray-100 hover:border-[var(--color-primary)]/20"
      }`}
    >
      {/* Brand accent bar */}
      <div
        className="h-1.5 w-full"
        style={{ backgroundColor: audiologist.brandColor }}
      />

      <div className="p-6">
        {/* Header */}
        <div className="flex items-start gap-4 mb-4">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg shrink-0"
            style={{ backgroundColor: audiologist.brandColor }}
          >
            {audiologist.shortName.charAt(0)}
          </div>
          <div className="min-w-0">
            <h3 className="font-[family-name:var(--font-display)] font-semibold text-[var(--color-navy)]">
              {audiologist.name}
            </h3>
            <p className="text-sm text-gray-500">
              {audiologist.storeCount}+ locations nationwide
            </p>
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          <span className="inline-flex items-center gap-1 text-xs bg-[var(--color-success)]/10 text-[var(--color-success)] px-2.5 py-1 rounded-full font-medium">
            <span className="w-1.5 h-1.5 bg-[var(--color-success)] rounded-full" />
            Available to book
          </span>
          {audiologist.nhsAvailable && (
            <span className="inline-flex items-center text-xs bg-[var(--color-nhs-blue)]/10 text-[var(--color-nhs-blue)] px-2.5 py-1 rounded-full font-medium">
              NHS
            </span>
          )}
        </div>

        {/* Services preview */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {audiologist.services.slice(0, 4).map((service) => (
            <span
              key={service}
              className="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-600"
            >
              {service}
            </span>
          ))}
          {audiologist.services.length > 4 && (
            <span className="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs text-gray-500">
              +{audiologist.services.length - 4} more
            </span>
          )}
        </div>

        {/* Price range */}
        <p className="text-sm text-gray-500 mb-5">
          {audiologist.priceRange}
        </p>

        {/* CTA */}
        <Link
          href={`/search?postcode=${encodeURIComponent(location.postcode)}`}
          className="w-full flex items-center justify-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold text-sm px-6 py-3 rounded-full transition-all hover:shadow-lg"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth="2.5"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          Book hearing test
        </Link>
      </div>
    </div>
  );
}

/** FAQ accordion section used by both variants */
function FAQSection({
  title,
  items,
}: {
  title: string;
  items: { q: string; a: string }[];
}) {
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2
            className="text-2xl sm:text-3xl font-bold text-[var(--color-navy)] mb-3"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {title}
          </h2>
        </div>

        <div className="space-y-4">
          {items.map((faq) => (
            <details
              key={faq.q}
              className="group bg-white border border-gray-100 rounded-2xl shadow-sm"
            >
              <summary className="flex items-center justify-between gap-4 p-6 cursor-pointer list-none font-semibold text-[var(--color-navy)] hover:text-[var(--color-primary)] transition-colors">
                <span>{faq.q}</span>
                <svg
                  className="w-5 h-5 shrink-0 text-gray-400 group-open:rotate-180 transition-transform"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </summary>
              <div className="px-6 pb-6 text-sm text-gray-600 leading-relaxed">
                {faq.a}
              </div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
