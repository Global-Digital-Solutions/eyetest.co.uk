import type { Metadata } from "next";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PageHero from "@/components/PageHero";
import { hearingConditions, hearingGuides } from "@/data/hearing-health";

export const metadata: Metadata = {
  title: "Hearing Health — Conditions & Guides | hearingtest.co.uk",
  description:
    "Learn about common hearing conditions including tinnitus, hearing loss, glue ear, and Meniere's disease, plus practical guides on hearing aids, NHS services, and protecting your hearing.",
  openGraph: {
    title: "Hearing Health — Conditions & Guides | hearingtest.co.uk",
    description:
      "Learn about common hearing conditions and read practical guides on hearing aids, NHS services, and protecting your hearing.",
    url: "https://www.hearingtest.co.uk/hearing-health",
    siteName: "hearingtest.co.uk",
    type: "website",
  },
  alternates: {
    canonical: "https://www.hearingtest.co.uk/hearing-health",
  },
};

export default function HearingHealthPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Hearing Health — Conditions & Guides",
    description:
      "Comprehensive information on hearing conditions and practical hearing health guides for UK readers.",
    url: "https://www.hearingtest.co.uk/hearing-health",
    publisher: {
      "@type": "Organization",
      name: "hearingtest.co.uk",
      url: "https://www.hearingtest.co.uk",
    },
  };

  return (
    <>
      <Header />
      <main className="flex-1">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        <PageHero
          variant="health"
          breadcrumbs={[
            { label: "Home", href: "/" },
            { label: "Hearing Health" },
          ]}
        >
          <h1
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Hearing Health
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/90 max-w-3xl">
            Understand common hearing conditions, learn how to protect your
            hearing, and get practical advice on NHS services, hearing aids,
            and more.
          </p>
        </PageHero>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
          {/* ── Hearing Conditions ──────────────────────────────────── */}
          <section>
            <h2
              className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Hearing Conditions
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl">
              In-depth information on 15 hearing and ear conditions, including
              symptoms, causes, treatments, and when to seek help.
            </p>

            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {hearingConditions.map((condition) => (
                <Link
                  key={condition.slug}
                  href={`/hearing-health/conditions/${condition.slug}`}
                  className="group block rounded-2xl border border-gray-200 bg-white p-6 shadow-sm transition hover:shadow-md hover:border-[var(--color-primary)]"
                >
                  <h3
                    className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {condition.name}
                  </h3>
                  <p className="mt-2 text-sm text-gray-600 line-clamp-3">
                    {condition.shortDescription}
                  </p>
                  <span className="mt-4 inline-flex items-center text-sm font-medium text-[var(--color-primary)]">
                    Read more
                    <svg
                      className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                      />
                    </svg>
                  </span>
                </Link>
              ))}
            </div>
          </section>

          {/* ── Hearing Guides ──────────────────────────────────────── */}
          <section className="mt-16">
            <h2
              className="text-2xl md:text-3xl font-bold text-[var(--color-navy)]"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Hearing Guides
            </h2>
            <p className="mt-2 text-gray-600 max-w-2xl">
              Practical, evidence-based guides covering hearing tests,
              audiograms, hearing aids, NHS services, and more.
            </p>

            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {hearingGuides.map((guide) => (
                <Link
                  key={guide.slug}
                  href={`/hearing-health/guides/${guide.slug}`}
                  className="group block rounded-2xl border border-gray-200 bg-white p-6 shadow-sm transition hover:shadow-md hover:border-[var(--color-primary)]"
                >
                  <h3
                    className="text-lg font-semibold text-[var(--color-navy)] group-hover:text-[var(--color-primary)] transition-colors"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {guide.title}
                  </h3>
                  <p className="mt-2 text-sm text-gray-600 line-clamp-3">
                    {guide.shortDescription}
                  </p>
                  <span className="mt-4 inline-flex items-center text-sm font-medium text-[var(--color-primary)]">
                    Read guide
                    <svg
                      className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                      />
                    </svg>
                  </span>
                </Link>
              ))}
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
